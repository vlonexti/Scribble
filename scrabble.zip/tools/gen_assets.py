"""
Scribble asset generator.

Generates every GUI sprite / texture used by the mod as pixel art, straight into
src/main/resources/assets/scribble/textures/gui/sprites. Pure python (no PIL).

    python tools/gen_assets.py
"""
import json
import math
import os
import random
import struct
import zlib

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "scribble", "textures", "gui", "sprites")


# --------------------------------------------------------------------------- image basics

class Img:
    def __init__(self, w, h, fill=(0, 0, 0, 0)):
        self.w, self.h = w, h
        self.px = [fill] * (w * h)

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.px[y * self.w + x]
        return (0, 0, 0, 0)

    def set(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h and c is not None:
            if len(c) == 3:
                c = (c[0], c[1], c[2], 255)
            if c[3] == 255 or self.get(x, y)[3] == 0:
                self.px[y * self.w + x] = c
            else:
                self.px[y * self.w + x] = blend(self.get(x, y), c)

    def put(self, x, y, c):
        """Set without blending."""
        if 0 <= x < self.w and 0 <= y < self.h:
            if len(c) == 3:
                c = (c[0], c[1], c[2], 255)
            self.px[y * self.w + x] = c

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.set(x, y, c)

    def hline(self, x0, x1, y, c):
        self.rect(x0, y, x1, y, c)

    def vline(self, x, y0, y1, c):
        self.rect(x, y0, x, y1, c)

    def line(self, x0, y0, x1, y1, c, w=1):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            for oy in range(w):
                for ox in range(w):
                    self.set(x0 + ox, y0 + oy, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def disc(self, cx, cy, r, c):
        for y in range(self.h):
            for x in range(self.w):
                if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                    self.set(x, y, c)

    def ring(self, cx, cy, r0, r1, c):
        for y in range(self.h):
            for x in range(self.w):
                d = (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2
                if r0 * r0 <= d <= r1 * r1:
                    self.set(x, y, c)

    def paste(self, other, ox, oy):
        for y in range(other.h):
            for x in range(other.w):
                c = other.get(x, y)
                if c[3]:
                    self.set(ox + x, oy + y, c)

    def flip_h(self):
        o = Img(self.w, self.h)
        for y in range(self.h):
            for x in range(self.w):
                o.put(self.w - 1 - x, y, self.get(x, y))
        return o

    def outline(self, c=None, diagonal=False):
        c = c or OUTLINE
        o = Img(self.w, self.h)
        o.px = list(self.px)
        for y in range(self.h):
            for x in range(self.w):
                if self.get(x, y)[3] != 0:
                    continue
                nb = [(1, 0), (-1, 0), (0, 1), (0, -1)]
                if diagonal:
                    nb += [(1, 1), (-1, 1), (1, -1), (-1, -1)]
                if any(self.get(x + dx, y + dy)[3] > 100 for dx, dy in nb):
                    o.put(x, y, c)
        return o

    def scaled(self, f):
        o = Img(self.w * f, self.h * f)
        for y in range(o.h):
            for x in range(o.w):
                o.put(x, y, self.get(x // f, y // f))
        return o

    def save(self, rel, meta=None):
        path = os.path.join(OUT, rel + ".png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        raw = bytearray()
        for y in range(self.h):
            raw.append(0)
            for x in range(self.w):
                raw.extend(bytes(self.px[y * self.w + x]))
        data = b"\x89PNG\r\n\x1a\n"
        data += chunk(b"IHDR", struct.pack(">IIBBBBB", self.w, self.h, 8, 6, 0, 0, 0))
        data += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        data += chunk(b"IEND", b"")
        with open(path, "wb") as f:
            f.write(data)
        meta_path = path + ".mcmeta"
        if meta:
            with open(meta_path, "w") as f:
                json.dump({"gui": {"scaling": meta}}, f, indent=2)
        elif os.path.exists(meta_path):
            os.remove(meta_path)


def chunk(tag, data):
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def blend(dst, src):
    sa = src[3] / 255.0
    da = dst[3] / 255.0
    oa = sa + da * (1 - sa)
    if oa <= 0:
        return (0, 0, 0, 0)
    r = (src[0] * sa + dst[0] * da * (1 - sa)) / oa
    g = (src[1] * sa + dst[1] * da * (1 - sa)) / oa
    b = (src[2] * sa + dst[2] * da * (1 - sa)) / oa
    return (int(r + 0.5), int(g + 0.5), int(b + 0.5), int(oa * 255 + 0.5))


def shade(c, d):
    return (max(0, min(255, c[0] + d)), max(0, min(255, c[1] + d)), max(0, min(255, c[2] + d)), c[3] if len(c) > 3 else 255)


def hexc(s, a=255):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), a)


def nine(w, h, border):
    return {"type": "nine_slice", "width": w, "height": h, "border": border}


def tile(w, h):
    return {"type": "tile", "width": w, "height": h}


# --------------------------------------------------------------------------- palette

OUTLINE = hexc("3b2a1e")
INK = OUTLINE
P = {
    ".": None,
    "k": OUTLINE,
    "x": hexc("000000"),
    "w": hexc("ffffff"),
    "W": hexc("e8e8ee"),
    "l": hexc("c6c6c6"),
    "g": hexc("8b8b8b"),
    "d": hexc("555555"),
    "D": hexc("3a3a3a"),
    "y": hexc("ffd24a"),
    "Y": hexc("c99a1e"),
    "o": hexc("f08a24"),
    "O": hexc("a85a12"),
    "r": hexc("e04848"),
    "R": hexc("962828"),
    "p": hexc("f7a8bb"),
    "P": hexc("cf7088"),
    "b": hexc("4a86e0"),
    "B": hexc("234a8f"),
    "c": hexc("9fdcff"),
    "C": hexc("5aa8dc"),
    "G": hexc("5bbd4f"),
    "E": hexc("2f7a2c"),
    "e": hexc("a6ea86"),
    "n": hexc("a06c3a"),
    "N": hexc("62401e"),
    "t": hexc("e2c08c"),
    "T": hexc("b8925a"),
    "m": hexc("9a66e0"),
    "M": hexc("5d3596"),
    "s": hexc("2f5a40"),
    "S": hexc("1d3a29"),
    "f": hexc("74747f"),
    "F": hexc("4d4d57"),
    "h": hexc("3e3e46"),
    "q": hexc("fff6c8"),
    "u": hexc("2a5ea8"),
    "U": hexc("163a70"),
    "z": hexc("e7d3a4"),
    "Z": hexc("b89a62"),
}


def ascii_img(rows, w=16, h=16, palette=P):
    img = Img(w, h)
    for y, row in enumerate(rows[:h]):
        for x, ch in enumerate(row[:w]):
            c = palette.get(ch)
            if c:
                img.put(x, y, c)
    return img


# --------------------------------------------------------------------------- diagonal tool helper

def diag_tool(segs, size=16, shading=True):
    """
    Draws a stick-like tool running from the bottom-left (tip, v=-11) to the top-right (v=+11).
    segs: list of (v0, v1, halfwidth, (hi, main, shadow)). halfwidth may be a callable(v)->int
    """
    img = Img(size, size)
    c = (size - 1)
    for y in range(size):
        for x in range(size):
            v = x - y
            u = x + y - c
            for v0, v1, hw, cols in segs:
                if v0 <= v <= v1:
                    w = hw(v) if callable(hw) else hw
                    if abs(u) <= w:
                        if not shading or w == 0:
                            col = cols[1]
                        elif u < 0:
                            col = cols[0]
                        elif u > 0 and u >= w:
                            col = cols[2]
                        else:
                            col = cols[1]
                        img.put(x, y, col)
                    break
    return img


def tri(c):
    return (shade(c, 40), c, shade(c, -45))


# --------------------------------------------------------------------------- icons

def icon_tools():
    out = {}
    graphite = (hexc("6a6a74"), hexc("3e3e46"), hexc("2a2a30"))
    metal = (hexc("e6e6ea"), hexc("b0b0b8"), hexc("7a7a84"))

    out["tool_pen"] = diag_tool([
        (-11, -10, 0, graphite),
        (-9, -7, 1, metal),
        (-6, 7, 1, tri(hexc("3f7fe0"))),
        (8, 11, 1, tri(hexc("1f3f80"))),
    ])
    out["tool_pencil"] = diag_tool([
        (-11, -10, 0, graphite),
        (-9, -8, lambda v: 0 if v == -9 else 1, tri(hexc("e8c48c"))),
        (-7, 5, 1, tri(hexc("f6c431"))),
        (6, 7, 1, metal),
        (8, 11, 1, tri(hexc("f39ab0"))),
    ])
    out["tool_marker"] = diag_tool([
        (-11, -10, 0, tri(hexc("2a2a30"))),
        (-9, -8, 1, tri(hexc("2a2a30"))),
        (-7, 3, 2, tri(hexc("f2f2f4"))),
        (4, 11, 2, tri(hexc("3a6ad0"))),
    ])
    out["tool_highlighter"] = diag_tool([
        (-11, -10, 1, tri(hexc("e8f020"))),
        (-9, -8, 1, tri(hexc("4a4a52"))),
        (-7, 0, 2, tri(hexc("fff27a"))),
        (1, 2, 2, tri(hexc("f0c020"))),
        (3, 4, 2, tri(hexc("fff27a"))),
        (5, 11, 2, tri(hexc("5a5a62"))),
    ])
    chalk = diag_tool([
        (-7, -6, 1, (hexc("ffffff"), hexc("f0f0f0"), hexc("c8c8c8"))),
        (-5, 7, 2, (hexc("ffffff"), hexc("f0f0f0"), hexc("c0c0c0"))),
    ])
    rnd = random.Random(4)
    for _ in range(5):
        x, y = rnd.randint(4, 11), rnd.randint(4, 11)
        if chalk.get(x, y)[3]:
            chalk.put(x, y, hexc("d4d4d4"))
    # dust puffs near tip
    for (x, y) in [(2, 13), (1, 11), (4, 14), (3, 12)]:
        chalk.put(x, y, hexc("ffffff", 160))
    out["tool_chalk"] = chalk
    out["tool_crayon"] = diag_tool([
        (-11, -10, lambda v: 0, tri(hexc("e04848"))),
        (-9, -8, 1, tri(hexc("e04848"))),
        (-7, 7, 1, tri(hexc("e04848"))),
        (-3, 3, 1, tri(hexc("f2f2f2"))),
        (8, 11, 1, tri(hexc("b83030"))),
    ])
    # crayon: paper wrapper band painted after
    cr = out["tool_crayon"]
    for y in range(16):
        for x in range(16):
            v = x - y
            if -3 <= v <= 4 and cr.get(x, y)[3]:
                cr.put(x, y, shade(hexc("f2f2f2"), -20 if (x + y - 15) > 0 else 0))
            if v in (-3, 4) and cr.get(x, y)[3]:
                cr.put(x, y, hexc("962828"))

    # quill: feather vane widening then narrowing
    def vane(v):
        if v < -3:
            return 0
        if v <= 6:
            return min(3, 1 + (v + 3) // 2)
        return max(0, int(3 - (v - 6) * 0.6))
    quill = diag_tool([
        (-11, -10, 0, graphite),
        (-9, -4, 0, (hexc("e8e0d0"), hexc("d8ccb4"), hexc("a8987a"))),
        (-3, 11, vane, (hexc("ffffff"), hexc("ece6dc"), hexc("bcb2a2"))),
    ])
    # shaft line through vane
    for i in range(-3, 12):
        x = (i + 15) // 2
        y = 15 - x - 0
        # the shaft is u=0: x + y = 15, v = x - y = i => x=(15+i)/2
        if (15 + i) % 2 == 0:
            quill.put(x, 15 - x, hexc("b8a888"))
    out["tool_quill"] = quill

    out["tool_eyedropper"] = diag_tool([
        (-11, -10, 0, tri(hexc("3a78d8"))),
        (-9, -4, 1, (hexc("ffffff"), hexc("5aa0f0"), hexc("2a68c8"))),
        (-3, 2, 1, (hexc("ffffff"), hexc("d8f0ff"), hexc("9ac8e8"))),
        (3, 4, 2, metal),
        (5, 11, 2, tri(hexc("3a3a42"))),
    ])

    sword = diag_tool([
        (-11, -10, 0, (hexc("ffffff"), hexc("e8e8ee"), hexc("b0b0b8"))),
        (-9, 3, 1, (hexc("ffffff"), hexc("d8d8e0"), hexc("8a8a94"))),
        (4, 5, 3, tri(hexc("6a4a2a"))),
        (6, 9, 0, tri(hexc("7a5230"))),
        (10, 11, 1, tri(hexc("6a4a2a"))),
    ])
    out["_sword"] = sword

    # erasers
    out["eraser_pencil"] = diag_tool([
        (-7, -1, 3, tri(hexc("f7a0b4"))),
        (0, 7, 3, tri(hexc("4a86e0"))),
    ])
    er = out["eraser_pencil"]
    for y in range(16):
        for x in range(16):
            if (x - y) == 3 and er.get(x, y)[3]:
                er.put(x, y, hexc("ffffff"))

    out["eraser_dry"] = ascii_img([
        "................",
        "................",
        "................",
        "................",
        "....bbbbbbbb....",
        "...bccbbbbbbB...",
        "..bbbbbbbbbbbB..",
        "..BBBBBBBBBBBB..",
        "..UUUUUUUUUUUU..",
        "..llllllllllll..",
        "..ggfggfggggfg..",
        "..ffffffffffff..",
        "................",
        "................",
        "................",
        "................",
    ])
    out["eraser_chalk"] = ascii_img([
        "................",
        "................",
        "................",
        "................",
        "...tttttttttt...",
        "..tnnnnnnnnnnT..",
        "..nnnNnnnnNnnn..",
        "..nnnnnnnnnnnn..",
        "..NNNNNNNNNNNN..",
        "..FFFFFFFFFFFF..",
        "..ffffffffffff..",
        "..fwfffffffwff..",
        "................",
        "................",
        "................",
        "................",
    ])

    # shapes & misc tools
    li = Img(16, 16)
    li.line(3, 12, 12, 3, P["w"], 2)
    li.rect(2, 12, 4, 14, P["y"])
    li.rect(12, 1, 14, 3, P["y"])
    out["tool_line"] = li

    r = Img(16, 16)
    r.rect(2, 3, 13, 12, P["w"])
    r.rect(4, 5, 11, 10, (0, 0, 0, 0))
    for y in range(5, 11):
        for x in range(4, 12):
            r.put(x, y, (0, 0, 0, 0))
    out["tool_rect"] = r

    e = Img(16, 16)
    e.ring(8, 8, 3.6, 6.2, P["w"])
    out["tool_ellipse"] = e

    out["tool_fill"] = ascii_img([
        "................",
        ".......ggg......",
        "......g...g.....",
        ".....g.....g....",
        "....lllllllll...",
        "....lwllllllgb..",
        "....lwlllllgbbb.",
        "....lwlllllgbbb.",
        "....lwlllllgbbb.",
        ".....lllllgg.b..",
        ".....lllllg..b..",
        "......llll...b..",
        ".............bb.",
        "..........bbbbbb",
        "...........bbbb.",
        "................",
    ])
    shapes = Img(16, 16)
    shapes.rect(1, 6, 8, 13, hexc("5aa0f0"))
    shapes.rect(2, 7, 7, 7, hexc("9ad0ff"))
    shapes.disc(10.5, 10.5, 4.2, hexc("f26b5a"))
    shapes.put(9, 8, hexc("ffb0a0"))
    for i in range(6):
        shapes.hline(8 - i, 8 + i, 1 + i, hexc("ffd45e"))
    shapes.hline(7, 8, 2, hexc("fff0b0"))
    out["tool_shapes"] = shapes
    out["tool_stamp"] = ascii_img([
        "................",
        "......nnnn......",
        ".....nttnnN.....",
        ".....nnnnNN.....",
        "......nnNN......",
        ".......nN.......",
        ".......nN.......",
        ".....tnnnNN.....",
        "...rrrrrrrrrr...",
        "..rpprrrrrrrRR..",
        "..rrrrrrrrrrRR..",
        "..RRRRRRRRRRRR..",
        "................",
        "..rr.rrr.r.rr...",
        "................",
        "................",
    ])
    skin = {**P, "s": hexc("f6cfa6"), "S": hexc("dca27a"), "h": hexc("fff0dc")}
    out["tool_pan"] = ascii_img([
        "................",
        ".......sS.......",
        "....sS.sS.sS....",
        "....sS.sS.sS....",
        "....sS.sS.sS.sS.",
        "....sS.sS.sS.sS.",
        "....sS.sS.sS.sS.",
        "....ssssssssssS.",
        ".s..ssshssssssS.",
        ".ss.sshsssssssS.",
        "..ssshssssssssS.",
        "...sssssssssss..",
        "....sssssssssS..",
        ".....ssssssss...",
        ".....sSSSSSSS...",
        "................",
    ], palette=skin)
    out["tool_pan_grab"] = ascii_img([
        "................",
        "................",
        "................",
        ".....ss.ss.ss...",
        "....sssssssssss.",
        "....sSsSsSsSsss.",
        "....ssshsssssss.",
        "..ssssssssssss..",
        ".sssssssssssssS.",
        ".sSSSSsssssssSS.",
        "..sssssssssssS..",
        "...sssssssssS...",
        ".....sssssss....",
        ".....sSSSSSS....",
        "................",
        "................",
    ], palette=skin)
    t = ascii_img([
        "................",
        "................",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "..ww...ww...ww..",
        ".......ww.......",
        ".......ww.......",
        ".......ww.......",
        ".......ww.......",
        ".......ww.......",
        ".......ww.......",
        ".....wwwwww.....",
        ".....wwwwww.....",
        "................",
    ])
    out["tool_text"] = t
    return out


def magnifier(sign=None):
    img = Img(16, 16)
    img.ring(6.5, 6.5, 3.6, 5.4, P["l"])
    img.disc(6.5, 6.5, 3.6, hexc("9fdcff", 255))
    img.put(5, 4, P["w"])
    img.put(4, 5, P["w"])
    for i in range(4):
        img.rect(10 + i, 10 + i, 11 + i, 11 + i, P["n"])
    if sign:
        img.hline(4, 9, 6, P["B"])
        img.hline(4, 9, 7, P["B"])
        if sign == "+":
            img.vline(6, 4, 9, P["B"])
            img.vline(7, 4, 9, P["B"])
    return img


def icon_ui():
    out = {}
    out["back"] = ascii_img([
        "................",
        "................",
        ".......w........",
        "......ww........",
        ".....www........",
        "....wwwwwwwwww..",
        "...wwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "....wwwwwwwwww..",
        ".....www........",
        "......ww........",
        ".......w........",
        "................",
    ])
    out["plus"] = ascii_img([
        "................",
        "................",
        "................",
        "......www.......",
        "......www.......",
        "......www.......",
        "...wwwwwwwww....",
        "...wwwwwwwww....",
        "...wwwwwwwww....",
        "......www.......",
        "......www.......",
        "......www.......",
        "................",
    ])
    out["close"] = ascii_img([
        "................",
        "................",
        "...ww......ww...",
        "...www....www...",
        "....www..www....",
        ".....wwwwww.....",
        "......wwww......",
        "......wwww......",
        ".....wwwwww.....",
        "....www..www....",
        "...www....www...",
        "...ww......ww...",
        "................",
    ])
    undo = ascii_img([
        "................",
        "................",
        "....w...........",
        "...ww...........",
        "..wwwwwwwww.....",
        ".wwwwwwwwwww....",
        "..wwwwwwwwwww...",
        "...ww......www..",
        "....w.......ww..",
        "............ww..",
        "............ww..",
        "...........www..",
        "......wwwwwww...",
        "......wwwwww....",
        "................",
    ])
    out["undo"] = undo
    out["redo"] = undo.flip_h()
    out["search"] = magnifier()
    out["zoom_in"] = magnifier("+")
    out["zoom_out"] = magnifier("-")
    out["bold"] = ascii_img([
        "................",
        "................",
        "...wwwwwww......",
        "...www..www.....",
        "...www..www.....",
        "...www..www.....",
        "...wwwwwww......",
        "...www...www....",
        "...www...www....",
        "...www...www....",
        "...wwwwwwww.....",
        "................",
    ])
    out["italic"] = ascii_img([
        "................",
        "................",
        "......wwwwww....",
        "........ww......",
        "........ww......",
        ".......ww.......",
        ".......ww.......",
        "......ww........",
        "......ww........",
        ".....ww.........",
        "...wwwwww.......",
        "................",
    ])
    out["underline"] = ascii_img([
        "................",
        "................",
        "....ww....ww....",
        "....ww....ww....",
        "....ww....ww....",
        "....ww....ww....",
        "....ww....ww....",
        "....ww....ww....",
        ".....wwwwww.....",
        "................",
        "...yyyyyyyyyy...",
        "................",
    ])
    out["strike"] = ascii_img([
        "................",
        "................",
        ".....wwwwww.....",
        "....ww....ww....",
        "....ww..........",
        ".....wwww.......",
        "..yyyyyyyyyyyy..",
        "........www.....",
        "..........ww....",
        "....ww....ww....",
        ".....wwwwww.....",
        "................",
    ])

    def lines(spec):
        img = Img(16, 16)
        for i, (x0, x1) in enumerate(spec):
            img.hline(x0, x1, 2 + i * 3, P["w"])
            img.hline(x0, x1, 3 + i * 3, P["w"])
        return img
    out["align_left"] = lines([(2, 13), (2, 9), (2, 13), (2, 8)])
    out["align_center"] = lines([(2, 13), (4, 11), (2, 13), (5, 10)])
    out["align_right"] = lines([(2, 13), (6, 13), (2, 13), (7, 13)])

    bl = Img(16, 16)
    for i in range(3):
        y = 2 + i * 4
        bl.rect(2, y, 3, y + 1, P["y"])
        bl.hline(6, 13, y, P["w"])
        bl.hline(6, 13, y + 1, P["w"])
    out["list_bullet"] = bl

    nl = ascii_img([
        "................",
        "..y.............",
        ".yy...wwwwwwww..",
        "..y...wwwwwwww..",
        "..y.............",
        ".yyy............",
        "................",
        ".yy.............",
        "...y..wwwwwwww..",
        "..y...wwwwwwww..",
        ".y..............",
        ".yyy............",
        "................",
    ])
    out["list_number"] = nl
    out["list_check"] = ascii_img([
        "................",
        ".wwwww.....G....",
        ".w...w....GG....",
        ".w.G.w.wwwwwww..",
        ".wGGGw.wwwwwww..",
        ".wwGww..........",
        "................",
        ".wwwww..........",
        ".w...w..........",
        ".w...w.wwwwwww..",
        ".w...w.wwwwwww..",
        ".wwwww..........",
        "................",
    ])
    out["quote"] = ascii_img([
        "................",
        "................",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "....ww....ww....",
        "...ww....ww.....",
        "..ww....ww......",
        "................",
    ])
    out["indent_more"] = ascii_img([
        "................",
        "..wwwwwwwwwwww..",
        "................",
        "..y....wwwwwww..",
        "..yy............",
        "..yyy..wwwwwww..",
        "..yy............",
        "..y....wwwwwww..",
        "................",
        "..wwwwwwwwwwww..",
        "................",
    ])
    out["indent_less"] = ascii_img([
        "................",
        "..wwwwwwwwwwww..",
        "................",
        "....y..wwwwwww..",
        "...yy...........",
        "..yyy..wwwwwww..",
        "...yy...........",
        "....y..wwwwwww..",
        "................",
        "..wwwwwwwwwwww..",
        "................",
    ])
    out["page_break"] = ascii_img([
        "................",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "................",
        ".yy.yy.yy.yy.yy.",
        "................",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "..wwwwwwwwwwww..",
        "................",
    ])
    out["text_color"] = ascii_img([
        "................",
        ".......ww.......",
        "......wwww......",
        "......wwww......",
        ".....ww..ww.....",
        ".....ww..ww.....",
        "....wwwwwwww....",
        "....wwwwwwww....",
        "...ww......ww...",
        "...ww......ww...",
        "................",
    ])
    out["highlight"] = ascii_img([
        "................",
        "..........dd....",
        ".........dddd...",
        "........yddddd..",
        ".......yyyddd...",
        "......yyyyyd....",
        ".....yyyyyy.....",
        "....gyyyyy......",
        "...ogggyy.......",
        "...oooog........",
        "................",
    ])
    out["font"] = ascii_img([
        "................",
        "................",
        "...www..........",
        "..ww.ww.........",
        "..ww.ww.........",
        ".ww...ww..wwww..",
        ".wwwwwww.....ww.",
        ".ww...ww..wwwww.",
        ".ww...ww.ww..ww.",
        ".ww...ww..wwwww.",
        "................",
    ])
    out["dots"] = ascii_img([
        "................",
        "................",
        "......www.......",
        "......www.......",
        "................",
        "................",
        "......www.......",
        "......www.......",
        "................",
        "................",
        "......www.......",
        "......www.......",
        "................",
    ])
    out["sort"] = ascii_img([
        "................",
        "....w...........",
        "...www..........",
        "..wwwww.........",
        "....w...........",
        "....w...........",
        "....w.....w.....",
        "....w.....w.....",
        "....w.....w.....",
        "..........w.....",
        "........wwwww...",
        ".........www....",
        "..........w.....",
        "................",
    ])
    out["folder"] = ascii_img([
        "................",
        "................",
        "..YYYY..........",
        ".YyyyyY.........",
        ".YyyyyyYYYYYYY..",
        ".YqqqqqqqqqqqY..",
        ".YyyyyyyyyyyyY..",
        ".YyyyyyyyyyyyY..",
        ".YyyyyyyyyyyyY..",
        ".YyyyyyyyyyyyY..",
        ".YyyyyyyyyyyyY..",
        ".YYYYYYYYYYYYY..",
        "................",
    ])

    def doc(band=None, inner=None):
        img = ascii_img([
            "................",
            "...wwwwwwww.....",
            "...wwwwwwwlw....",
            "...wwwwwwwllw...",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "...wwwwwwwwwww..",
            "................",
        ])
        if inner == "lines":
            for y in (6, 8, 10, 12):
                img.hline(5, 11, y, P["g"])
        if inner == "pic":
            img.rect(5, 6, 11, 11, P["c"])
            img.rect(8, 9, 11, 11, P["G"])
            img.rect(5, 10, 9, 11, P["E"])
            img.rect(6, 7, 6, 7, P["y"])
        if band:
            img.rect(2, 9, 12, 12, band)
            img.hline(4, 10, 10, P["w"])
            img.hline(4, 8, 11, P["w"])
        return img
    out["file_txt"] = doc(inner="lines")
    out["file_md"] = doc(band=P["m"], inner="lines")
    out["file_png"] = doc(inner="pic")
    out["file_pdf"] = doc(band=P["r"], inner="lines")
    out["copy"] = ascii_img([
        "................",
        ".wwwwwww........",
        ".wlllllw........",
        ".wlwwwwwwwww....",
        ".wlw.......w....",
        ".wlw.wwwww.w....",
        ".wlw.......w....",
        ".wwww.wwwww.w...",
        "....w.......w...",
        "....w.wwww..w...",
        "....w.......w...",
        "....wwwwwwwww...",
        "................",
    ])
    out["grid"] = ascii_img([
        "................",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "................",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "..wwww..wwww....",
        "................",
    ])
    out["panel"] = ascii_img([
        "................",
        ".wwwwwwwwwwwwww.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".w........wyyyw.",
        ".wwwwwwwwwwwwww.",
        "................",
    ])
    out["save"] = ascii_img([
        "................",
        "..bbbbbbbbbbb...",
        "..bblllllllbbb..",
        "..bblllllllbbb..",
        "..bblllllllbbb..",
        "..bbbbbbbbbbbb..",
        "..bbbbbbbbbbbb..",
        "..bbwwwwwwwwbb..",
        "..bbwwwwwwwwbb..",
        "..bbwwwwwwwwbb..",
        "..bbbbbbbbbbbb..",
        "................",
    ])
    out["trash"] = ascii_img([
        "................",
        "......llll......",
        "..llllllllllll..",
        "..gggggggggggg..",
        "...llllllllll...",
        "...lgllgllglll..",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "....llllllll....",
        "................",
    ])
    out["trash_open"] = ascii_img([
        "..........ll....",
        "........llll....",
        "......llllll....",
        "....lllllll.....",
        "...gggggg.......",
        "...llllllllll...",
        "...lgllgllglll..",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "...lgllgllgll...",
        "....llllllll....",
        "................",
    ])
    star_rows = [
        "................",
        ".......y........",
        ".......y........",
        "......yyy.......",
        "......yyy.......",
        "..yyyyyyyyyyy...",
        "...yyyyyyyyy....",
        "....yyyyyyy.....",
        "....yyyyyyy.....",
        "...yyyy.yyyy....",
        "...yyy...yyy....",
        "..yy.......yy...",
        "................",
    ]
    star = ascii_img(star_rows)
    for (x, y) in [(7, 4), (6, 6), (5, 7)]:
        star.put(x, y, P["q"])
    out["star_filled"] = star
    se = Img(16, 16)
    filled = ascii_img(star_rows)
    for y in range(16):
        for x in range(16):
            if filled.get(x, y)[3]:
                edge = any(filled.get(x + dx, y + dy)[3] == 0 for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)])
                if edge:
                    se.put(x, y, P["l"])
    out["star"] = se
    out["page_add"] = ascii_img([
        "................",
        "..wwwwwwww......",
        "..wwwwwwwlw.....",
        "..wwwwwwwllw....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwwwGGG....",
        "..wwwwwwwGGG....",
        "..wwwwwGGGGGGG..",
        "..wwwwwGGGGGGG..",
        "..wwwwwGGGGGGG..",
        ".........GGG....",
        ".........GGG....",
        "................",
    ])
    out["page_remove"] = ascii_img([
        "................",
        "..wwwwwwww......",
        "..wwwwwwwlw.....",
        "..wwwwwwwllw....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwwwwww....",
        "..wwwwwrrrrrrr..",
        "..wwwwwrrrrrrr..",
        "..wwwwwrrrrrrr..",
        "................",
    ])
    out["check"] = ascii_img([
        "................",
        "................",
        "............GG..",
        "...........GGG..",
        "..........GGG...",
        ".........GGG....",
        "..GG....GGG.....",
        "..GGG..GGG......",
        "...GGGGGG.......",
        "....GGGG........",
        ".....GG.........",
        "................",
    ])
    out["export"] = ascii_img([
        "................",
        ".......w........",
        "......www.......",
        ".....wwwww......",
        "....wwwwwww.....",
        "......www.......",
        "......www.......",
        "..ll..www..ll...",
        "..ll..www..ll...",
        "..ll.......ll...",
        "..llllllllllll..",
        "..llllllllllll..",
        "................",
    ])
    out["rename"] = diag_tool([
        (-11, -10, 0, (hexc("6a6a74"), hexc("3e3e46"), hexc("2a2a30"))),
        (-9, -8, lambda v: 0 if v == -9 else 1, tri(hexc("e8c48c"))),
        (-7, 5, 1, tri(hexc("f6c431"))),
        (6, 7, 1, (hexc("e6e6ea"), hexc("b0b0b8"), hexc("7a7a84"))),
        (8, 11, 1, tri(hexc("f39ab0"))),
    ])
    out["restore"] = ascii_img([
        "................",
        "......w.........",
        ".....www........",
        "....wwwww.......",
        "...wwwwwww......",
        ".....www........",
        ".....www........",
        ".....wwwwwwwww..",
        "......wwwwwwwww.",
        "............www.",
        "............www.",
        "...wwwwwwwwwww..",
        "...wwwwwwwwww...",
        "................",
    ])
    out["paper"] = ascii_img([
        "................",
        "...wwwwwwwww....",
        "...wwwwwwwwww...",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "...wwwwwwwwwww..",
        "................",
    ])
    out["info"] = ascii_img([
        "................",
        ".....bbbbbb.....",
        "....bbbwwbbb....",
        "...bbbbwwbbbb...",
        "...bbbbbbbbbb...",
        "...bbbwwwbbbb...",
        "...bbbbwwbbbb...",
        "...bbbbwwbbbb...",
        "....bbbwwbbb....",
        ".....bbbbbb.....",
        "................",
    ])
    out["keyboard"] = ascii_img([
        "................",
        "................",
        "................",
        ".llllllllllllll.",
        ".lwlwlwlwlwlwll.",
        ".llllllllllllll.",
        ".lwlwlwlwlwlwll.",
        ".llllllllllllll.",
        ".llwwwwwwwwwlll.",
        ".llllllllllllll.",
        "................",
    ])
    out["bell"] = ascii_img([
        "................",
        ".......yy.......",
        "......yyyy......",
        ".....yqyyyy.....",
        ".....yqyyyy.....",
        "....yqyyyyyy....",
        "....yyyyyyyy....",
        "....yyyyyyyy....",
        "...yyyyyyyyyy...",
        "..YYYYYYYYYYYY..",
        "......YYYY......",
        ".......YY.......",
        "................",
    ])
    out["page_prev"] = ascii_img([
        "................",
        "........ww......",
        ".......www......",
        "......www.......",
        ".....www........",
        "....www.........",
        "...www..........",
        "....www.........",
        ".....www........",
        "......www.......",
        ".......www......",
        "........ww......",
        "................",
    ])
    out["page_next"] = out["page_prev"].flip_h()
    out["warn"] = ascii_img([
        "................",
        ".......oo.......",
        "......oyyo......",
        "......oxxo......",
        ".....oyxxyo.....",
        ".....oyxxyo.....",
        "....oyyxxyyo....",
        "....oyyyyyyo....",
        "...oyyyxxyyyo...",
        "...oyyyxxyyyo...",
        "..oooooooooooo..",
        "................",
    ])
    out["notebook"] = ascii_img([
        "................",
        "..oooooooooo....",
        ".lOooooooooo....",
        "..oqqqqqqqqo....",
        ".lOqqqqqqqqo....",
        "..oooooooooo....",
        ".lOooooooooo....",
        "..oooooooooo....",
        ".lOooooooooo....",
        "..oooooooooo....",
        ".lOooooooooo....",
        "..OOOOOOOOOO....",
        "................",
    ])
    speaker = [
        "................",
        "......w.........",
        ".....ww.........",
        "....www.........",
        ".wwwwww.........",
        ".wwwwww.........",
        ".wwwwww.........",
        ".wwwwww.........",
        "....www.........",
        ".....ww.........",
        "......w.........",
        "................",
    ]
    on = ascii_img(speaker)
    for (x, y) in [(9, 4), (9, 7), (10, 5), (10, 6), (11, 2), (12, 3), (13, 4), (13, 5), (13, 6), (13, 7), (12, 8), (11, 9)]:
        on.put(x, y, P["w"])
    out["sound_on"] = on
    off = ascii_img(speaker)
    for i in range(5):
        off.put(9 + i, 3 + i, P["r"])
        off.put(13 - i, 3 + i, P["r"])
    out["sound_off"] = off
    out["pages"] = ascii_img([
        "................",
        "....wwwwwwww....",
        "....wllllllw....",
        "..wwwwwwwwwwl...",
        "..wllllllllwl...",
        "..wlwwwwwwlwl...",
        "..wllllllllwl...",
        "..wlwwwwwwlw....",
        "..wllllllllw....",
        "..wlwwwwlllw....",
        "..wllllllllw....",
        "..wwwwwwwwww....",
        "................",
    ])
    return out


def icon_types():
    out = {}

    def page(base, fold=True):
        img = Img(16, 16)
        img.rect(2, 1, 13, 14, base)
        if fold:
            for i in range(3):
                for j in range(3 - i):
                    img.put(13 - j, 1 + i, (0, 0, 0, 0))
            img.put(11, 1, shade(base, -40))
            img.put(11, 2, shade(base, -40))
            img.put(12, 3, shade(base, -40))
            img.put(13, 3, shade(base, -40))
            img.put(12, 2, shade(base, -40))
            img.put(11, 3, shade(base, -40))
        return img

    lined = page(hexc("fbf6e4"))
    for y in range(5, 14, 2):
        lined.hline(3, 12 if y > 3 else 10, y, hexc("8db8e0"))
    lined.vline(4, 2, 13, hexc("e07a7a"))
    out["type_lined"] = lined

    out["type_blank"] = page(hexc("ffffff"))

    grid = page(hexc("ffffff"))
    for y in range(3, 14, 3):
        grid.hline(2, 13, y, hexc("a8cbea"))
    for x in range(3, 14, 3):
        grid.vline(x, 1 if x < 11 else 4, 14, hexc("a8cbea"))
    out["type_grid"] = grid

    dots = page(hexc("fffdf6"))
    for y in range(4, 14, 3):
        for x in range(4, 13, 3):
            dots.put(x, y, hexc("8a8a8a"))
    out["type_dotted"] = dots

    sticky = Img(16, 16)
    sticky.rect(2, 2, 13, 13, hexc("ffe86a"))
    sticky.rect(2, 2, 13, 3, hexc("f5d84a"))
    for i in range(4):
        for j in range(4 - i):
            sticky.put(13 - j, 13 - i, (0, 0, 0, 0))
    for i in range(3):
        sticky.put(10 + i, 13 - i - 0, hexc("d8b830"))
        sticky.put(10 + i, 12 - i, hexc("e8c840"))
    sticky.put(10, 13, hexc("c8a828"))
    for y in (6, 8):
        sticky.hline(4, 10, y, hexc("b89a30"))
    out["type_sticky"] = sticky

    parch = Img(16, 16)
    parch.rect(3, 3, 12, 12, hexc("e7d3a4"))
    parch.rect(2, 1, 13, 3, hexc("cdb07a"))
    parch.hline(2, 13, 1, hexc("e2c890"))
    parch.rect(2, 12, 13, 14, hexc("cdb07a"))
    parch.hline(2, 13, 12, hexc("e2c890"))
    parch.vline(2, 1, 3, hexc("a88a52"))
    parch.vline(13, 12, 14, hexc("a88a52"))
    for y in (5, 7, 9):
        parch.hline(5, 10 if y != 9 else 8, y, hexc("8a6a3a"))
    out["type_parchment"] = parch

    wb = Img(16, 16)
    wb.rect(1, 2, 14, 11, hexc("a8aeb6"))
    wb.rect(2, 3, 13, 10, hexc("f6f8fa"))
    wb.line(3, 8, 6, 5, hexc("3a6ad0"))
    wb.line(6, 5, 8, 7, hexc("3a6ad0"))
    wb.line(8, 7, 11, 4, hexc("e04848"))
    wb.rect(3, 11, 12, 12, hexc("8a9098"))
    wb.vline(3, 12, 14, hexc("6a7078"))
    wb.vline(12, 12, 14, hexc("6a7078"))
    out["type_whiteboard"] = wb

    cb = Img(16, 16)
    cb.rect(1, 2, 14, 12, hexc("9a6a3a"))
    cb.hline(1, 14, 2, hexc("b8844e"))
    cb.rect(2, 3, 13, 11, hexc("2f5a40"))
    cb.line(3, 9, 5, 5, hexc("f0f0f0"))
    cb.line(5, 5, 7, 9, hexc("f0f0f0"))
    cb.hline(4, 6, 7, hexc("f0f0f0"))
    cb.line(9, 6, 12, 6, hexc("ffe680"))
    cb.line(9, 8, 11, 8, hexc("f0f0f0"))
    cb.rect(2, 12, 13, 13, hexc("7a5230"))
    cb.put(4, 12, hexc("ffffff"))
    cb.put(5, 12, hexc("ffffff"))
    out["type_chalkboard"] = cb

    bp = Img(16, 16)
    bp.rect(1, 2, 14, 13, hexc("2a5ea8"))
    for x in range(1, 15, 3):
        bp.vline(x, 2, 13, hexc("3a70bc"))
    for y in range(2, 14, 3):
        bp.hline(1, 14, y, hexc("3a70bc"))
    w = hexc("e8f2ff")
    bp.line(4, 8, 8, 4, w)
    bp.line(8, 4, 12, 8, w)
    bp.rect(5, 8, 11, 8, w)
    bp.vline(5, 8, 11, w)
    bp.vline(11, 8, 11, w)
    bp.hline(5, 11, 11, w)
    bp.vline(8, 9, 11, w)
    out["type_blueprint"] = bp
    return out


def icon_stamps(sword):
    out = {}
    out["heart"] = ascii_img([
        "................",
        "................",
        "...RRR...RRR....",
        "..RrrrR.RrrrR...",
        ".RrwwrrRrrrrrR..",
        ".RrwrrrrrrrrrR..",
        ".RrrrrrrrrrrrR..",
        ".RrrrrrrrrrrrR..",
        "..RrrrrrrrrrR...",
        "...RrrrrrrrR....",
        "....RrrrrrR.....",
        ".....RrrrR......",
        "......RrR.......",
        ".......R........",
        "................",
    ])
    out["star"] = ascii_img([
        "................",
        ".......Y........",
        "......YyY.......",
        "......YyY.......",
        ".....YyqyY......",
        "YYYYYYyqyYYYYYY.",
        ".YyyyyyyyyyyyY..",
        "..YyyyyyyyyyY...",
        "...YyyyyyyyY....",
        "...YyyyyyyyY....",
        "..YyyyyYyyyyY...",
        "..YyyyY.YyyyY...",
        ".YyyYY...YYyyY..",
        ".YYY.......YYY..",
        "................",
    ])
    rnd = random.Random(7)
    face = [
        "GGGGGGGG",
        "GGGGGGGG",
        "GxxGGxxG",
        "GxxGGxxG",
        "GGGxxGGG",
        "GGxxxxGG",
        "GGxxxxGG",
        "GGxGGxGG",
    ]
    cr = Img(16, 16)
    greens = [hexc("5bbd4f"), hexc("4aa63f"), hexc("6fd060"), hexc("3f8f37"), hexc("82d872")]
    for y in range(16):
        for x in range(16):
            ch = face[y // 2][x // 2]
            if ch == "x":
                cr.put(x, y, hexc("101410") if rnd.random() < 0.8 else hexc("243024"))
            else:
                cr.put(x, y, greens[rnd.randrange(len(greens))])
    out["creeper"] = cr
    out["diamond"] = ascii_img([
        "................",
        "................",
        "....CCCCCCC.....",
        "...CwwcccccC....",
        "..CwcccccccCC...",
        ".CccccccccccCC..",
        ".CCCCCCCCCCCCC..",
        "..CcccccccccC...",
        "...CcccccccC....",
        "....CcccccC.....",
        ".....CcccC......",
        "......CcC.......",
        ".......C........",
        "................",
    ])
    out["check"] = ascii_img([
        "................",
        "............EE..",
        "...........EGGE.",
        "..........EGGE..",
        ".........EGGE...",
        ".EE.....EGGE....",
        "EGGE...EGGE.....",
        ".EGGE.EGGE......",
        "..EGGEGGE.......",
        "...EGGGE........",
        "....EGE.........",
        ".....E..........",
        "................",
    ])
    out["cross"] = ascii_img([
        "................",
        "..RR.......RR...",
        ".RrrR.....RrrR..",
        ".RrrrR...RrrrR..",
        "..RrrrR.RrrrR...",
        "...RrrrRrrrR....",
        "....RrrrrrR.....",
        "....RrrrrrR.....",
        "...RrrrRrrrR....",
        "..RrrrR.RrrrR...",
        ".RrrrR...RrrrR..",
        ".RrrR.....RrrR..",
        "..RR.......RR...",
        "................",
    ])
    out["exclaim"] = ascii_img([
        "................",
        ".......OO.......",
        "......OyyO......",
        "......OyyO......",
        ".....OyxxyO.....",
        ".....OyxxyO.....",
        "....OyyxxyyO....",
        "....OyyxxyyO....",
        "...OyyyxxyyyO...",
        "...OyyyyyyyyO...",
        "..OyyyyxxyyyyO..",
        "..OyyyyxxyyyyO..",
        ".OyyyyyyyyyyyyO.",
        ".OOOOOOOOOOOOOO.",
        "................",
    ])
    out["question"] = ascii_img([
        "................",
        ".....BBBBBB.....",
        "...BBbbbbbbBB...",
        "..BbbbwwwwbbbB..",
        "..BbbwwbbwwbbB..",
        ".BbbbbbbbwwbbbB.",
        ".BbbbbbbwwbbbbB.",
        ".BbbbbbwwbbbbbB.",
        ".BbbbbbwwbbbbbB.",
        "..BbbbbbbbbbbB..",
        "..BbbbbwwbbbbB..",
        "...BBbbwwbbBB...",
        ".....BBBBBB.....",
        "................",
    ])
    out["arrow"] = ascii_img([
        "................",
        "................",
        "........OO......",
        "........OoO.....",
        "........OooO....",
        ".OOOOOOOOoooO...",
        ".OyyyyyyyyoooO..",
        ".OyyyyyyyyyoooO.",
        ".OyyyyyyyyoooO..",
        ".OOOOOOOOoooO...",
        "........OooO....",
        "........OoO.....",
        "........OO......",
        "................",
    ])
    sun = Img(16, 16)
    for a in range(8):
        ang = a * math.pi / 4
        x, y = 7.5 + math.cos(ang) * 6.3, 7.5 + math.sin(ang) * 6.3
        sun.rect(int(x), int(y), int(x), int(y), hexc("f08a24"))
        x, y = 7.5 + math.cos(ang) * 5.5, 7.5 + math.sin(ang) * 5.5
        sun.rect(int(x), int(y), int(x), int(y), hexc("f08a24"))
    sun.disc(8, 8, 4.4, hexc("ffd24a"))
    sun.put(6, 6, hexc("fff6c8"))
    sun.put(7, 5, hexc("fff6c8"))
    out["sun"] = sun.outline(hexc("a85a12"))
    smile = Img(16, 16)
    smile.disc(8, 8, 6.6, hexc("ffd24a"))
    smile.rect(5, 5, 5, 7, hexc("3a2a10"))
    smile.rect(10, 5, 10, 7, hexc("3a2a10"))
    smile.hline(6, 9, 11, hexc("3a2a10"))
    smile.put(5, 10, hexc("3a2a10"))
    smile.put(10, 10, hexc("3a2a10"))
    smile.put(4, 9, hexc("f7a0a0"))
    smile.put(11, 9, hexc("f7a0a0"))
    out["smile"] = smile.outline(hexc("a8780a"))
    out["sword"] = sword.outline()
    pick = Img(16, 16)
    pick.line(3, 13, 11, 5, hexc("7a5230"), 2)
    head = ascii_img([
        "................",
        "....ccCCCC......",
        "...cwccccCCC....",
        "........CcCCC...",
        "........CCcCC...",
        ".........CCcC...",
        "..........CCcC..",
        "...........CcC..",
        "...........CcC..",
        "............C...",
    ])
    pick.paste(head, 0, 0)
    out["pickaxe"] = pick.outline()
    for k in list(out):
        if k not in ("sun", "smile", "sword", "pickaxe", "creeper"):
            pass
    return out


def menu_icon():
    img = ascii_img([
        "...............",
        "...wwwwwwwww...",
        "..lwwwwwwwwwr..",
        "..wwbbbbbbbwr..",
        "..lwwwwwwwwwr..",
        "..wwbbbbbbwwr..",
        "..lwwwwwwwwwr..",
        "..wwbbbbbbbwr..",
        "..lwwwwwwwwwr..",
        "..wwbbbbbwwwr..",
        "..lwwwwwwwwwr..",
        "...wwwwwwwwwr..",
        "....rrrrrrrrr..",
        "...............",
        "...............",
    ], 15, 15)
    # pencil across the corner
    pencil = diag_tool([
        (-11, -10, 0, (hexc("6a6a74"), hexc("3e3e46"), hexc("2a2a30"))),
        (-9, -8, lambda v: 0 if v == -9 else 1, tri(hexc("e8c48c"))),
        (-7, 5, 1, tri(hexc("f6c431"))),
        (6, 7, 1, (hexc("e6e6ea"), hexc("b0b0b8"), hexc("7a7a84"))),
        (8, 11, 1, tri(hexc("f39ab0"))),
    ], size=16)
    small = Img(15, 15)
    for y in range(15):
        for x in range(15):
            c = pencil.get(int(x * 16 / 11) - 5, int(y * 16 / 11) - 6)
            if c[3]:
                small.put(x, y, c)
    small = small.outline(hexc("2b2b2b"))
    img.paste(small, 0, 0)
    return img


# --------------------------------------------------------------------------- logo

FONT5 = {
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###"],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."],
    "L": ["#....", "#....", "#....", "#....", "#....", "#....", "#####"],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####"],
}


def logo():
    word = "SCRIBBLE"
    s = 2
    widths = [len(FONT5[ch][0]) for ch in word]
    w = sum(widths) * s + (len(word) - 1) * s + 6
    h = 7 * s + 12
    base = Img(w, h)
    x = 2
    top = 2
    for ch in word:
        glyph = FONT5[ch]
        for gy, row in enumerate(glyph):
            for gx, cc in enumerate(row):
                if cc == "#":
                    for oy in range(s):
                        for ox in range(s):
                            py = top + gy * s + oy
                            t = (py - top) / (7 * s - 1)
                            col = (int(255 - 12 * t), int(226 - 90 * t), int(110 - 80 * t), 255)
                            base.put(x + gx * s + ox, py, col)
        x += len(glyph[0]) * s + s
    # highlight on the top row of each glyph pixel run
    for yy in range(h):
        for xx in range(w):
            if base.get(xx, yy)[3] and not base.get(xx, yy - 1)[3]:
                base.put(xx, yy, hexc("fff4c0"))
    shadow = Img(w, h)
    for yy in range(h):
        for xx in range(w):
            if base.get(xx, yy)[3]:
                shadow.put(xx + 1, yy + 1, hexc("3a2412"))
                shadow.put(xx + 2, yy + 2, hexc("1a1008", 140))
    out = Img(w, h)
    out.paste(shadow, 0, 0)
    out.paste(base.outline(hexc("3a2412")), 0, 0)
    # squiggle underline
    sq_y = top + 7 * s + 4
    prev = None
    for xx in range(3, w - 4):
        yy = sq_y + int(round(math.sin(xx / 3.2) * 1.6))
        out.put(xx, yy, hexc("5aa8ff"))
        out.put(xx, yy + 1, hexc("2a6ac8"))
        if prev is not None and abs(prev - yy) > 1:
            out.put(xx, (prev + yy) // 2, hexc("5aa8ff"))
        prev = yy
    return out


# --------------------------------------------------------------------------- nine-slice UI

def bevel(w, h, fill, hi, sh, outline=OUTLINE, cut=True, hi_w=1, sh_w=1):
    img = Img(w, h)
    img.rect(0, 0, w - 1, h - 1, outline)
    img.rect(1, 1, w - 2, h - 2, fill)
    for i in range(hi_w):
        img.hline(1, w - 2 - i, 1 + i, hi)
        img.vline(1 + i, 1, h - 2 - i, hi)
    for i in range(sh_w):
        img.hline(1 + i, w - 2, h - 2 - i, sh)
        img.vline(w - 2 - i, 1 + i, h - 2, sh)
    if cut:
        for (x, y) in [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]:
            img.put(x, y, (0, 0, 0, 0))
    return img


CREAM = hexc("fff3d6")
CREAM_HI = hexc("fffbee")
CREAM_LIP = hexc("e3c99a")


def rounded_mask(w, h, r):
    cut = set()
    for i in range(r):
        for j in range(r - i):
            for (x, y) in [(j, i), (w - 1 - j, i), (j, h - 1 - i), (w - 1 - j, h - 1 - i)]:
                cut.add((x, y))
    return lambda x, y: 0 <= x < w and 0 <= y < h and (x, y) not in cut


def toon_box(w, h, fill, hi, lip, outline=None, radius=2, lip_h=2, hi_h=1):
    """Rounded, outlined 'toy' box: highlight row on top, darker lip at the bottom."""
    outline = outline or INK
    inside = rounded_mask(w, h, radius)
    img = Img(w, h)
    for y in range(h):
        for x in range(w):
            if not inside(x, y):
                continue
            edge = any(not inside(x + dx, y + dy) for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)])
            if edge:
                img.put(x, y, outline)
            elif lip_h > 0 and y >= h - 1 - lip_h:
                img.put(x, y, lip)
            elif y <= hi_h:
                img.put(x, y, hi)
            else:
                img.put(x, y, fill)
    return img


def soft_shadow(w, h, inset, radius, strength):
    img = Img(w, h)
    for y in range(h):
        for x in range(w):
            dx = max(inset + radius - x - 0.5, 0, x + 0.5 - (w - inset - radius))
            dy = max(inset + radius - y - 0.5, 0, y + 0.5 - (h - inset - radius))
            d = math.sqrt(dx * dx + dy * dy) - radius
            t = max(0.0, min(1.0, 1 - d / inset))
            a = int(strength * t * t * (3 - 2 * t))
            if a > 0:
                img.put(x, y, (40, 20, 8, a))
    return img


def ui_sprites():
    toon_box(16, 16, CREAM, CREAM_HI, CREAM_LIP, radius=3, lip_h=3).save("ui/panel", nine(16, 16, 5))
    toon_box(16, 16, hexc("8b5a33"), hexc("a8744a"), hexc("5e3a1e"), radius=3, lip_h=3).save("ui/panel_dark", nine(16, 16, 5))
    toon_box(16, 16, hexc("8b5a33"), hexc("a8744a"), hexc("5e3a1e"), radius=0, lip_h=2).save("ui/toolbar", nine(16, 16, 3))
    toon_box(16, 16, CREAM, CREAM_HI, CREAM_LIP, radius=0, lip_h=2).save("ui/toolbar_light", nine(16, 16, 3))
    toon_box(16, 16, CREAM, CREAM_HI, CREAM_LIP, radius=2, lip_h=2).save("ui/button", nine(16, 16, 4))
    toon_box(16, 16, hexc("fffaea"), hexc("ffffff"), hexc("f0d49e"), radius=2, lip_h=2).save("ui/button_hover", nine(16, 16, 4))
    toon_box(16, 16, hexc("ffb347"), hexc("ffd08a"), hexc("d9822b"), radius=2, lip_h=1).save("ui/button_selected", nine(16, 16, 4))
    toon_box(16, 16, hexc("ebe0ca"), hexc("f3ebda"), hexc("d6c6a6"), outline=hexc("a48c70"), radius=2, lip_h=2).save("ui/button_disabled", nine(16, 16, 4))
    toon_box(16, 16, hexc("fffdf6"), hexc("ebdcbe"), hexc("fffdf6"), radius=2, lip_h=0, hi_h=1).save("ui/field", nine(16, 16, 3))
    toon_box(16, 16, hexc("fffdf6"), hexc("ebdcbe"), hexc("fffdf6"), outline=hexc("e07a2a"), radius=2, lip_h=0, hi_h=1).save("ui/field_focused", nine(16, 16, 3))
    toon_box(16, 13, CREAM, CREAM_HI, CREAM_LIP, radius=4, lip_h=2).save("ui/chip", nine(16, 13, 5))
    toon_box(16, 13, hexc("fffaea"), hexc("ffffff"), hexc("f0d49e"), radius=4, lip_h=2).save("ui/chip_hover", nine(16, 13, 5))
    toon_box(16, 13, hexc("ffb347"), hexc("ffd08a"), hexc("d9822b"), radius=4, lip_h=2).save("ui/chip_selected", nine(16, 13, 5))
    toon_box(6, 16, hexc("6e4426"), hexc("5a361c"), hexc("6e4426"), radius=1, lip_h=0).save("ui/scroll_track", nine(6, 16, 2))
    toon_box(6, 16, CREAM, CREAM_HI, CREAM_LIP, radius=1, lip_h=1).save("ui/scroll_thumb", nine(6, 16, 2))
    toon_box(16, 6, hexc("d9c29a"), hexc("c4aa7c"), hexc("d9c29a"), radius=1, lip_h=0).save("ui/slider_track", nine(16, 6, 2))
    toon_box(8, 12, hexc("ffb347"), hexc("ffd08a"), hexc("d9822b"), radius=2, lip_h=2).save("ui/slider_knob")
    inside = rounded_mask(12, 12, 2)
    sw = Img(12, 12)
    for y in range(12):
        for x in range(12):
            if inside(x, y) and any(not inside(x + dx, y + dy) for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]):
                sw.put(x, y, INK)
    sw.hline(2, 9, 1, (255, 255, 255, 90))
    sw.save("ui/swatch", nine(12, 12, 3))
    ss = Img(12, 12)
    for y in range(12):
        for x in range(12):
            if inside(x, y):
                edge = any(not inside(x + dx, y + dy) for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)])
                ring = not edge and any(not inside(x + dx, y + dy) for dx, dy in [(2, 0), (-2, 0), (0, 2), (0, -2)])
                if edge:
                    ss.put(x, y, INK)
                elif ring:
                    ss.put(x, y, hexc("ffffff"))
    ss.save("ui/swatch_selected", nine(12, 12, 3))
    toon_box(16, 12, hexc("ffb347"), hexc("ffd08a"), hexc("d9822b"), radius=3, lip_h=1).save("ui/badge", nine(16, 12, 4))
    toon_box(16, 16, hexc("fffbf0"), hexc("ffffff"), hexc("e8d6b4"), radius=3, lip_h=3).save("ui/card", nine(16, 16, 5))
    toon_box(16, 16, hexc("fffdf7"), hexc("ffffff"), hexc("f2d7a0"), outline=hexc("e07a2a"), radius=3, lip_h=3).save("ui/card_hover", nine(16, 16, 5))
    soft_shadow(32, 32, 10, 4, 110).save("ui/shadow", nine(32, 32, 14))
    toon_box(16, 16, hexc("fff8e4"), hexc("ffffff"), hexc("e8cf9e"), radius=4, lip_h=3).save("ui/notify", nine(16, 16, 6))

    logo().save("ui/logo")
    pencil = diag_tool([
        (-11, -10, 0, (hexc("6a6a74"), hexc("3e3e46"), hexc("2a2a30"))),
        (-9, -8, lambda v: 0 if v == -9 else 1, tri(hexc("e8c48c"))),
        (-7, 5, 1, tri(hexc("f6c431"))),
        (6, 7, 1, (hexc("e6e6ea"), hexc("b0b0b8"), hexc("7a7a84"))),
        (8, 11, 1, tri(hexc("f39ab0"))),
    ]).outline()
    pencil.save("ui/pencil")


# --------------------------------------------------------------------------- tiled surfaces

def value_noise(size, cells, seed):
    rnd = random.Random(seed)
    lat = [[rnd.random() for _ in range(cells)] for _ in range(cells)]

    def smooth(t):
        return t * t * (3 - 2 * t)

    out = [[0.0] * size for _ in range(size)]
    for y in range(size):
        for x in range(size):
            fx = x / size * cells
            fy = y / size * cells
            x0, y0 = int(fx) % cells, int(fy) % cells
            x1, y1 = (x0 + 1) % cells, (y0 + 1) % cells
            tx, ty = smooth(fx - int(fx)), smooth(fy - int(fy))
            a = lat[y0][x0] * (1 - tx) + lat[y0][x1] * tx
            b = lat[y1][x0] * (1 - tx) + lat[y1][x1] * tx
            out[y][x] = a * (1 - ty) + b * ty
    return out


def surfaces():
    rnd = random.Random(11)

    # desk: warm honey oak planks, soft and low-noise (cozy, toon-ish)
    desk = Img(64, 64)
    n = value_noise(64, 4, 3)
    tones = [(168, 109, 61), (163, 104, 56), (173, 115, 66), (159, 101, 54)]
    seams = [11, 43, 27, 53]
    for row in range(4):
        base = tones[row]
        seam = seams[row]
        for y in range(row * 16, row * 16 + 16):
            for x in range(64):
                c = shade(base, int((n[y][x] - 0.5) * 8))
                ly = y - row * 16
                if ly == 0:
                    c = shade(base, 14)
                elif ly == 15:
                    c = (107, 66, 35, 255)
                elif ly == 14:
                    c = shade(base, -8)
                if x == seam and ly != 15:
                    c = (112, 70, 38, 255)
                elif x == seam + 1 and 0 < ly < 15:
                    c = shade(base, 10)
                desk.put(x, y, c)
        for k in range(3):
            gy = row * 16 + 3 + k * 4 + rnd.randint(0, 1)
            gx = rnd.randint(0, 63)
            for i in range(rnd.randint(8, 18)):
                xx = (gx + i) % 64
                if xx != seam:
                    desk.put(xx, gy, shade(desk.get(xx, gy), -9))
    desk.save("bg/desk", tile(64, 64))

    shelf = Img(64, 64)
    for y in range(64):
        for x in range(64):
            shelf.put(x, y, shade(desk.get(x, y), -55))
    shelf.save("bg/desk_dark", tile(64, 64))

    cork = Img(32, 32)
    n = value_noise(32, 4, 23)
    for y in range(32):
        for x in range(32):
            c = shade((201, 150, 96), int((n[y][x] - 0.5) * 16))
            r = rnd.random()
            if r < 0.10:
                c = shade(c, -26)
            elif r < 0.16:
                c = shade(c, 18)
            cork.put(x, y, c)
    cork.save("bg/cork", tile(32, 32))

    grain = Img(64, 64)
    for y in range(64):
        for x in range(64):
            r = rnd.random()
            if r < 0.10:
                grain.put(x, y, (0, 0, 0, 12))
            elif r < 0.17:
                grain.put(x, y, (255, 255, 255, 30))
            elif r < 0.19:
                grain.put(x, y, (90, 70, 40, 18))
    for _ in range(18):  # fibers
        x, y = rnd.randrange(64), rnd.randrange(64)
        L = rnd.randint(3, 7)
        horiz = rnd.random() < 0.5
        for i in range(L):
            grain.put((x + (i if horiz else 0)) % 64, (y + (0 if horiz else i)) % 64, (80, 60, 30, 14))
    grain.save("bg/paper_grain", tile(64, 64))

    wb = Img(64, 64)
    n = value_noise(64, 4, 5)
    for y in range(64):
        for x in range(64):
            v = 244 + int((n[y][x] - 0.5) * 6)
            c = (v - 1, v + 1, min(255, v + 3), 255)
            d = (x + y) % 64
            if 8 <= d <= 20:
                c = shade(c, 4)
            if rnd.random() < 0.012:
                c = shade(c, -10)
            wb.put(x, y, c)
    # faint ghost marker smear
    for i in range(20):
        x = 10 + i
        y = 40 + int(math.sin(i / 3) * 3)
        wb.put(x % 64, y, shade(wb.get(x % 64, y), -6))
    wb.save("bg/whiteboard", tile(64, 64))

    cb = Img(64, 64)
    n = value_noise(64, 4, 9)
    n2 = value_noise(64, 16, 10)
    for y in range(64):
        for x in range(64):
            base = (40, 68, 52)
            d = int((n[y][x] - 0.5) * 10 + (n2[y][x] - 0.5) * 6)
            c = shade(base, d)
            if n[y][x] > 0.72:
                c = shade(c, 6)  # chalk dust ghost
            if rnd.random() < 0.03:
                c = shade(c, rnd.choice([-6, 7]))
            cb.put(x, y, c)
    cb.save("bg/chalkboard", tile(64, 64))

    bp = Img(64, 64)
    n = value_noise(64, 8, 13)
    for y in range(64):
        for x in range(64):
            d = int((n[y][x] - 0.5) * 8)
            c = shade((30, 80, 150), d)
            if rnd.random() < 0.02:
                c = shade(c, 6)
            bp.put(x, y, c)
    bp.save("bg/blueprint", tile(64, 64))

    pa = Img(64, 64)
    n = value_noise(64, 4, 17)
    n2 = value_noise(64, 16, 18)
    for y in range(64):
        for x in range(64):
            d = int((n[y][x] - 0.5) * 22 + (n2[y][x] - 0.5) * 10)
            c = shade((232, 211, 163), d)
            if rnd.random() < 0.015:
                c = shade(c, -24)
            pa.put(x, y, c)
    pa.save("bg/parchment", tile(64, 64))


def frames():
    # whiteboard aluminium frame
    s = 16
    f = Img(s, s)
    alu = [hexc("5e646c"), hexc("e4e8ec"), hexc("cfd4da"), hexc("b4bbc3"), hexc("8e959e"), hexc("6a7079")]
    for i, c in enumerate(alu):
        for y in range(i, s - i):
            for x in range(i, s - i):
                if x in (i, s - 1 - i) or y in (i, s - 1 - i):
                    f.put(x, y, c)
    for y in range(6, s - 6):
        for x in range(6, s - 6):
            f.put(x, y, (0, 0, 0, 0))
    for (cx, cy) in [(0, 0), (s - 5, 0), (0, s - 5), (s - 5, s - 5)]:
        f.rect(cx, cy, cx + 4, cy + 4, hexc("3a3a40"))
        f.rect(cx + 1, cy + 1, cx + 3, cy + 3, hexc("54545c"))
        f.put(cx + 1, cy + 1, hexc("74747e"))
    f.save("frame/whiteboard", nine(s, s, 6))

    # chalkboard wooden frame
    w = Img(s, s)
    rnd = random.Random(21)
    for y in range(s):
        for x in range(s):
            edge = min(x, y, s - 1 - x, s - 1 - y)
            if edge >= 6:
                continue
            horiz = min(y, s - 1 - y) <= min(x, s - 1 - x)
            g = (x if horiz else y)
            base = hexc("9a6a3a")
            c = shade(base, int(math.sin(g * 1.3 + (y if horiz else x) * 0.7) * 6) + rnd.randint(-4, 4))
            if edge == 0:
                c = hexc("3a2410")
            elif edge == 1:
                c = shade(c, 22)
            elif edge == 5:
                c = hexc("4a2e14")
            elif edge == 4:
                c = shade(c, -18)
            w.put(x, y, c)
    # mitre lines
    for i in range(6):
        w.put(i, i, hexc("6a4422"))
        w.put(s - 1 - i, i, hexc("6a4422"))
        w.put(i, s - 1 - i, hexc("6a4422"))
        w.put(s - 1 - i, s - 1 - i, hexc("6a4422"))
    w.save("frame/chalkboard", nine(s, s, 6))

    # trays
    ct = Img(16, 8)
    for y in range(8):
        for x in range(16):
            c = shade(hexc("8a5a2e"), int(math.sin(x * 0.9) * 4))
            if y == 0:
                c = hexc("c08a52")
            if y == 1:
                c = hexc("a87440")
            if y >= 6:
                c = hexc("4a2e14") if y == 7 else hexc("6a4422")
            ct.put(x, y, c)
    ct.save("deco/chalk_tray", nine(16, 8, 3))
    mt = Img(16, 8)
    for y in range(8):
        for x in range(16):
            c = [hexc("eef1f4"), hexc("d4d9de"), hexc("c0c6cc"), hexc("b0b7be"), hexc("a2a9b1"), hexc("8e959e"), hexc("6a7079"), hexc("4a5058")][y]
            mt.put(x, y, c)
    mt.save("deco/marker_tray", nine(16, 8, 3))

    # chalk sticks + felt eraser lying on the tray
    cs = Img(48, 6)
    colors = [hexc("f4f4f4"), hexc("ffe680"), hexc("ff9ab8"), hexc("8fd0ff")]
    x = 0
    for c in colors:
        cs.rect(x, 3, x + 7, 5, c)
        cs.hline(x, x + 7, 3, shade(c, 12))
        cs.hline(x, x + 7, 5, shade(c, -30))
        x += 10
    cs.rect(40, 0, 47, 3, hexc("a06c3a"))
    cs.hline(40, 47, 0, hexc("c08a52"))
    cs.rect(40, 4, 47, 5, hexc("74747f"))
    cs.save("deco/chalk_sticks")

    mk = Img(52, 6)
    mcols = [hexc("2a2a30"), hexc("3a6ad0"), hexc("d83a3a"), hexc("3aa040")]
    x = 0
    for c in mcols:
        mk.rect(x, 2, x + 9, 5, hexc("f2f2f4"))
        mk.hline(x, x + 9, 5, hexc("b0b0b8"))
        mk.rect(x + 7, 2, x + 9, 5, c)
        mk.put(x, 3, c)
        mk.put(x, 4, c)
        x += 12
    mk.rect(48, 0, 51, 3, hexc("234a8f"))
    mk.rect(48, 4, 51, 5, hexc("c6c6c6"))
    mk.save("deco/markers")

    # notebook spiral loop (8 wide, 14 tall; the page top edge is at y=6)
    sp = Img(8, 14)
    sp.rect(2, 8, 5, 11, hexc("2a2a2e"))
    sp.rect(3, 9, 4, 10, hexc("101012"))
    sp.put(2, 8, (0, 0, 0, 0))
    sp.put(5, 8, (0, 0, 0, 0))
    sp.put(2, 11, (0, 0, 0, 0))
    sp.put(5, 11, (0, 0, 0, 0))
    wire = [(1, 9), (1, 8), (1, 7), (1, 6), (1, 5), (1, 4), (2, 3), (2, 2), (3, 1), (4, 1), (5, 2), (5, 3), (6, 4), (6, 5), (5, 6), (4, 7), (4, 8)]
    for i, (x, y) in enumerate(wire):
        sp.put(x, y, hexc("d8dce2") if i < 8 else hexc("9aa0a8"))
        sp.put(x + 1, y, hexc("8a9098") if i < 8 else hexc("6a7078"))
    sp.save("deco/spiral")

    ring = ascii_img([
        "...dllllld....",
        "..dlwwwwwlld..",
        ".dlw.....wlld.",
        ".dl.......lld.",
        "..dlllllllld..",
        "...ddddddddd..",
    ], 14, 6, {**P, "d": hexc("6a7078"), "l": hexc("b8bec6"), "w": hexc("f4f6f8")})
    ring.save("deco/ring")

    hole = ascii_img([
        "..dddd..",
        ".dDDDDd.",
        "dDhhhhDd",
        "dDhhhhDl",
        "dDhhhhDl",
        "dDhhhhll",
        ".dDDlll.",
        "..llll..",
    ], 8, 8, {**P, "D": hexc("1a1a1e"), "h": hexc("2c2c32"), "d": hexc("8a8a90", 160), "l": hexc("ffffff", 120)})
    hole.save("deco/hole")

    tp = Img(36, 10)
    rnd = random.Random(31)
    for y in range(10):
        for x in range(36):
            jag = (x < 2 and (y + x) % 3 == 0) or (x > 33 and (y + x) % 3 == 1)
            if jag:
                continue
            c = hexc("fff4b0", 170) if (x // 4) % 2 == 0 else hexc("ffe880", 170)
            if y == 0:
                c = hexc("ffffff", 150)
            tp.put(x, y, c)
    tp.save("deco/tape")

    cbx = Img(8, 8)
    cbx.rect(0, 0, 7, 7, hexc("6a6a72"))
    cbx.rect(1, 1, 6, 6, hexc("ffffff", 120))
    cbx.save("deco/checkbox")
    cbc = Img(9, 9)
    cbc.rect(0, 1, 7, 8, hexc("6a6a72"))
    cbc.rect(1, 2, 6, 7, hexc("ffffff", 120))
    for (x, y) in [(1, 4), (2, 5), (3, 6), (4, 5), (5, 4), (6, 3), (7, 2), (8, 1), (2, 4), (3, 5), (4, 4), (5, 3), (6, 2), (7, 1)]:
        cbc.put(x, y, hexc("2f9a3a"))
    cbc.save("deco/checkbox_checked")

    pin = Img(8, 8)
    pin.disc(4, 3.5, 3.2, hexc("e04848"))
    pin.put(3, 2, hexc("ffb0b0"))
    pin.rect(4, 6, 4, 7, hexc("8a8a8a"))
    pin.outline(hexc("6a1a1a")).save("deco/pin")


# --------------------------------------------------------------------------- main

NO_CENTER = {"text_color", "highlight"}
# monochrome "glyph" icons get warm walnut ink instead of stark white, so the set feels cozy and cohesive
GLYPHS = {"align_left", "align_center", "align_right", "back", "plus", "close", "undo", "redo", "bold", "italic",
          "underline", "strike", "list_bullet", "list_number", "list_check", "quote", "indent_more", "indent_less",
          "page_break", "dots", "sort", "sound_on", "sound_off", "grid", "restore", "page_prev", "page_next", "text_color", "tool_text",
          "tool_line", "tool_rect", "tool_ellipse", "panel", "pages", "star"}
GLYPH_FILL = (104, 68, 44, 255)
GLYPH_HI = (140, 96, 62, 255)


def warm_glyph(img):
    out = Img(img.w, img.h)
    for y in range(img.h):
        for x in range(img.w):
            c = img.get(x, y)
            if c[3] and ((c[0] > 240 and c[1] > 240 and c[2] > 240) or c[:3] == (198, 198, 198)):
                above = img.get(x, y - 1)
                top = not (above[3] and (above[0] > 190 and above[1] > 190 and above[2] > 190))
                out.put(x, y, GLYPH_HI if top else GLYPH_FILL)
            else:
                out.put(x, y, c)
    return out


def centered(img):
    xs = [x for y in range(img.h) for x in range(img.w) if img.get(x, y)[3]]
    ys = [y for y in range(img.h) for x in range(img.w) if img.get(x, y)[3]]
    if not xs:
        return img
    dx = (img.w - (max(xs) - min(xs) + 1)) // 2 - min(xs)
    dy = (img.h - (max(ys) - min(ys) + 1)) // 2 - min(ys)
    out = Img(img.w, img.h)
    out.paste(img, dx, dy)
    return out


def main():
    os.makedirs(OUT, exist_ok=True)
    tools = icon_tools()
    sword = tools.pop("_sword")
    for name, img in tools.items():
        if name in GLYPHS:
            centered(warm_glyph(img)).save("icon/" + name)
        else:
            centered(img.outline()).save("icon/" + name)
    for name, img in icon_ui().items():
        if name == "font":
            continue
        o = warm_glyph(img) if name in GLYPHS else img.outline()
        (o if name in NO_CENTER else centered(o)).save("icon/" + name)
    for name, img in icon_types().items():
        centered(img.outline()).save("icon/" + name)
    for name, img in icon_stamps(sword).items():
        centered(img).save("stamp/" + name)
    menu_icon().save("icon/scribble")
    ui_sprites()
    surfaces()
    frames()
    print("assets written to", os.path.normpath(OUT))


if __name__ == "__main__":
    main()
