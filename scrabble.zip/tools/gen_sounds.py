"""
Scribble sound generator.

Synthesizes every Scribble sound effect procedurally (shaped noise, tones and envelopes) and writes them as OGG
Vorbis into src/main/resources/assets/scribble/sounds, plus sounds.json.

Needs numpy and soundfile:

    python -m pip install numpy soundfile
    python tools/gen_sounds.py
"""
import json
import os

import numpy as np
import soundfile as sf

SR = 44100
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "scribble", "sounds")
rng = np.random.default_rng(1234)


# --------------------------------------------------------------------------- building blocks

def n_of(sec):
    return int(SR * sec)


def noise(n):
    return rng.standard_normal(n)


def band(x, lo, hi, soft=0.25):
    """Band-limits a signal with smooth spectral edges (FFT mask)."""
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    lo_edge = np.clip((f - lo * (1 - soft)) / max(1.0, lo * soft * 2), 0, 1)
    hi_edge = np.clip((hi * (1 + soft) - f) / max(1.0, hi * soft * 2), 0, 1)
    return np.fft.irfft(spec * lo_edge * hi_edge, len(x))


def tilt(x, db_per_octave):
    spec = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    f[0] = 1
    gain = (f / 1000.0) ** (db_per_octave / 6.02)
    return np.fft.irfft(spec * gain, len(x))


def env(n, attack, release, curve=1.0):
    t = np.arange(n) / SR
    dur = n / SR
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    r = np.clip((dur - t) / max(release, 1e-4), 0, 1)
    return (a * r) ** curve


def decay(n, tau):
    return np.exp(-np.arange(n) / SR / tau)


def sample_hold(n, rate, lo=0.2, hi=1.0, power=2.0):
    """Rough random amplitude steps: gives scratchy grain."""
    step = max(1, int(SR / rate))
    vals = rng.uniform(lo, hi, n // step + 2) ** power
    out = np.repeat(vals, step)[:n]
    # tiny smoothing so it isn't clicky
    k = max(1, step // 4)
    return np.convolve(out, np.ones(k) / k, mode="same")


def sine(n, f0, f1=None, phase=0.0):
    f1 = f0 if f1 is None else f1
    if np.isscalar(f0) and np.isscalar(f1):
        freq = np.geomspace(max(f0, 1), max(f1, 1), n) if f0 != f1 else np.full(n, f0)
    else:
        freq = f0
    return np.sin(2 * np.pi * np.cumsum(freq) / SR + phase)


def strokes(n, count, sharpness=1.5):
    """Back-and-forth rubbing envelope."""
    t = np.linspace(0, count * np.pi, n)
    return np.abs(np.sin(t)) ** sharpness


def impulses(n, count, width=0.002):
    out = np.zeros(n)
    w = n_of(width)
    for _ in range(count):
        i = rng.integers(0, max(1, n - w))
        out[i:i + w] += rng.uniform(0.4, 1.0) * np.hanning(w) * rng.choice([-1, 1])
    return out


def finish(x, peak=0.7):
    x = np.asarray(x, dtype=np.float64)
    m = np.max(np.abs(x))
    if m > 0:
        x = x / m * peak
    f = min(len(x) // 4, n_of(0.004))
    if f > 0:
        x[:f] *= np.linspace(0, 1, f)
        x[-f:] *= np.linspace(1, 0, f)
    return x.astype(np.float32)


SOUNDS = {}


def save(event, idx, x, peak=0.7):
    name = f"{event}{idx}"
    os.makedirs(OUT, exist_ok=True)
    sf.write(os.path.join(OUT, name + ".ogg"), finish(x, peak), SR, format="OGG", subtype="VORBIS")
    SOUNDS.setdefault(event, []).append(name)


# --------------------------------------------------------------------------- writing tools

def chalk(i):
    n = n_of(rng.uniform(0.2, 0.3))
    grit = sample_hold(n, rng.uniform(250, 420), 0.05, 1.0, 3.0)
    body = band(noise(n), 1400, 7500) * grit
    squeal = sine(n, rng.uniform(2800, 3600) * (1 + 0.01 * sine(n, 23))) * 0.05 * sample_hold(n, 30, 0.0, 1.0, 4)
    crackle = band(impulses(n, 14, 0.0015), 2000, 9000) * 0.6
    return (body + squeal + crackle) * env(n, 0.012, 0.07)


def marker(i):
    n = n_of(rng.uniform(0.15, 0.24))
    f0 = rng.uniform(1100, 1600)
    wobble = 1 + 0.07 * band(noise(n), 8, 45) / 0.3
    freq = f0 * np.clip(wobble, 0.85, 1.15)
    tone = sine(n, freq) + 0.45 * sine(n, freq * 2) + 0.2 * sine(n, freq * 3)
    stick = sample_hold(n, rng.uniform(25, 40), 0.3, 1.0, 2.0)
    breath = band(noise(n), 2500, 7000) * 0.35
    return (tone * 0.5 * stick + breath) * env(n, 0.02, 0.06)


def pencil(i):
    n = n_of(rng.uniform(0.15, 0.22))
    grain = sample_hold(n, rng.uniform(500, 800), 0.15, 1.0, 2.0)
    body = band(noise(n), 2200, 9500) * grain
    return tilt(body, -2) * env(n, 0.01, 0.06) * (0.6 + 0.4 * strokes(n, 2, 0.8))


def pen(i):
    n = n_of(rng.uniform(0.15, 0.22))
    body = band(noise(n), 900, 5200) * sample_hold(n, 180, 0.5, 1.0, 1.2)
    roll = band(noise(n), 200, 600) * 0.3
    return (body + roll) * env(n, 0.015, 0.06)


def quill(i):
    n = n_of(rng.uniform(0.16, 0.24))
    body = band(noise(n), 3000, 10000) * sample_hold(n, 900, 0.05, 1.0, 3.0)
    scratch = band(impulses(n, 24, 0.001), 3000, 11000)
    return (body + scratch * 0.8) * env(n, 0.006, 0.05)


def highlighter(i):
    n = n_of(rng.uniform(0.14, 0.2))
    f0 = rng.uniform(700, 950)
    tone = sine(n, f0 * (1 + 0.03 * sine(n, rng.uniform(12, 20)))) * 0.35
    breath = band(noise(n), 1200, 5000) * sample_hold(n, 60, 0.5, 1.0, 1.0) * 0.6
    return (tone + breath) * env(n, 0.02, 0.05)


# --------------------------------------------------------------------------- erasers

def eraser_rubber(i):
    n = n_of(rng.uniform(0.26, 0.34))
    rub = band(noise(n), 180, 2600) * strokes(n, 2, 1.2)
    squeak = sine(n, rng.uniform(520, 700) * (1 + 0.05 * sine(n, 9))) * 0.08 * strokes(n, 2, 3)
    crumbs = band(impulses(n, 6, 0.002), 1500, 6000) * 0.3
    return (rub + squeak + crumbs) * env(n, 0.02, 0.06)


def eraser_chalk(i):
    n = n_of(rng.uniform(0.34, 0.44))
    fff = band(noise(n), 300, 5200) * strokes(n, 2, 0.9)
    dust = band(impulses(n, 18, 0.0015), 2500, 9000) * 0.35
    thump = sine(n, 140, 90) * decay(n, 0.04) * 0.25
    return tilt(fff, -1) + dust + thump


def eraser_dry(i):
    n = n_of(rng.uniform(0.25, 0.32))
    third = n // 3
    parts = [band(noise(third), 500, 3000), band(noise(third), 800, 5000), band(noise(n - 2 * third), 1200, 7000)]
    swish = np.concatenate(parts) * strokes(n, 1, 0.7)
    squeak = sine(n, rng.uniform(1700, 2100) * (1 + 0.04 * sine(n, 14))) * 0.12 * decay(n, 0.06)
    return (swish + squeak) * env(n, 0.03, 0.08)


# --------------------------------------------------------------------------- paper & desk

def page_flip(i):
    n = n_of(rng.uniform(0.32, 0.42))
    t = np.arange(n) / SR
    swoosh = band(noise(n), 400, 8000) * np.exp(-((t - 0.07) / 0.09) ** 2)
    crinkle = band(impulses(n, 30, 0.0012), 1500, 9000) * np.exp(-t / 0.12) * 0.7
    land = sine(n, 160, 90) * np.exp(-((t - 0.24) / 0.03) ** 2) * 0.35
    flutter = band(noise(n), 300, 1800) * (0.5 + 0.5 * np.sin(2 * np.pi * 26 * t)) * np.exp(-t / 0.15) * 0.4
    return swoosh + crinkle + land + flutter


def paper_pickup(i):
    n = n_of(0.16)
    t = np.arange(n) / SR
    slide = band(noise(n), 600, 6000) * np.exp(-((t - 0.05) / 0.05) ** 2)
    rustle = band(impulses(n, 8, 0.0012), 2000, 8000) * 0.5
    return slide + rustle


def paper_drop(i):
    n = n_of(0.18)
    t = np.arange(n) / SR
    slap = band(noise(n), 200, 4000) * np.exp(-t / 0.025)
    thud = sine(n, 120, 80) * np.exp(-t / 0.05) * 0.6
    return slap + thud


def crumple(i):
    n = n_of(0.45)
    t = np.arange(n) / SR
    x = band(impulses(n, 70, 0.0018), 800, 9000) + band(noise(n), 500, 6000) * 0.15
    return x * env(n, 0.02, 0.15) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * t) ** 2)


# --------------------------------------------------------------------------- ui

def click(i):
    n = n_of(0.06)
    t = np.arange(n) / SR
    f = rng.uniform(1500, 1900)
    wood = (sine(n, f) + 0.5 * sine(n, f * 2.7)) * np.exp(-t / 0.012)
    tick = band(noise(n), 2000, 9000) * np.exp(-t / 0.003) * 0.6
    body = sine(n, 420, 300) * np.exp(-t / 0.02) * 0.5
    return wood + tick + body


def hover(i):
    n = n_of(0.03)
    t = np.arange(n) / SR
    return sine(n, rng.uniform(2300, 2700)) * np.exp(-t / 0.006)


def pop(i):
    n = n_of(0.11)
    t = np.arange(n) / SR
    f0 = rng.uniform(650, 780)
    return sine(n, f0, f0 * 0.55) * np.exp(-t / 0.035) * env(n, 0.004, 0.02)


def type_key(i):
    n = n_of(0.04)
    t = np.arange(n) / SR
    f = rng.uniform(900, 1300)
    return (sine(n, f) * 0.5 + band(noise(n), 1500, 7000) * 0.6) * np.exp(-t / 0.008)


def marimba(n, f, start, gain=1.0):
    out = np.zeros(n)
    s = n_of(start)
    m = n - s
    t = np.arange(m) / SR
    note = (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t / 0.05)) * np.exp(-t / 0.22)
    out[s:] = note * gain * env(m, 0.003, 0.05)
    return out


def chime(i):
    n = n_of(0.6)
    root = [880.0, 987.8, 784.0][i % 3]
    return marimba(n, root, 0) + marimba(n, root * 1.498, 0.075, 0.8)


def success(i):
    n = n_of(0.75)
    return marimba(n, 1046.5, 0) + marimba(n, 1318.5, 0.07, 0.9) + marimba(n, 1568.0, 0.14, 0.85)


def stamp(i):
    n = n_of(0.22)
    t = np.arange(n) / SR
    thunk = sine(n, 110, 55) * np.exp(-t / 0.06)
    slap = band(noise(n), 300, 3000) * np.exp(-t / 0.012) * 0.8
    squish = band(noise(n), 150, 900) * np.exp(-((t - 0.05) / 0.03) ** 2) * 0.3
    return thunk + slap + squish


def bucket(i):
    n = n_of(0.35)
    out = np.zeros(n)
    for k in range(3):
        s = n_of(0.03 + k * 0.08 + rng.uniform(0, 0.02))
        m = n_of(0.07)
        t = np.arange(m) / SR
        f0 = rng.uniform(280, 380)
        blip = sine(m, f0, f0 * 2.1) * np.exp(-t / 0.03)
        out[s:s + m] += blip[:max(0, min(m, n - s))]
    return out


def whoosh(i):
    n = n_of(0.22)
    t = np.arange(n) / SR
    return band(noise(n), 300, 4000) * np.exp(-((t - 0.09) / 0.06) ** 2)


# --------------------------------------------------------------------------- main

def main():
    variants = {
        "chalk": (chalk, 4), "marker": (marker, 4), "pencil": (pencil, 4), "pen": (pen, 3), "quill": (quill, 3),
        "highlighter": (highlighter, 3), "eraser_rubber": (eraser_rubber, 3), "eraser_chalk": (eraser_chalk, 3),
        "eraser_dry": (eraser_dry, 3), "page_flip": (page_flip, 4), "paper_pickup": (paper_pickup, 2),
        "paper_drop": (paper_drop, 2), "crumple": (crumple, 2), "click": (click, 3), "hover": (hover, 2),
        "pop": (pop, 3), "type": (type_key, 4), "chime": (chime, 3), "success": (success, 1),
        "stamp": (stamp, 2), "bucket": (bucket, 2), "whoosh": (whoosh, 2),
    }
    peaks = {"hover": 0.35, "type": 0.45, "click": 0.6, "chime": 0.55, "success": 0.55}
    if os.path.isdir(OUT):
        for f in os.listdir(OUT):
            if f.endswith(".ogg"):
                os.remove(os.path.join(OUT, f))
    for event, (fn, count) in variants.items():
        for i in range(count):
            save(event, i + 1, fn(i), peaks.get(event, 0.7))
    meta = {}
    for event, names in SOUNDS.items():
        meta[event] = {
            "sounds": ["scribble:" + nm for nm in names],
            "subtitle": "subtitles.scribble." + event,
        }
    with open(os.path.join(OUT, "..", "sounds.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(f"wrote {sum(len(v) for v in SOUNDS.values())} sounds to {os.path.normpath(OUT)}")


if __name__ == "__main__":
    main()
