package com.vess7y.scribble.client.ui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

/**
 * Clickable regions collected while rendering. Screens draw their (immediate mode) UI each frame and register
 * hotspots as they go; mouse input is then resolved against the hotspots of the last frame.
 */
public final class Hotspots {
	private final List<Hotspot> list = new ArrayList<>();
	private int clipX0 = Integer.MIN_VALUE, clipY0 = Integer.MIN_VALUE, clipX1 = Integer.MAX_VALUE, clipY1 = Integer.MAX_VALUE;

	public interface DragHandler {
		void drag(double mouseX, double mouseY);

		default void release() {
		}
	}

	public static final class Hotspot {
		public final int x, y, w, h;
		public @Nullable Runnable onClick;
		public @Nullable Runnable onRightClick;
		public @Nullable DragHandler onDrag;
		public @Nullable Component tooltip;
		public boolean pointer = true;

		Hotspot(int x, int y, int w, int h) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
		}

		public boolean contains(double mx, double my) {
			return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
		}

		public Hotspot click(@Nullable Runnable r) {
			this.onClick = r;
			return this;
		}

		public Hotspot rightClick(@Nullable Runnable r) {
			this.onRightClick = r;
			return this;
		}

		public Hotspot drag(@Nullable DragHandler d) {
			this.onDrag = d;
			return this;
		}

		public Hotspot tooltip(@Nullable Component c) {
			this.tooltip = c;
			return this;
		}

		public Hotspot noPointer() {
			this.pointer = false;
			return this;
		}
	}

	public void clear() {
		this.list.clear();
		this.unclip();
	}

	public Hotspot add(int x, int y, int w, int h) {
		int x0 = Math.max(x, this.clipX0);
		int y0 = Math.max(y, this.clipY0);
		int x1 = Math.min(x + w, this.clipX1);
		int y1 = Math.min(y + h, this.clipY1);
		Hotspot hs = new Hotspot(x0, y0, Math.max(0, x1 - x0), Math.max(0, y1 - y0));
		if (hs.w > 0 && hs.h > 0) {
			this.list.add(hs);
		}
		return hs;
	}

	/** Restricts subsequently added hotspots to a rectangle (for scrolled, scissored areas). */
	public void clip(int x0, int y0, int x1, int y1) {
		this.clipX0 = x0;
		this.clipY0 = y0;
		this.clipX1 = x1;
		this.clipY1 = y1;
	}

	public void unclip() {
		this.clipX0 = Integer.MIN_VALUE;
		this.clipY0 = Integer.MIN_VALUE;
		this.clipX1 = Integer.MAX_VALUE;
		this.clipY1 = Integer.MAX_VALUE;
	}

	/** Topmost hotspot under the mouse (the one registered last). */
	public @Nullable Hotspot at(double mx, double my) {
		for (int i = this.list.size() - 1; i >= 0; i--) {
			Hotspot hs = this.list.get(i);
			if (hs.contains(mx, my)) {
				return hs;
			}
		}
		return null;
	}
}
