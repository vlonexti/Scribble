package com.vess7y.scribble.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.Scribble;
import com.vess7y.scribble.client.note.Align;
import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.note.PaperColor;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import org.jspecify.annotations.Nullable;

/**
 * Reads and writes notes under {@code .minecraft/scribble/notes/<id>/}: a {@code note.json} with the text
 * and settings plus one {@code ink_<page>.png} per page that has drawings on it.
 */
public final class NotesStorage {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	private static final Pattern INK_FILE = Pattern.compile("ink_(\\d+)\\.png");
	private static final int FORMAT_VERSION = 1;

	private NotesStorage() {
	}

	public static Path root() {
		return Minecraft.getInstance().gameDirectory.toPath().resolve("scribble");
	}

	public static Path notesDir() {
		return root().resolve("notes");
	}

	public static Path exportsDir() {
		return root().resolve("exports");
	}

	private static Path dirOf(Note note) {
		return notesDir().resolve(note.id);
	}

	// ------------------------------------------------------------------ listing

	public static List<Note> loadAll() {
		List<Note> notes = new ArrayList<>();
		Path dir = notesDir();
		if (!Files.isDirectory(dir)) {
			return notes;
		}
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
			for (Path noteDir : stream) {
				Path json = noteDir.resolve("note.json");
				if (!Files.isRegularFile(json)) {
					continue;
				}
				try {
					notes.add(read(noteDir.getFileName().toString(), Files.readString(json, StandardCharsets.UTF_8)));
				} catch (Exception e) {
					Scribble.LOGGER.error("Failed to read note {}", json, e);
				}
			}
		} catch (IOException e) {
			Scribble.LOGGER.error("Failed to list notes", e);
		}
		notes.sort(Comparator.comparingLong((Note n) -> n.modified).reversed());
		return notes;
	}

	// ------------------------------------------------------------------ saving

	public static void save(Note note) {
		Path dir = dirOf(note);
		try {
			Files.createDirectories(dir);
			writeAtomic(dir.resolve("note.json"), GSON.toJson(write(note)));
			if (note.inkLoaded) {
				for (Map.Entry<Integer, InkLayer> e : note.ink.entrySet()) {
					InkLayer layer = e.getValue();
					if (!layer.unsaved) {
						continue;
					}
					Path file = dir.resolve("ink_" + e.getKey() + ".png");
					if (layer.isBlank()) {
						Files.deleteIfExists(file);
					} else {
						try (NativeImage image = layer.toImage()) {
							image.writeToFile(file);
						}
					}
					layer.unsaved = false;
				}
				for (int page : note.removedInkPages) {
					if (!note.ink.containsKey(page)) {
						Files.deleteIfExists(dir.resolve("ink_" + page + ".png"));
					}
				}
				note.removedInkPages.clear();
			}
		} catch (IOException e) {
			Scribble.LOGGER.error("Failed to save note {}", note.id, e);
		}
	}

	private static void writeAtomic(Path target, String content) throws IOException {
		Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
		Files.writeString(tmp, content, StandardCharsets.UTF_8);
		try {
			Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
		} catch (AtomicMoveNotSupportedException e) {
			Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
		}
	}

	/** Loads every ink layer of a note. Safe to call more than once. */
	public static void loadInk(Note note) {
		if (note.inkLoaded) {
			return;
		}
		note.inkLoaded = true;
		Path dir = dirOf(note);
		if (!Files.isDirectory(dir)) {
			return;
		}
		try (Stream<Path> files = Files.list(dir)) {
			for (Path file : files.toList()) {
				Matcher m = INK_FILE.matcher(file.getFileName().toString());
				if (m.matches()) {
					InkLayer layer = readInk(file);
					if (layer != null) {
						note.ink.put(Integer.parseInt(m.group(1)), fitToPage(layer, note.type));
					}
				}
			}
		} catch (IOException e) {
			Scribble.LOGGER.error("Failed to load ink for note {}", note.id, e);
		}
	}

	/** Loads a single page's ink without marking the note as loaded (used for thumbnails). */
	public static @Nullable InkLayer loadInkPage(Note note, int page) {
		Path file = dirOf(note).resolve("ink_" + page + ".png");
		return Files.isRegularFile(file) ? readInk(file) : null;
	}

	private static @Nullable InkLayer readInk(Path file) {
		try (InputStream in = Files.newInputStream(file); NativeImage image = NativeImage.read(in)) {
			return InkLayer.fromImage(image);
		} catch (IOException e) {
			Scribble.LOGGER.error("Failed to read ink {}", file, e);
			return null;
		}
	}

	private static InkLayer fitToPage(InkLayer layer, NoteType type) {
		InkLayer target = InkLayer.forPage(type);
		if (layer.width == target.width && layer.height == target.height) {
			return layer;
		}
		for (int y = 0; y < Math.min(layer.height, target.height); y++) {
			System.arraycopy(layer.pixels, y * layer.width, target.pixels, y * target.width, Math.min(layer.width, target.width));
		}
		target.unsaved = true;
		return target;
	}

	// ------------------------------------------------------------------ library order

	/** The user's hand-arranged order of note ids in the library (from dragging cards around). */
	public static List<String> loadOrder() {
		List<String> order = new ArrayList<>();
		Path file = root().resolve("library.json");
		try {
			if (Files.isRegularFile(file)) {
				JsonObject o = JsonParser.parseString(Files.readString(file, StandardCharsets.UTF_8)).getAsJsonObject();
				if (o.has("order")) {
					for (JsonElement e : o.getAsJsonArray("order")) {
						order.add(e.getAsString());
					}
				}
			}
		} catch (Exception e) {
			Scribble.LOGGER.warn("Could not read library order", e);
		}
		return order;
	}

	public static void saveOrder(List<String> ids) {
		JsonObject o = new JsonObject();
		JsonArray arr = new JsonArray();
		ids.forEach(arr::add);
		o.add("order", arr);
		try {
			Files.createDirectories(root());
			writeAtomic(root().resolve("library.json"), GSON.toJson(o));
		} catch (IOException e) {
			Scribble.LOGGER.warn("Could not save library order", e);
		}
	}

	// ------------------------------------------------------------------ management

	public static void delete(Note note) {
		Path dir = dirOf(note);
		if (!Files.exists(dir)) {
			return;
		}
		try (Stream<Path> walk = Files.walk(dir)) {
			for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) {
				Files.deleteIfExists(p);
			}
		} catch (IOException e) {
			Scribble.LOGGER.error("Failed to delete note {}", note.id, e);
		}
	}

	public static Note duplicate(Note source, String newTitle) {
		loadInk(source);
		Note copy = read(UUID.randomUUID().toString(), GSON.toJson(write(source)));
		copy.title = newTitle;
		copy.starred = false;
		copy.created = System.currentTimeMillis();
		copy.modified = copy.created;
		copy.inkLoaded = true;
		for (Map.Entry<Integer, InkLayer> e : source.ink.entrySet()) {
			InkLayer layer = InkLayer.forPage(copy.type);
			layer.restore(e.getValue().pixels);
			copy.ink.put(e.getKey(), layer);
		}
		save(copy);
		return copy;
	}

	// ------------------------------------------------------------------ json

	private static JsonObject write(Note note) {
		JsonObject o = new JsonObject();
		o.addProperty("version", FORMAT_VERSION);
		o.addProperty("title", note.title);
		o.addProperty("type", note.type.id);
		o.addProperty("paper", note.paper.id);
		o.addProperty("cover", String.format("%08X", note.cover));
		o.addProperty("created", note.created);
		o.addProperty("modified", note.modified);
		o.addProperty("starred", note.starred);
		o.addProperty("trashed", note.trashed);
		o.addProperty("pages", note.minPages);
		JsonArray paras = new JsonArray();
		for (Paragraph p : note.paragraphs) {
			JsonObject po = new JsonObject();
			if (p.style != ParaStyle.BODY) {
				po.addProperty("style", p.style.id);
			}
			if (p.align != Align.LEFT) {
				po.addProperty("align", p.align.id);
			}
			if (p.indent != 0) {
				po.addProperty("indent", p.indent);
			}
			if (p.checked) {
				po.addProperty("checked", true);
			}
			JsonArray runs = new JsonArray();
			if (!p.isEmpty()) {
				for (Paragraph.Run run : p.runs(0, p.length())) {
					JsonObject ro = new JsonObject();
					ro.addProperty("t", p.text().substring(run.start(), run.end()));
					TextFormat f = run.format();
					if (f.bold()) {
						ro.addProperty("b", true);
					}
					if (f.italic()) {
						ro.addProperty("i", true);
					}
					if (f.underline()) {
						ro.addProperty("u", true);
					}
					if (f.strike()) {
						ro.addProperty("s", true);
					}
					if (f.color() != 0) {
						ro.addProperty("c", String.format("%08X", f.color()));
					}
					if (f.highlight() != 0) {
						ro.addProperty("h", String.format("%08X", f.highlight()));
					}
					runs.add(ro);
				}
			}
			po.add("runs", runs);
			paras.add(po);
		}
		o.add("paragraphs", paras);
		return o;
	}

	private static Note read(String id, String json) {
		JsonObject o = JsonParser.parseString(json).getAsJsonObject();
		NoteType type = NoteType.byId(str(o, "type", "lined"));
		Note note = new Note(id, type);
		note.title = str(o, "title", "");
		note.paper = PaperColor.byId(str(o, "paper", type.defaultPaper.id), type.defaultPaper);
		if (o.has("cover")) {
			note.cover = color(o, "cover") | 0xFF000000;
		}
		note.created = o.has("created") ? o.get("created").getAsLong() : System.currentTimeMillis();
		note.modified = o.has("modified") ? o.get("modified").getAsLong() : note.created;
		note.starred = o.has("starred") && o.get("starred").getAsBoolean();
		note.trashed = o.has("trashed") && o.get("trashed").getAsBoolean();
		note.minPages = o.has("pages") ? Math.max(1, o.get("pages").getAsInt()) : 1;
		note.paragraphs.clear();
		if (o.has("paragraphs")) {
			for (JsonElement pe : o.getAsJsonArray("paragraphs")) {
				JsonObject po = pe.getAsJsonObject();
				Paragraph p = new Paragraph();
				p.style = ParaStyle.byId(str(po, "style", "body"));
				p.align = Align.byId(str(po, "align", "left"));
				p.indent = po.has("indent") ? po.get("indent").getAsInt() : 0;
				p.checked = po.has("checked") && po.get("checked").getAsBoolean();
				if (po.has("runs")) {
					for (JsonElement re : po.getAsJsonArray("runs")) {
						JsonObject ro = re.getAsJsonObject();
						TextFormat f = new TextFormat(
								bool(ro, "b"), bool(ro, "i"), bool(ro, "u"), bool(ro, "s"),
								color(ro, "c"), color(ro, "h")
						);
						p.insert(p.length(), str(ro, "t", ""), f);
					}
				}
				note.paragraphs.add(p);
			}
		}
		if (note.paragraphs.isEmpty()) {
			note.paragraphs.add(new Paragraph());
		}
		return note;
	}

	private static String str(JsonObject o, String key, String fallback) {
		return o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsString() : fallback;
	}

	private static boolean bool(JsonObject o, String key) {
		return o.has(key) && o.get(key).getAsBoolean();
	}

	private static int color(JsonObject o, String key) {
		if (!o.has(key)) {
			return 0;
		}
		try {
			return (int) Long.parseLong(o.get(key).getAsString(), 16);
		} catch (NumberFormatException e) {
			return 0;
		}
	}
}
