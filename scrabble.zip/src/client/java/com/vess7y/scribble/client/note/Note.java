package com.vess7y.scribble.client.note;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.jspecify.annotations.Nullable;

/**
 * A single note: rich text flowing over pages plus one ink layer per page.
 */
public final class Note {
	public final String id;
	public String title;
	public NoteType type;
	public PaperColor paper;
	/** Cover color of notebook style notes. */
	public int cover = 0xFFD9653B;
	public long created;
	public long modified;
	public boolean starred;
	public boolean trashed;
	/** Minimum number of pages, raised by "add page". Text and ink can push the real count higher. */
	public int minPages = 1;
	public final List<Paragraph> paragraphs = new ArrayList<>();
	/** Ink layers by page index. Only populated once loaded (see {@link #inkLoaded}). */
	public final Map<Integer, InkLayer> ink = new HashMap<>();
	public boolean inkLoaded;
	/** Pages whose ink files must be deleted on next save. */
	public final List<Integer> removedInkPages = new ArrayList<>();

	public Note(String id, NoteType type) {
		this.id = id;
		this.type = type;
		this.paper = type.defaultPaper;
		this.title = "";
		this.paragraphs.add(new Paragraph());
	}

	public static Note create(NoteType type, String title) {
		Note note = new Note(UUID.randomUUID().toString(), type);
		note.title = title;
		note.created = System.currentTimeMillis();
		note.modified = note.created;
		return note;
	}

	public int defaultInk() {
		return this.type.defaultInk(this.paper);
	}

	public @Nullable InkLayer inkFor(int page) {
		return this.ink.get(page);
	}

	public InkLayer inkForEditing(int page) {
		return this.ink.computeIfAbsent(page, p -> InkLayer.forPage(this.type));
	}

	public int highestInkPage() {
		int max = -1;
		for (Map.Entry<Integer, InkLayer> e : this.ink.entrySet()) {
			if (e.getKey() > max && !e.getValue().isBlank()) {
				max = e.getKey();
			}
		}
		return max;
	}

	public String plainText() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < this.paragraphs.size(); i++) {
			if (i > 0) {
				sb.append('\n');
			}
			sb.append(this.paragraphs.get(i).text());
		}
		return sb.toString();
	}

	public int wordCount() {
		int words = 0;
		for (Paragraph p : this.paragraphs) {
			boolean inWord = false;
			for (int i = 0; i < p.length(); i++) {
				boolean letter = !Character.isWhitespace(p.charAt(i));
				if (letter && !inWord) {
					words++;
				}
				inWord = letter;
			}
		}
		return words;
	}

	public int charCount() {
		int n = 0;
		for (Paragraph p : this.paragraphs) {
			n += p.length();
		}
		return n;
	}

	/** First non-empty line of text, used as a fallback title. */
	public String snippet() {
		for (Paragraph p : this.paragraphs) {
			String t = p.text().strip();
			if (!t.isEmpty()) {
				return t;
			}
		}
		return "";
	}

	public void touch() {
		this.modified = System.currentTimeMillis();
	}

	public void releaseTextures() {
		for (InkLayer layer : this.ink.values()) {
			layer.release();
		}
	}
}
