package com.vess7y.scribble.client.editor;

import com.vess7y.scribble.client.note.NoteType;

public enum Tool {
	TEXT("text", 't'),
	PEN("pen", 'p'),
	HIGHLIGHTER("highlighter", 'h'),
	ERASER("eraser", 'e'),
	SHAPES("shapes", 'r'),
	FILL("fill", 'f'),
	STAMP("stamp", 's'),
	EYEDROPPER("eyedropper", 'i'),
	PAN("pan", ' ');

	public final String id;
	public final char hotkey;

	Tool(String id, char hotkey) {
		this.id = id;
		this.hotkey = hotkey;
	}

	public boolean availableFor(NoteType type) {
		return this != HIGHLIGHTER || !type.board;
	}

	public String icon(NoteType type) {
		return switch (this) {
			case TEXT -> "tool_text";
			case PEN -> type.pen.icon;
			case HIGHLIGHTER -> "tool_highlighter";
			case ERASER -> type.eraser.icon;
			case SHAPES -> "tool_rect";
			case FILL -> "tool_fill";
			case STAMP -> "tool_stamp";
			case EYEDROPPER -> "tool_eyedropper";
			case PAN -> "tool_pan";
		};
	}

	public String translationKey(NoteType type) {
		return switch (this) {
			case PEN -> type.pen.translationKey();
			case ERASER -> type.eraser.translationKey();
			default -> "scribble.tool." + this.id;
		};
	}

	public boolean usesColor() {
		return this == PEN || this == HIGHLIGHTER || this == SHAPES || this == FILL || this == TEXT;
	}

	public boolean usesSize() {
		return this == PEN || this == HIGHLIGHTER || this == ERASER || this == SHAPES || this == STAMP;
	}

	public boolean draws() {
		return this != TEXT && this != PAN;
	}

	public enum Shape {
		LINE("line", "tool_line"),
		RECT("rect", "tool_rect"),
		ELLIPSE("ellipse", "tool_ellipse");

		public final String id;
		public final String icon;

		Shape(String id, String icon) {
			this.id = id;
			this.icon = icon;
		}
	}

	/** Pen variants offered on paper notes. */
	public enum PenStyle {
		BALLPOINT("ballpoint", "tool_pen", 1.0F, 0.0F),
		PENCIL("pencil", "tool_pencil", 0.82F, 0.25F),
		FELT("felt", "tool_marker", 1.0F, 0.0F),
		CRAYON("crayon", "tool_crayon", 0.62F, 0.15F);

		public final String id;
		public final String icon;
		public final float density;
		public final float alphaJitter;

		PenStyle(String id, String icon, float density, float alphaJitter) {
			this.id = id;
			this.icon = icon;
			this.density = density;
			this.alphaJitter = alphaJitter;
		}
	}
}
