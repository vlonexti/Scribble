package com.vess7y.scribble.client.note;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;

/**
 * A paragraph of rich text: characters with per-character {@link TextFormat}s plus block level style.
 */
public final class Paragraph {
	private final StringBuilder text = new StringBuilder();
	private final ArrayList<TextFormat> formats = new ArrayList<>();
	public ParaStyle style = ParaStyle.BODY;
	public Align align = Align.LEFT;
	public int indent;
	public boolean checked;

	public Paragraph() {
	}

	public Paragraph(String text) {
		this.insert(0, text, TextFormat.PLAIN);
	}

	public int length() {
		return this.text.length();
	}

	public boolean isEmpty() {
		return this.text.isEmpty();
	}

	public String text() {
		return this.text.toString();
	}

	public char charAt(int i) {
		return this.text.charAt(i);
	}

	public TextFormat formatAt(int i) {
		return this.formats.get(i);
	}

	/** Format that newly typed text at {@code offset} should inherit. */
	public TextFormat formatForInsert(int offset) {
		if (this.formats.isEmpty()) {
			return TextFormat.PLAIN;
		}
		return this.formats.get(Math.max(0, Math.min(offset, this.formats.size()) - 1));
	}

	public void insert(int offset, String s, TextFormat format) {
		this.text.insert(offset, s);
		for (int i = 0; i < s.length(); i++) {
			this.formats.add(offset + i, format);
		}
	}

	public void delete(int start, int end) {
		if (end <= start) {
			return;
		}
		this.text.delete(start, end);
		this.formats.subList(start, end).clear();
	}

	/** Cuts everything from {@code offset} to the end into a new paragraph with the same block style. */
	public Paragraph split(int offset) {
		Paragraph tail = new Paragraph();
		tail.style = this.style;
		tail.align = this.align;
		tail.indent = this.indent;
		tail.text.append(this.text, offset, this.text.length());
		tail.formats.addAll(this.formats.subList(offset, this.formats.size()));
		this.delete(offset, this.length());
		return tail;
	}

	public void append(Paragraph other) {
		this.text.append(other.text);
		this.formats.addAll(other.formats);
	}

	public void applyFormat(int start, int end, UnaryOperator<TextFormat> op) {
		for (int i = Math.max(0, start); i < Math.min(end, this.formats.size()); i++) {
			this.formats.set(i, op.apply(this.formats.get(i)));
		}
	}

	public Paragraph copy() {
		Paragraph p = new Paragraph();
		p.text.append(this.text);
		p.formats.addAll(this.formats);
		p.style = this.style;
		p.align = this.align;
		p.indent = this.indent;
		p.checked = this.checked;
		return p;
	}

	/** Copies the characters in [start, end) keeping their formats. */
	public Paragraph slice(int start, int end) {
		Paragraph p = new Paragraph();
		p.text.append(this.text, start, end);
		p.formats.addAll(this.formats.subList(start, end));
		p.style = this.style;
		p.align = this.align;
		p.indent = this.indent;
		p.checked = this.checked;
		return p;
	}

	/** Splits [start, end) into runs of identical formatting. */
	public List<Run> runs(int start, int end) {
		List<Run> runs = new ArrayList<>();
		int runStart = start;
		for (int i = start + 1; i <= end; i++) {
			if (i == end || !this.formats.get(i).equals(this.formats.get(runStart))) {
				runs.add(new Run(runStart, i, this.formats.get(runStart)));
				runStart = i;
			}
		}
		return runs;
	}

	public record Run(int start, int end, TextFormat format) {
	}
}
