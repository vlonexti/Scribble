package com.vess7y.scribble.client.note;

import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.Scribble;
import java.util.BitSet;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.jspecify.annotations.Nullable;

/**
 * A raster drawing layer for one page. Pixels are ARGB and live on the CPU; a GPU texture is created
 * lazily and only the dirty region is copied before each upload.
 */
public final class InkLayer {
	/** Ink pixels per page unit. */
	public static final int SCALE = 2;
	private static final AtomicInteger COUNTER = new AtomicInteger();

	public final int width;
	public final int height;
	public final int[] pixels;
	private @Nullable DynamicTexture texture;
	private @Nullable Identifier textureId;
	private int dirtyX0, dirtyY0, dirtyX1 = -1, dirtyY1 = -1;
	/** True when the pixels changed since the last save. */
	public boolean unsaved;
	/** Pixels already touched by the current stroke, so a stroke never builds up over itself. */
	public final BitSet strokeMask;

	public InkLayer(int width, int height) {
		this.width = width;
		this.height = height;
		this.pixels = new int[width * height];
		this.strokeMask = new BitSet(width * height);
		this.markAllDirty();
	}

	public static InkLayer forPage(NoteType type) {
		return new InkLayer(type.pageWidth * SCALE, type.pageHeight * SCALE);
	}

	public static InkLayer fromImage(NativeImage image) {
		InkLayer layer = new InkLayer(image.getWidth(), image.getHeight());
		for (int y = 0; y < layer.height; y++) {
			for (int x = 0; x < layer.width; x++) {
				layer.pixels[y * layer.width + x] = image.getPixel(x, y);
			}
		}
		return layer;
	}

	public NativeImage toImage() {
		NativeImage image = new NativeImage(this.width, this.height, false);
		for (int y = 0; y < this.height; y++) {
			for (int x = 0; x < this.width; x++) {
				image.setPixel(x, y, this.pixels[y * this.width + x]);
			}
		}
		return image;
	}

	public boolean isBlank() {
		for (int p : this.pixels) {
			if ((p >>> 24) != 0) {
				return false;
			}
		}
		return true;
	}

	public int get(int x, int y) {
		if (x < 0 || y < 0 || x >= this.width || y >= this.height) {
			return 0;
		}
		return this.pixels[y * this.width + x];
	}

	public int[] snapshot() {
		return this.pixels.clone();
	}

	public void restore(int[] snapshot) {
		System.arraycopy(snapshot, 0, this.pixels, 0, this.pixels.length);
		this.markAllDirty();
		this.unsaved = true;
	}

	public void clear() {
		java.util.Arrays.fill(this.pixels, 0);
		this.markAllDirty();
		this.unsaved = true;
	}

	public void markDirty(int x0, int y0, int x1, int y1) {
		x0 = Math.max(0, x0);
		y0 = Math.max(0, y0);
		x1 = Math.min(this.width - 1, x1);
		y1 = Math.min(this.height - 1, y1);
		if (x1 < x0 || y1 < y0) {
			return;
		}
		if (this.dirtyX1 < 0) {
			this.dirtyX0 = x0;
			this.dirtyY0 = y0;
			this.dirtyX1 = x1;
			this.dirtyY1 = y1;
		} else {
			this.dirtyX0 = Math.min(this.dirtyX0, x0);
			this.dirtyY0 = Math.min(this.dirtyY0, y0);
			this.dirtyX1 = Math.max(this.dirtyX1, x1);
			this.dirtyY1 = Math.max(this.dirtyY1, y1);
		}
		this.unsaved = true;
	}

	public void markAllDirty() {
		this.dirtyX0 = 0;
		this.dirtyY0 = 0;
		this.dirtyX1 = this.width - 1;
		this.dirtyY1 = this.height - 1;
	}

	/** Returns the texture for this layer, uploading pending changes first. Render thread only. */
	public Identifier texture() {
		if (this.texture == null) {
			this.texture = new DynamicTexture(() -> "scribble ink", this.width, this.height, true);
			this.textureId = Scribble.id("dynamic/ink_" + COUNTER.incrementAndGet());
			Minecraft.getInstance().getTextureManager().register(this.textureId, this.texture);
			this.markAllDirty();
		}
		if (this.dirtyX1 >= 0) {
			NativeImage image = this.texture.getPixels();
			for (int y = this.dirtyY0; y <= this.dirtyY1; y++) {
				int row = y * this.width;
				for (int x = this.dirtyX0; x <= this.dirtyX1; x++) {
					image.setPixel(x, y, this.pixels[row + x]);
				}
			}
			this.texture.upload();
			this.dirtyX1 = -1;
			this.dirtyY1 = -1;
		}
		return this.textureId;
	}

	/** Frees the GPU texture. The layer stays usable and re-creates it on demand. */
	public void release() {
		if (this.textureId != null) {
			Minecraft.getInstance().getTextureManager().release(this.textureId);
		}
		this.texture = null;
		this.textureId = null;
		this.markAllDirty();
	}

	/** A smaller copy for thumbnails. Keeps the strongest pixel of each block so thin lines survive. */
	public InkLayer downscaled(int factor) {
		InkLayer out = new InkLayer(Math.max(1, this.width / factor), Math.max(1, this.height / factor));
		for (int y = 0; y < out.height; y++) {
			for (int x = 0; x < out.width; x++) {
				int best = 0;
				for (int dy = 0; dy < factor; dy++) {
					for (int dx = 0; dx < factor; dx++) {
						int p = this.get(x * factor + dx, y * factor + dy);
						if ((p >>> 24) > (best >>> 24)) {
							best = p;
						}
					}
				}
				out.pixels[y * out.width + x] = best;
			}
		}
		return out;
	}
}
