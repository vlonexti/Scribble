package com.vess7y.scribble.client.editor;

import com.mojang.blaze3d.Blaze3D;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.cursor.CursorTypes;
import com.vess7y.scribble.Scribble;
import com.vess7y.scribble.client.NotesStorage;
import com.vess7y.scribble.client.ScribbleSettings;
import com.vess7y.scribble.client.ScribbleSounds;
import com.vess7y.scribble.client.export.NoteExporter;
import com.vess7y.scribble.client.note.Align;
import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.MinecraftColors;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.note.PaperColor;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import com.vess7y.scribble.client.render.BitmapFont;
import com.vess7y.scribble.client.render.PageRenderer;
import com.vess7y.scribble.client.render.SpriteData;
import com.vess7y.scribble.client.render.Sprites;
import com.vess7y.scribble.client.text.TextEditor;
import com.vess7y.scribble.client.text.TextLayout;
import com.vess7y.scribble.client.text.TextMetrics;
import com.vess7y.scribble.client.ui.Anim;
import com.vess7y.scribble.client.ui.Dialog;
import com.vess7y.scribble.client.ui.Dust;
import com.vess7y.scribble.client.ui.Hotspots;
import com.vess7y.scribble.client.ui.Notifications;
import com.vess7y.scribble.client.ui.Popup;
import com.vess7y.scribble.client.ui.Ui;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

/**
 * The full-screen note editor. Paper-like notes scroll like a document; lined paper is a ring-binder notebook you
 * flip through two pages at a time. Cozy floating toolbars surround the page, and the tools follow the mouse as
 * big springy toon props.
 */
public class NoteEditorScreen extends Screen {
	private static final int TOP_H = 26;
	private static final int FMT_Y = 30;
	private static final int FMT_H = 22;
	private static final int VIEW_Y = 57;
	private static final int STATUS_H = 16;
	private static final int PANEL_W = 112;
	private static final int PAD = 14;
	private static final int GAP = 18;
	private static final int SPINE = 12;
	private static final int COVER = 9;
	private static final int NAV_H = 24;
	private static final long FLIP_MS = 460;
	private static final float[] ZOOMS = {0.5F, 0.75F, 1.0F, 1.25F, 1.5F, 2.0F, 2.5F, 3.0F, 4.0F};
	private static final int[] HIGHLIGHTS = {0x90FFF176, 0x90A5F28A, 0x90FFA6C9, 0x908FD3FF, 0x90FFC07A, 0x90D2B4FF};
	private static final int[] HIGHLIGHTER_COLORS = {0xFFFFF176, 0xFFA5F28A, 0xFFFFA6C9, 0xFF8FD3FF, 0xFFFFC07A, 0xFFD2B4FF};
	private static final long AUTOSAVE_MS = 1500;

	// SDL keycodes as delivered by KeyEvent#shortcutKey
	private static final int K_BACKSPACE = 8;
	private static final int K_TAB = 9;
	private static final int K_ENTER = 13;
	private static final int K_DELETE = 127;
	private static final int K_RIGHT = 1073741903;
	private static final int K_LEFT = 1073741904;
	private static final int K_DOWN = 1073741905;
	private static final int K_UP = 1073741906;
	private static final int K_HOME = 1073741898;
	private static final int K_END = 1073741901;
	private static final int K_PAGEUP = 1073741899;
	private static final int K_PAGEDOWN = 1073741902;
	private static final int K_KP_ENTER = 1073741912;

	private final @Nullable Screen parent;
	private final Note note;
	private final TextMetrics metrics;
	private final TextEditor editor;
	private final History history = new History();
	private final Hotspots hs = new Hotspots();
	private final ToolCursor toolCursor = new ToolCursor();
	private final Dust dust = new Dust();
	private final boolean notebook;
	private @Nullable TextLayout layout;

	private Tool tool;
	private Tool previousTool;
	private Tool.PenStyle penStyle = Tool.PenStyle.BALLPOINT;
	private Tool.Shape shape = Tool.Shape.RECT;
	private boolean shapeFilled;
	private String stamp = "heart";
	private MinecraftColors.Group colorGroup = MinecraftColors.Group.DYES;
	private final Map<Tool, Integer> sizes = new EnumMap<>(Tool.class);
	private final Map<Tool, Integer> colors = new EnumMap<>(Tool.class);

	private float zoom = 1.0F;
	private boolean zoomInitialized;
	private double scrollX;
	private double scrollY;
	private boolean panelOpen = true;
	private double panelScroll;
	private int panelContentHeight;

	// notebook spread and page flip animation
	private int spread;
	private int flipFrom = -1;
	private int flipTo;
	private long flipStart;
	private long lastWheelFlip;

	private @Nullable Popup popup;
	private @Nullable Dialog dialog;
	private Hotspots.@Nullable DragHandler activeDrag;

	// pointer interaction state
	private boolean selecting;
	private boolean drawing;
	private boolean erasingWithRightButton;
	private boolean shaping;
	private boolean panning;
	private boolean spaceDown;
	private int drawPage = -1;
	private float lastInkX;
	private float lastInkY;
	private float shapeStartX;
	private float shapeStartY;
	private int @Nullable [] shapeBase;
	private int strokeSeed;
	private int lastStrokePage = -1;
	private double panMouseX;
	private double panMouseY;
	private long lastClickTime;
	private int clickCount;

	private boolean dirty;
	private long lastChange;
	private @Nullable Component flash;
	private long flashTime;

	public NoteEditorScreen(@Nullable Screen parent, Note note) {
		super(Component.literal(note.title));
		this.parent = parent;
		this.note = note;
		ScribbleSettings.load();
		TextMetrics.invalidate();
		BitmapFont.invalidate();
		SpriteData.invalidate();
		NotesStorage.loadInk(note);
		this.metrics = TextMetrics.get();
		this.notebook = note.type.notebook;
		this.editor = new TextEditor(note, this::beforeTextEdit, this::afterTextEdit);
		this.tool = note.type.board ? Tool.PEN : Tool.TEXT;
		this.previousTool = this.tool;
		this.editor.docEnd(false);
		if (this.notebook) {
			this.spread = spreadOf(this.layout().lineOf(this.editor.cursor).page());
		}
	}

	public Note note() {
		return this.note;
	}

	// ------------------------------------------------------------------ geometry

	private int railWidth() {
		int n = this.tools().size();
		int perCol = Math.max(1, (this.viewH() - 10) / 22);
		int cols = (n + perCol - 1) / perCol;
		return 8 + cols * 22;
	}

	private int viewX() {
		return 4 + this.railWidth() + 4;
	}

	private int viewY() {
		return VIEW_Y;
	}

	private int viewW() {
		return this.width - this.viewX() - (this.panelOpen ? PANEL_W + 8 : 4);
	}

	private int viewH() {
		return this.height - VIEW_Y - STATUS_H - 2;
	}

	private TextLayout layout() {
		if (this.layout == null) {
			this.layout = TextLayout.build(this.note, this.metrics);
		}
		return this.layout;
	}

	private int pageCount() {
		return this.layout().pageCount(this.note);
	}

	private boolean inView(double mx, double my) {
		return mx >= this.viewX() && my >= this.viewY() && mx < this.viewX() + this.viewW() && my < this.viewY() + this.viewH();
	}

	private float stride() {
		return (this.note.type.outerHeight() + GAP) * this.zoom;
	}

	private double docWidth() {
		return this.notebook ? (2 * this.note.type.pageWidth + SPINE + 2 * COVER) * this.zoom + PAD * 2
				: this.note.type.outerWidth() * this.zoom + PAD * 2;
	}

	private double docHeight() {
		return this.notebook ? (this.note.type.pageHeight + 2 * COVER) * this.zoom + PAD * 2 + NAV_H
				: PAD * 2 + this.pageCount() * this.stride() - GAP * this.zoom;
	}

	private double maxScrollX() {
		return Math.max(0, this.docWidth() - this.viewW());
	}

	private double maxScrollY() {
		return Math.max(0, this.docHeight() - this.viewH());
	}

	private void clampScroll() {
		this.scrollX = Mth.clamp(this.scrollX, 0, this.maxScrollX());
		this.scrollY = Mth.clamp(this.scrollY, 0, this.maxScrollY());
	}

	private static int spreadOf(int page) {
		return (page + 1) / 2;
	}

	private int leftPage() {
		return this.spread > 0 ? 2 * this.spread - 1 : -1;
	}

	private int rightPage() {
		return 2 * this.spread;
	}

	private int maxSpread() {
		return spreadOf(Math.max(0, this.pageCount() - 1)) + 1;
	}

	private float bookX() {
		float bookW = (2 * this.note.type.pageWidth + SPINE) * this.zoom;
		if (this.docWidth() <= this.viewW()) {
			return this.viewX() + (this.viewW() - bookW) / 2;
		}
		return (float) (this.viewX() + PAD + COVER * this.zoom - this.scrollX);
	}

	private float bookY() {
		float bookH = this.note.type.pageHeight * this.zoom;
		if (this.docHeight() <= this.viewH()) {
			return this.viewY() + (this.viewH() - NAV_H - bookH) / 2;
		}
		return (float) (this.viewY() + PAD + COVER * this.zoom - this.scrollY);
	}

	private boolean flipping() {
		return this.flipFrom >= 0 && Util.getMillis() - this.flipStart < FLIP_MS;
	}

	/** Screen x of a page's top-left corner, or NaN when it is not shown. */
	private float pageX(int page) {
		if (this.notebook) {
			if (page == this.leftPage()) {
				return this.bookX();
			}
			if (page == this.rightPage()) {
				return this.bookX() + (this.note.type.pageWidth + SPINE) * this.zoom;
			}
			return Float.NaN;
		}
		NoteType t = this.note.type;
		if (this.docWidth() <= this.viewW()) {
			return this.viewX() + (this.viewW() - t.outerWidth() * this.zoom) / 2 + t.outerLeft * this.zoom;
		}
		return (float) (this.viewX() + PAD + t.outerLeft * this.zoom - this.scrollX);
	}

	private float pageY(int page) {
		if (this.notebook) {
			return page == this.leftPage() || page == this.rightPage() ? this.bookY() : Float.NaN;
		}
		return (float) (this.viewY() + PAD + page * this.stride() + this.note.type.outerTop * this.zoom - this.scrollY);
	}

	/** Page under the mouse, or -1 (notebook only; documents always resolve to the nearest page). */
	private int pageAt(double mx, double my) {
		if (this.notebook) {
			NoteType t = this.note.type;
			for (int page : new int[]{this.leftPage(), this.rightPage()}) {
				if (page < 0) {
					continue;
				}
				float px = this.pageX(page);
				float py = this.pageY(page);
				if (mx >= px - 4 && mx < px + t.pageWidth * this.zoom + 4 && my >= py - 4 && my < py + t.pageHeight * this.zoom + 4) {
					return page;
				}
			}
			return -1;
		}
		double rel = (my - this.viewY() - PAD + this.scrollY + GAP * this.zoom / 2) / this.stride();
		return Mth.clamp((int) Math.floor(rel), 0, this.pageCount() - 1);
	}

	private double toPageX(int page, double mx) {
		return (mx - this.pageX(page)) / this.zoom;
	}

	private double toPageY(int page, double my) {
		return (my - this.pageY(page)) / this.zoom;
	}

	private int currentPage() {
		if (this.tool == Tool.TEXT) {
			return this.layout().lineOf(this.editor.cursor).page();
		}
		if (this.notebook) {
			return this.rightPage();
		}
		return this.pageAt(this.viewX() + this.viewW() / 2.0, this.viewY() + this.viewH() / 2.0);
	}

	// ------------------------------------------------------------------ init & lifecycle

	@Override
	protected void init() {
		if (!this.zoomInitialized) {
			this.zoomInitialized = true;
			this.zoom = this.fitZoom();
			if (this.tool == Tool.TEXT && !this.notebook) {
				this.ensureCaretVisible();
			}
		}
		this.clampScroll();
	}

	private float fitZoom() {
		NoteType t = this.note.type;
		if (this.notebook) {
			float fw = (this.viewW() - PAD * 2.0F) / (2 * t.pageWidth + SPINE + 2 * COVER);
			float fh = (this.viewH() - PAD * 2.0F - NAV_H) / (t.pageHeight + 2 * COVER);
			return Math.max(0.4F, (float) Math.floor(Math.min(fw, fh) * 20) / 20);
		}
		float fit = (this.viewW() - PAD * 2.0F) / t.outerWidth();
		float best = ZOOMS[0];
		for (float z : ZOOMS) {
			if (z <= fit && z <= 2.0F) {
				best = z;
			}
		}
		return best;
	}

	@Override
	public void tick() {
		if (this.dirty && Util.getMillis() - this.lastChange > AUTOSAVE_MS && !this.drawing && !this.shaping) {
			this.save();
		}
	}

	private void save() {
		this.note.title = this.note.title.strip();
		NotesStorage.save(this.note);
		this.dirty = false;
	}

	private void markChanged() {
		this.note.touch();
		this.dirty = true;
		this.lastChange = Util.getMillis();
	}

	@Override
	public void removed() {
		if (this.dirty) {
			this.save();
		}
		this.note.releaseTextures();
	}

	@Override
	public void onClose() {
		this.save();
		ScribbleSounds.playVaried(ScribbleSounds.PAGE_FLIP, 0.9F, 0.6F);
		this.minecraft.gui.setScreen(this.parent);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	private void flash(Component message) {
		this.flash = message;
		this.flashTime = Util.getMillis();
	}

	// ------------------------------------------------------------------ history

	private final class TextSnap implements History.Snapshot {
		private final List<Paragraph> paragraphs = new ArrayList<>();
		private final TextLayout.Pos cursor;
		private final TextLayout.Pos anchor;
		private final int minPages;

		TextSnap() {
			for (Paragraph p : NoteEditorScreen.this.note.paragraphs) {
				this.paragraphs.add(p.copy());
			}
			this.cursor = NoteEditorScreen.this.editor.cursor;
			this.anchor = NoteEditorScreen.this.editor.anchor;
			this.minPages = NoteEditorScreen.this.note.minPages;
		}

		@Override
		public History.Snapshot captureCurrent() {
			return new TextSnap();
		}

		@Override
		public void restore() {
			Note n = NoteEditorScreen.this.note;
			n.paragraphs.clear();
			for (Paragraph p : this.paragraphs) {
				n.paragraphs.add(p.copy());
			}
			n.minPages = this.minPages;
			NoteEditorScreen.this.editor.select(this.anchor, this.cursor);
			NoteEditorScreen.this.invalidate();
		}
	}

	private final class InkSnap implements History.Snapshot {
		private final int page;
		private final int @Nullable [] pixels;

		InkSnap(int page) {
			this.page = page;
			InkLayer layer = NoteEditorScreen.this.note.inkFor(page);
			this.pixels = layer == null ? null : layer.snapshot();
		}

		@Override
		public History.Snapshot captureCurrent() {
			return new InkSnap(this.page);
		}

		@Override
		public void restore() {
			Note n = NoteEditorScreen.this.note;
			if (this.pixels == null) {
				InkLayer layer = n.inkFor(this.page);
				if (layer != null) {
					layer.clear();
				}
			} else {
				n.inkForEditing(this.page).restore(this.pixels);
			}
			NoteEditorScreen.this.markChanged();
		}
	}

	/** Text plus all ink, for page structure changes. */
	private final class FullSnap implements History.Snapshot {
		private final TextSnap text = new TextSnap();
		private final Map<Integer, int[]> ink = new HashMap<>();

		FullSnap() {
			for (Map.Entry<Integer, InkLayer> e : NoteEditorScreen.this.note.ink.entrySet()) {
				this.ink.put(e.getKey(), e.getValue().snapshot());
			}
		}

		@Override
		public History.Snapshot captureCurrent() {
			return new FullSnap();
		}

		@Override
		public void restore() {
			this.text.restore();
			Note n = NoteEditorScreen.this.note;
			for (Map.Entry<Integer, InkLayer> e : n.ink.entrySet()) {
				if (!this.ink.containsKey(e.getKey())) {
					e.getValue().clear();
				}
			}
			for (Map.Entry<Integer, int[]> e : this.ink.entrySet()) {
				n.inkForEditing(e.getKey()).restore(e.getValue());
			}
		}
	}

	private void beforeTextEdit(@Nullable String key) {
		this.history.push(new TextSnap(), key);
	}

	private void afterTextEdit() {
		this.invalidate();
		this.ensureCaretVisible();
	}

	private void invalidate() {
		this.layout = null;
		this.markChanged();
	}

	private void undo() {
		if (this.history.undo()) {
			this.invalidate();
			ScribbleSounds.playVaried(ScribbleSounds.WHOOSH, 1.2F, 0.35F);
			this.flash(Component.translatable("scribble.status.undo"));
		}
	}

	private void redo() {
		if (this.history.redo()) {
			this.invalidate();
			ScribbleSounds.playVaried(ScribbleSounds.WHOOSH, 1.4F, 0.35F);
			this.flash(Component.translatable("scribble.status.redo"));
		}
	}

	// ------------------------------------------------------------------ tools, colors, sizes

	private List<Tool> tools() {
		List<Tool> list = new ArrayList<>();
		for (Tool t : Tool.values()) {
			if (t.availableFor(this.note.type)) {
				list.add(t);
			}
		}
		return list;
	}

	private void setTool(Tool t) {
		if (t != this.tool) {
			this.previousTool = this.tool;
			this.tool = t;
			this.history.breakCoalescing();
			this.toolCursor.reset();
		}
	}

	private String toolIcon(Tool t) {
		if (t == Tool.SHAPES) {
			return "tool_shapes";
		}
		if (t == Tool.PEN && this.note.type.pen == NoteType.PenKind.PEN) {
			return this.penStyle.icon;
		}
		return t.icon(this.note.type);
	}

	private int size(Tool t) {
		return this.sizes.computeIfAbsent(t, k -> switch (k) {
			case PEN -> switch (this.note.type.pen) {
				case MARKER -> 4;
				case CHALK -> 5;
				default -> 2;
			};
			case HIGHLIGHTER -> 10;
			case ERASER -> switch (this.note.type.eraser) {
				case PENCIL -> 8;
				case DRY_ERASE -> 20;
				case CHALK -> 22;
			};
			case SHAPES -> this.note.type.board ? 4 : 2;
			case STAMP -> 2;
			default -> 1;
		});
	}

	private int maxSize(Tool t) {
		return t == Tool.STAMP ? 6 : 32;
	}

	private int[] paletteFor(Tool t) {
		return t == Tool.HIGHLIGHTER ? HIGHLIGHTER_COLORS : this.note.type.palette;
	}

	private int color(Tool t) {
		return this.colors.computeIfAbsent(t, k -> k == Tool.FILL && this.paletteFor(k).length > 1 ? this.paletteFor(k)[1] : this.paletteFor(k)[0]);
	}

	private void setColor(Tool t, int c) {
		this.colors.put(t, c);
	}

	private InkPainter.Brush brush(Tool t, boolean erase) {
		if (t == Tool.ERASER || erase) {
			int es = this.size(Tool.ERASER);
			return switch (this.note.type.eraser) {
				case PENCIL -> new InkPainter.Brush(0, es, InkPainter.Shape.ROUND, InkPainter.Mode.ERASE, 1, 0);
				case DRY_ERASE -> new InkPainter.Brush(0, es, InkPainter.Shape.WIDE, InkPainter.Mode.ERASE, 1, 0);
				case CHALK -> new InkPainter.Brush(0, es, InkPainter.Shape.WIDE, InkPainter.Mode.ERASE_SOFT, 1, 0);
			};
		}
		int size = this.size(t);
		int color = this.color(t);
		if (t == Tool.HIGHLIGHTER) {
			return new InkPainter.Brush((color & 0xFFFFFF) | 0x66000000, size, InkPainter.Shape.CHISEL, InkPainter.Mode.PAINT, 1, 0);
		}
		return switch (this.note.type.pen) {
			case CHALK -> new InkPainter.Brush(color, size, InkPainter.Shape.ROUND, InkPainter.Mode.PAINT, 0.72F, 0.35F);
			case MARKER -> InkPainter.Brush.solid(color, size, InkPainter.Shape.ROUND);
			case QUILL -> new InkPainter.Brush(color, size, InkPainter.Shape.ROUND, InkPainter.Mode.PAINT, 0.96F, 0.12F);
			case WHITE_PENCIL -> new InkPainter.Brush(color, size, InkPainter.Shape.ROUND, InkPainter.Mode.PAINT, 0.9F, 0.18F);
			case PEN -> new InkPainter.Brush(color, size,
					this.penStyle == Tool.PenStyle.FELT ? InkPainter.Shape.SQUARE : InkPainter.Shape.ROUND,
					InkPainter.Mode.PAINT, this.penStyle.density, this.penStyle.alphaJitter);
		};
	}

	private ToolCursor.Effect drawEffect() {
		return switch (this.note.type.pen) {
			case CHALK -> ToolCursor.Effect.CHALK;
			case MARKER -> ToolCursor.Effect.MARKER;
			case QUILL -> ToolCursor.Effect.QUILL;
			case WHITE_PENCIL -> ToolCursor.Effect.PENCIL;
			case PEN -> switch (this.penStyle) {
				case PENCIL, CRAYON -> ToolCursor.Effect.PENCIL;
				case FELT -> ToolCursor.Effect.MARKER;
				default -> ToolCursor.Effect.PEN;
			};
		};
	}

	private ToolCursor.Effect eraseEffect() {
		return switch (this.note.type.eraser) {
			case PENCIL -> ToolCursor.Effect.CRUMBS;
			case DRY_ERASE -> ToolCursor.Effect.DRY_ERASER;
			case CHALK -> ToolCursor.Effect.CHALK_ERASER;
		};
	}

	// ------------------------------------------------------------------ zoom, scrolling, flipping

	private void setZoom(float newZoom, double anchorX, double anchorY) {
		newZoom = Mth.clamp(newZoom, 0.4F, ZOOMS[ZOOMS.length - 1]);
		if (newZoom == this.zoom) {
			return;
		}
		double docY = (anchorY - this.viewY() + this.scrollY) / this.zoom;
		double docX = (anchorX - this.viewX() + this.scrollX) / this.zoom;
		this.zoom = newZoom;
		this.scrollY = docY * this.zoom - (anchorY - this.viewY());
		this.scrollX = docX * this.zoom - (anchorX - this.viewX());
		this.clampScroll();
		this.flash(Component.translatable("scribble.status.zoom", Math.round(this.zoom * 100)));
	}

	private void zoomStep(int dir) {
		int idx = 0;
		for (int i = 0; i < ZOOMS.length; i++) {
			if (ZOOMS[i] <= this.zoom + 0.001F) {
				idx = i;
			}
		}
		float next = ZOOMS[Mth.clamp(idx + dir, 0, ZOOMS.length - 1)];
		if (dir < 0 && ZOOMS[idx] < this.zoom - 0.001F) {
			next = ZOOMS[idx];
		}
		this.setZoom(next, this.viewX() + this.viewW() / 2.0, this.viewY() + this.viewH() / 2.0);
	}

	private void scrollToPage(int page) {
		if (this.notebook) {
			this.flipToSpread(spreadOf(page));
			return;
		}
		this.scrollY = page * this.stride();
		this.clampScroll();
	}

	private void flipToSpread(int target) {
		target = Mth.clamp(target, 0, this.maxSpread());
		if (target == this.spread) {
			return;
		}
		this.flipFrom = this.spread;
		this.flipTo = target;
		this.flipStart = Util.getMillis();
		this.spread = target;
		Ui.pageTurn();
	}

	private void ensureCaretVisible() {
		if (this.width == 0) {
			return;
		}
		TextLayout.Line line = this.layout().lineOf(this.editor.cursor);
		if (this.notebook) {
			int target = spreadOf(line.page());
			if (target != this.spread) {
				this.flipToSpread(target);
			}
			return;
		}
		float top = this.pageY(line.page()) + line.slotTop() * this.zoom;
		float bottom = this.pageY(line.page()) + line.bottom() * this.zoom;
		if (top < this.viewY() + 8) {
			this.scrollY -= this.viewY() + 8 - top;
		} else if (bottom > this.viewY() + this.viewH() - 8) {
			this.scrollY += bottom - (this.viewY() + this.viewH() - 8);
		}
		this.clampScroll();
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		Ui.sprite(g, Sprites.DESK, 0, 0, this.width, this.height);
		Ui.cozyLight(g, this.width, this.height);
		this.dust.render(g, this.width, this.height);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		Anim.beginFrame();
		this.hs.clear();
		this.clampScroll();
		this.autoScroll(mouseX, mouseY);
		if (this.flipFrom >= 0 && !this.flipping()) {
			this.flipFrom = -1;
		}

		if (this.notebook) {
			this.renderNotebook(g, mouseX, mouseY);
		} else {
			this.renderPages(g, mouseX, mouseY);
		}
		this.renderViewScrollbars(g);
		this.renderStatusBar(g);
		this.renderToolRail(g, mouseX, mouseY);
		if (this.panelOpen) {
			this.renderPanel(g, mouseX, mouseY);
		}
		this.renderFormatBar(g, mouseX, mouseY);
		this.renderTopBar(g, mouseX, mouseY);

		Hotspots.Hotspot chrome = this.hs.at(mouseX, mouseY);
		boolean showTool = this.inView(mouseX, mouseY) && this.dialog == null && this.popup == null
				&& (chrome == null || (chrome.onClick == null && chrome.onDrag == null && !this.overChromePanel(mouseX, mouseY)))
				&& this.activeDrag == null;
		this.renderToolCursor(g, mouseX, mouseY, showTool);

		if (this.popup != null) {
			this.popup.render(g, this.hs, mouseX, mouseY);
		}
		if (this.dialog != null) {
			this.dialog.render(g, this.hs, this.width, this.height, mouseX, mouseY);
		}
		Notifications.render(g, this.hs, this.width - (this.panelOpen ? PANEL_W + 12 : 8), VIEW_Y + 4, mouseX, mouseY);

		Hotspots.Hotspot hover = this.hs.at(mouseX, mouseY);
		if (hover != null && (hover.onClick != null || hover.onDrag != null || hover.tooltip != null || !this.inView(mouseX, mouseY))) {
			if (hover.tooltip != null && this.activeDrag == null) {
				g.setTooltipForNextFrame(this.font, hover.tooltip, mouseX, mouseY);
			}
			if (hover.pointer && (hover.onClick != null || hover.onDrag != null)) {
				Ui.requestPointer(g);
			}
		} else if (this.inView(mouseX, mouseY) && this.dialog == null && this.popup == null) {
			if (this.panning || this.tool == Tool.PAN || this.spaceDown) {
				g.requestCursor(CursorTypes.RESIZE_ALL);
			} else if (this.tool == Tool.TEXT) {
				g.requestCursor(CursorTypes.IBEAM);
			} else {
				g.requestCursor(CursorTypes.CROSSHAIR);
			}
		}
		Ui.endFrame();
	}

	private boolean overChromePanel(double mx, double my) {
		int railH = Math.min(Math.max(1, (this.viewH() - 10) / 22), this.tools().size()) * 22 + 8;
		if (Ui.hovered(mx, my, 4, VIEW_Y + 2, this.railWidth(), railH)) {
			return true;
		}
		return this.panelOpen && mx >= this.width - PANEL_W - 4;
	}

	private void renderToolCursor(GuiGraphicsExtractor g, int mx, int my, boolean visible) {
		String icon;
		int ax = 2;
		int ay = 13;
		ToolCursor.Effect effect = ToolCursor.Effect.NONE;
		boolean active = this.drawing || this.shaping;
		Tool t = this.tool;
		if (this.panning || this.spaceDown || t == Tool.PAN) {
			icon = this.panning ? "tool_pan_grab" : "tool_pan";
			ax = 8;
			ay = 8;
		} else if (t == Tool.TEXT) {
			this.toolCursor.render(g, mx, my, "tool_text", 8, 8, false, ToolCursor.Effect.NONE, 0, false);
			return;
		} else if (t == Tool.ERASER || this.erasingWithRightButton) {
			icon = this.note.type.eraser.icon;
			ax = 8;
			ay = 12;
			effect = this.eraseEffect();
		} else if (t == Tool.STAMP) {
			icon = "tool_stamp";
			ax = 8;
			ay = 14;
		} else if (t == Tool.FILL) {
			icon = "tool_fill";
			ax = 13;
			ay = 13;
		} else if (t == Tool.HIGHLIGHTER) {
			icon = "tool_highlighter";
			effect = ToolCursor.Effect.HIGHLIGHTER;
		} else if (t == Tool.EYEDROPPER) {
			icon = "tool_eyedropper";
		} else {
			icon = this.toolIcon(Tool.PEN);
			effect = this.drawEffect();
		}
		this.toolCursor.render(g, mx, my, icon, ax, ay, active, effect, this.color(t == Tool.SHAPES ? Tool.SHAPES : Tool.PEN), visible);
	}

	private void autoScroll(double mx, double my) {
		if (!this.selecting && !this.drawing && !this.shaping) {
			return;
		}
		double before = this.scrollY;
		if (my < this.viewY() + 6) {
			this.scrollY -= 6;
		} else if (my > this.viewY() + this.viewH() - 6) {
			this.scrollY += 6;
		}
		this.clampScroll();
		if (this.selecting && before != this.scrollY) {
			this.updateSelection(mx, my);
		}
	}

	// --- documents

	private void renderPages(GuiGraphicsExtractor g, int mx, int my) {
		int vx = this.viewX();
		int vy = this.viewY();
		g.enableScissor(vx, vy, vx + this.viewW(), vy + this.viewH());
		TextLayout l = this.layout();
		int pages = this.pageCount();
		NoteType t = this.note.type;
		for (int page = 0; page < pages; page++) {
			float px = this.pageX(page);
			float py = this.pageY(page);
			if (py + (t.pageHeight + t.outerBottom) * this.zoom < vy || py - t.outerTop * this.zoom > vy + this.viewH()) {
				continue;
			}
			Ui.shadow(g, Math.round(px - t.outerLeft * this.zoom), Math.round(py - t.outerTop * this.zoom),
					Math.round(t.outerWidth() * this.zoom), Math.round(t.outerHeight() * this.zoom), 0.85F);
			PageRenderer.draw(g, this.note, l, this.metrics, page, pages, this.note.inkFor(page), px, py, this.zoom, true, true);
			this.renderPageOverlays(g, l, page, px, py, mx, my);
			String label = String.valueOf(page + 1);
			int lx = Math.round(px + t.pageWidth * this.zoom / 2) - this.font.width(label) / 2;
			int ly = Math.round(py + (t.pageHeight + t.outerBottom) * this.zoom) + 5;
			if (GAP * this.zoom >= 13) {
				Ui.textLight(g, label, lx, ly, Ui.TEXT_LIGHT_DIM);
			}
		}
		g.disableScissor();
	}

	private void renderPageOverlays(GuiGraphicsExtractor g, TextLayout l, int page, float px, float py, int mx, int my) {
		g.pose().pushMatrix();
		g.pose().translate(px, py);
		g.pose().scale(this.zoom, this.zoom);
		this.renderSelectionAndCaret(g, l, page);
		if (this.inView(mx, my) && this.pageAt(mx, my) == page && this.dialog == null && this.popup == null) {
			this.renderBrushPreview(g, this.toPageX(page, mx), this.toPageY(page, my));
		}
		g.pose().popMatrix();
	}

	// --- notebook

	private void renderNotebook(GuiGraphicsExtractor g, int mx, int my) {
		int vx = this.viewX();
		int vy = this.viewY();
		NoteType t = this.note.type;
		int w = t.pageWidth;
		int h = t.pageHeight;
		float z = this.zoom;
		float bx = this.bookX();
		float by = this.bookY();
		TextLayout l = this.layout();
		int pages = this.pageCount();
		int totalSpreads = this.maxSpread() + 1;

		g.enableScissor(vx, vy, vx + this.viewW(), vy + this.viewH());
		Ui.shadow(g, Math.round(bx - COVER * z), Math.round(by - COVER * z), Math.round((2 * w + SPINE + 2 * COVER) * z), Math.round((h + 2 * COVER) * z), 1.0F);

		g.pose().pushMatrix();
		g.pose().translate(bx, by);
		g.pose().scale(z, z);
		int cover = this.note.cover;
		g.fill(-COVER, -COVER, 2 * w + SPINE + COVER, h + COVER, Ui.INK);
		g.fill(-COVER + 1, -COVER + 1, 2 * w + SPINE + COVER - 1, h + COVER - 1, cover);
		Ui.sprite(g, Sprites.PAPER_GRAIN, -COVER + 1, -COVER + 1, 2 * w + SPINE + 2 * COVER - 2, h + 2 * COVER - 2);
		g.fill(-COVER + 1, -COVER + 1, 2 * w + SPINE + COVER - 1, -COVER + 2, 0x40FFFFFF);
		g.fill(-COVER + 1, h + COVER - 3, 2 * w + SPINE + COVER - 1, h + COVER - 1, 0x40000000);
		for (int sx = -COVER + 4; sx < 2 * w + SPINE + COVER - 4; sx += 6) {
			g.fill(sx, -COVER + 3, sx + 3, -COVER + 4, 0x70FFF0D0);
			g.fill(sx, h + COVER - 5, sx + 3, h + COVER - 4, 0x70FFF0D0);
		}
		g.fill(w, -COVER + 1, w + SPINE, h + COVER - 1, Ui.shade(cover, 0.75F));
		g.fill(w + SPINE / 2, -COVER + 1, w + SPINE / 2 + 1, h + COVER - 1, Ui.shade(cover, 0.6F));
		int right = Math.min(4, Math.max(0, totalSpreads - this.spread - 1));
		for (int i = right; i >= 1; i--) {
			g.fill(w + SPINE + i, i, 2 * w + SPINE + i, h + i, i % 2 == 0 ? 0xFFE8DCC4 : 0xFFD8CAB0);
		}
		int left = Math.min(4, this.spread);
		for (int i = left; i >= 1; i--) {
			g.fill(-i, i, w - i, h + i, i % 2 == 0 ? 0xFFE8DCC4 : 0xFFD8CAB0);
		}
		g.pose().popMatrix();

		float lx = bx;
		float rx = bx + (w + SPINE) * z;
		if (this.flipping()) {
			this.renderFlip(g, l, pages, lx, rx, by);
		} else {
			this.renderSpreadPage(g, l, pages, this.leftPage(), lx, by, mx, my);
			this.renderSpreadPage(g, l, pages, this.rightPage(), rx, by, mx, my);
			this.renderCornerCurls(g, mx, my, lx, rx, by);
		}

		g.pose().pushMatrix();
		g.pose().translate(bx, by);
		g.pose().scale(z, z);
		for (int i = 0; i < 10; i++) {
			int a = (int) (60 * Math.pow(1 - i / 10.0, 2));
			g.fill(w - 1 - i, 0, w - i, h, a << 24);
			g.fill(w + SPINE + i, 0, w + SPINE + i + 1, h, a << 24);
		}
		for (int i = 0; i < 3; i++) {
			int ry = h * (18 + i * 32) / 100;
			Ui.sprite(g, Sprites.RING, w - 13, ry - 7, SPINE + 26, 12);
		}
		g.pose().popMatrix();
		g.disableScissor();

		this.renderNotebookNav(g, mx, my, bx, by);
	}

	private void renderSpreadPage(GuiGraphicsExtractor g, TextLayout l, int pages, int page, float px, float py, int mx, int my) {
		if (page < 0) {
			this.renderInsideCover(g, px, py);
			return;
		}
		PageRenderer.draw(g, this.note, l, this.metrics, page, pages, this.note.inkFor(page), px, py, this.zoom, true, true);
		if (mx >= 0) {
			this.renderPageOverlays(g, l, page, px, py, mx, my);
		}
	}

	/** The inside of the front cover, with a cozy bookplate. */
	private void renderInsideCover(GuiGraphicsExtractor g, float px, float py) {
		NoteType t = this.note.type;
		g.pose().pushMatrix();
		g.pose().translate(px, py);
		g.pose().scale(this.zoom, this.zoom);
		int w = t.pageWidth;
		int h = t.pageHeight;
		g.fill(0, 0, w, h, Ui.shade(this.note.cover, 0.82F));
		Ui.sprite(g, Sprites.PAPER_GRAIN, 0, 0, w, h);
		int pw = 150;
		int ph = 70;
		int x0 = (w - pw) / 2;
		int y0 = h / 3;
		Ui.shadow(g, x0, y0, pw, ph, 0.6F);
		Ui.sprite(g, Sprites.CARD, x0, y0, pw, ph);
		Ui.centered(g, Component.translatable("scribble.notebook.belongs"), w / 2, y0 + 12, Ui.TEXT_DIM);
		String title = this.note.title.isBlank() ? Component.translatable("scribble.note.untitled").getString() : this.note.title;
		Ui.centered(g, Component.literal(Ui.ellipsize(title, pw - 16)), w / 2, y0 + 30, Ui.TEXT);
		g.fill(x0 + 14, y0 + 41, x0 + pw - 14, y0 + 42, 0x603B2A1E);
		String date = new java.text.SimpleDateFormat("MMM d, yyyy").format(new java.util.Date(this.note.created));
		Ui.centered(g, Component.literal(date), w / 2, y0 + 50, Ui.TEXT_DIM);
		g.pose().popMatrix();
	}

	/** A page turning around the spine, drawn as a horizontally squashed page with shading. */
	private void renderFlip(GuiGraphicsExtractor g, TextLayout l, int pages, float lx, float rx, float by) {
		float raw = Anim.clamp01((Util.getMillis() - this.flipStart) / (float) FLIP_MS);
		float t = Anim.easeInOutCubic(raw);
		boolean forward = this.flipTo > this.flipFrom;
		int fromLeft = this.flipFrom > 0 ? 2 * this.flipFrom - 1 : -1;
		int fromRight = 2 * this.flipFrom;
		int toLeft = this.flipTo > 0 ? 2 * this.flipTo - 1 : -1;
		int toRight = 2 * this.flipTo;
		NoteType nt = this.note.type;
		int w = nt.pageWidth;
		int h = nt.pageHeight;
		float z = this.zoom;
		this.renderSpreadPage(g, l, pages, forward ? fromLeft : toLeft, lx, by, -1, -1);
		this.renderSpreadPage(g, l, pages, forward ? toRight : fromRight, rx, by, -1, -1);
		float lift = (float) Math.sin(Math.PI * t);
		g.pose().pushMatrix();
		g.pose().translate(forward ? rx : lx, by);
		g.pose().scale(z, z);
		int shadowW = (int) (w * 0.45F * lift);
		for (int i = 0; i < shadowW; i += 2) {
			int a = (int) (80 * lift * (1 - i / (float) Math.max(1, shadowW)));
			int x = forward ? i : w - i - 2;
			g.fill(x, 0, x + 2, h, a << 24);
		}
		g.pose().popMatrix();

		float spineLeft = lx + w * z;
		int page;
		float sx;
		boolean onRight;
		if (t < 0.5F) {
			sx = (float) Math.cos(Math.PI * t);
			page = forward ? fromRight : fromLeft;
			onRight = forward;
		} else {
			sx = (float) -Math.cos(Math.PI * t);
			page = forward ? toLeft : toRight;
			onRight = !forward;
		}
		sx = Math.max(0.02F, sx);
		float sy = 1 + 0.045F * lift;
		g.pose().pushMatrix();
		float x = onRight ? rx : spineLeft - w * z * sx;
		g.pose().translate(x, by + h * z / 2);
		g.pose().scale(sx, sy);
		g.pose().translate(0, -h * z / 2);
		this.renderSpreadPage(g, l, pages, page, 0, 0, -1, -1);
		g.pose().scale(z, z);
		int shade = (int) (110 * (1 - sx));
		g.fill(0, 0, w, h, shade << 24 | 0x2A1A0E);
		int ex = onRight ? w - 3 : 0;
		g.fill(ex, 0, ex + 3, h, (int) (90 * lift) << 24 | 0xFFFFFF);
		g.pose().popMatrix();
	}

	/** Dog-eared corners that curl up under the mouse and flip the page when clicked. */
	private void renderCornerCurls(GuiGraphicsExtractor g, int mx, int my, float lx, float rx, float by) {
		NoteType t = this.note.type;
		int w = t.pageWidth;
		int h = t.pageHeight;
		float z = this.zoom;
		int c = 26;
		int cs = Math.round(c * z);
		if (this.spread < this.maxSpread()) {
			int x0 = Math.round(rx + (w - c) * z);
			int y0 = Math.round(by + (h - c) * z);
			boolean hover = this.dialog == null && this.popup == null && !this.drawing && Ui.hovered(mx, my, x0, y0, cs, cs);
			Ui.hoverSound("curlR", hover);
			float curl = Anim.bouncy("curlR", hover ? 1 : 0.18F);
			this.drawCurl(g, rx + w * z, by + h * z, curl * 20 * z, true);
			this.hs.add(x0, y0, cs, cs).tooltip(Component.translatable("scribble.notebook.next")).click(() -> this.flipToSpread(this.spread + 1));
		}
		if (this.spread > 0) {
			int x0 = Math.round(lx);
			int y0 = Math.round(by + (h - c) * z);
			boolean hover = this.dialog == null && this.popup == null && !this.drawing && Ui.hovered(mx, my, x0, y0, cs, cs);
			Ui.hoverSound("curlL", hover);
			float curl = Anim.bouncy("curlL", hover ? 1 : 0.18F);
			this.drawCurl(g, lx, by + h * z, curl * 20 * z, false);
			this.hs.add(x0, y0, cs, cs).tooltip(Component.translatable("scribble.notebook.prev")).click(() -> this.flipToSpread(this.spread - 1));
		}
	}

	/** Draws a folded triangle at a bottom corner (cx, cy) of size s. */
	private void drawCurl(GuiGraphicsExtractor g, float cx, float cy, float s, boolean rightCorner) {
		int size = Math.max(1, Math.round(s));
		int dir = rightCorner ? -1 : 1;
		int x = Math.round(cx);
		int y = Math.round(cy);
		for (int i = 0; i < size; i++) {
			int len = size - i;
			int rowY = y - 1 - i;
			if (rightCorner) {
				g.fill(x - len, rowY, x, rowY + 1, 0xFF6E4426);
			} else {
				g.fill(x, rowY, x + len, rowY + 1, 0xFF6E4426);
			}
		}
		for (int i = 0; i < size; i++) {
			int len = i + 1;
			int rowY = y - size + i;
			int sx = x + dir * size;
			int c = i == size - 1 ? Ui.INK : 0xFFEFE4CF;
			if (rightCorner) {
				g.fill(sx, rowY, sx + len, rowY + 1, c);
			} else {
				g.fill(sx - len, rowY, sx, rowY + 1, c);
			}
		}
		if (size > 2) {
			for (int i = 0; i < size; i++) {
				int px = x + dir * (size - i);
				int py = y - size + i;
				g.fill(px, py, px + 1, py + 1, 0x803B2A1E);
			}
		}
	}

	private void renderNotebookNav(GuiGraphicsExtractor g, int mx, int my, float bx, float by) {
		NoteType t = this.note.type;
		int cx = Math.round(bx + (2 * t.pageWidth + SPINE) * this.zoom / 2);
		int y = Math.min(this.viewY() + this.viewH() - 22, Math.round(by + (t.pageHeight + COVER) * this.zoom) + 6);
		int lp = this.leftPage();
		int rp = this.rightPage();
		String label = lp < 0 ? Component.translatable("scribble.notebook.page", rp + 1).getString()
				: Component.translatable("scribble.notebook.pages", lp + 1, rp + 1).getString();
		int lw = this.font.width(label) + 16;
		Ui.iconButton(g, this.hs, mx, my, cx - lw / 2 - 24, y, 20, "page_prev", Component.translatable("scribble.notebook.prev"),
				false, this.spread > 0, false, () -> this.flipToSpread(this.spread - 1));
		Ui.sprite(g, Sprites.CHIP, cx - lw / 2, y + 2, lw, 16);
		Ui.centered(g, Component.literal(label), cx, y + 6, Ui.TEXT);
		Ui.iconButton(g, this.hs, mx, my, cx + lw / 2 + 4, y, 20, "page_next", Component.translatable("scribble.notebook.next"),
				false, this.spread < this.maxSpread(), false, () -> this.flipToSpread(this.spread + 1));
	}

	// --- overlays

	private void renderSelectionAndCaret(GuiGraphicsExtractor g, TextLayout l, int page) {
		TextLayout.Pos s = this.editor.selStart();
		TextLayout.Pos e = this.editor.selEnd();
		boolean dark = this.note.type.isDarkSurface(this.note.paper);
		if (this.editor.hasSelection()) {
			int selColor = dark ? 0x60A0C8FF : 0x50FFB347;
			for (int i = l.firstLine[s.para()]; i <= l.lastLine[e.para()]; i++) {
				TextLayout.Line line = l.lines.get(i);
				if (line.page() != page) {
					continue;
				}
				int from = line.para() == s.para() ? Math.max(line.start(), s.offset()) : line.start();
				int to = line.para() == e.para() ? Math.min(line.end(), e.offset()) : line.end();
				boolean between = line.para() > s.para() && line.para() < e.para();
				if (from >= to && !(between && line.start() == line.end()) && !(line.para() < e.para() && to == line.end())) {
					continue;
				}
				int x0 = l.caretX(this.note, this.metrics, line, from);
				int x1 = l.caretX(this.note, this.metrics, line, to);
				if (line.para() < e.para() && to == line.end() && i == l.lastLine[line.para()]) {
					x1 += 3 * line.scale();
				}
				g.fill(x0, line.y() - line.scale(), Math.max(x1, x0 + 1), line.y() + 9 * line.scale(), selColor);
			}
		}
		if (this.tool == Tool.TEXT && this.dialog == null && !this.flipping() && (Util.getMillis() / 530) % 2 == 0) {
			TextLayout.Line line = l.lineOf(this.editor.cursor);
			if (line.page() == page) {
				int cx = l.caretX(this.note, this.metrics, line, this.editor.cursor.offset());
				int ts = this.note.type.textScale;
				int color = this.editor.currentFormat().color() != 0 ? this.editor.currentFormat().color() : this.note.defaultInk();
				g.fill(cx, line.y() - ts, cx + Math.max(1, ts), line.y() + 8 * line.scale() + ts, color | 0xFF000000);
			}
		}
	}

	private void renderBrushPreview(GuiGraphicsExtractor g, double px, double py) {
		boolean erase = this.tool == Tool.ERASER || this.erasingWithRightButton;
		if (!(this.tool == Tool.PEN || this.tool == Tool.HIGHLIGHTER || this.tool == Tool.SHAPES || erase)) {
			if (this.tool == Tool.STAMP) {
				int s = 16 * this.size(Tool.STAMP) / InkLayer.SCALE;
				int x = (int) Math.floor(px) - s / 2;
				int y = (int) Math.floor(py) - s / 2;
				Ui.sprite(g, Sprites.stamp(this.stamp), x, y, s, s, 0x90FFFFFF);
			}
			return;
		}
		InkPainter.Brush b = this.brush(this.tool, erase);
		float w = b.size() / (float) InkLayer.SCALE;
		float h = w;
		if (b.shape() == InkPainter.Shape.WIDE) {
			h = Math.max(1, w / 2);
		} else if (b.shape() == InkPainter.Shape.CHISEL) {
			w = Math.max(1, w / 3);
		}
		int x0 = (int) Math.floor(px - w / 2);
		int y0 = (int) Math.floor(py - h / 2);
		int x1 = (int) Math.ceil(px + w / 2);
		int y1 = (int) Math.ceil(py + h / 2);
		boolean dark = this.note.type.isDarkSurface(this.note.paper);
		int col = erase ? (dark ? 0xA0FFFFFF : 0xA0000000) : (b.color() | 0xFF000000);
		if (!erase && x1 - x0 <= 2) {
			g.fill(x0, y0, x1, y1, col);
			return;
		}
		g.outline(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), col);
	}

	private void renderViewScrollbars(GuiGraphicsExtractor g) {
		int x = this.viewX() + this.viewW() - 7;
		Ui.scrollbar(g, this.hs, x, this.viewY() + 2, this.viewH() - 4, this.scrollY, this.maxScrollY(), (mx, my) -> {
			double frac = (my - this.viewY()) / Math.max(1, this.viewH());
			this.scrollY = frac * this.maxScrollY();
			this.clampScroll();
		});
		if (this.maxScrollX() > 0) {
			int y = this.viewY() + this.viewH() - 6;
			int w = this.viewW() - 12;
			g.fill(this.viewX() + 2, y, this.viewX() + 2 + w, y + 4, 0xA06E4426);
			int thumb = Math.max(16, (int) (w * w / (w + this.maxScrollX())));
			int tx = this.viewX() + 2 + (int) ((w - thumb) * (this.scrollX / this.maxScrollX()));
			g.fill(tx, y, tx + thumb, y + 4, Ui.CREAM);
			this.hs.add(this.viewX() + 2, y - 2, w, 8).drag((mx, my) -> {
				this.scrollX = (mx - this.viewX()) / Math.max(1, w) * this.maxScrollX();
				this.clampScroll();
			});
		}
	}

	// --- top bar

	private void renderTopBar(GuiGraphicsExtractor g, int mx, int my) {
		Ui.shadow(g, -10, -10, this.width + 20, TOP_H + 10, 0.7F);
		Ui.sprite(g, Sprites.TOOLBAR_LIGHT, -2, -2, this.width + 4, TOP_H + 2);
		this.hs.add(0, 0, this.width, TOP_H).noPointer();
		Ui.iconButton(g, this.hs, mx, my, 4, 3, 20, "back", Component.translatable("scribble.editor.back"), false, true, true, this::onClose);
		Ui.icon(g, this.note.type.iconName(), 28, 5);

		int right = this.width - 4;
		right -= 20;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "panel", Component.translatable("scribble.editor.panel"), this.panelOpen, true, true, () -> {
			this.panelOpen = !this.panelOpen;
			this.clampScroll();
		});
		right -= 22;
		int exportX = right;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "export", Component.translatable("scribble.editor.export"), false, true, true,
				() -> this.openPopup(this.exportMenu(), exportX - 60, TOP_H));
		right -= 22;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, ScribbleSettings.sounds ? "sound_on" : "sound_off",
				Component.translatable(ScribbleSettings.sounds ? "scribble.settings.sounds_on" : "scribble.settings.sounds_off"), false, true, true,
				() -> this.openPopup(this.soundMenu(), exportX - 80, TOP_H));
		right -= 8;
		Ui.vgroove(g, right + 3, 6, TOP_H - 6);
		right -= 22;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "zoom_in", Component.translatable("scribble.editor.zoom_in"), false, true, true, () -> this.zoomStep(1));
		String zl = Math.round(this.zoom * 100) + "%";
		int zw = 36;
		right -= zw;
		int zoomX = right;
		Ui.textButton(g, this.hs, mx, my, right, 5, zw, 16, Component.literal(zl), true, () -> this.openPopup(this.zoomMenu(), zoomX, TOP_H));
		right -= 21;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "zoom_out", Component.translatable("scribble.editor.zoom_out"), false, true, true, () -> this.zoomStep(-1));
		right -= 8;
		Ui.vgroove(g, right + 3, 6, TOP_H - 6);
		right -= 22;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "redo", Component.translatable("scribble.editor.redo"), false, this.history.canRedo(), true, this::redo);
		right -= 20;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, "undo", Component.translatable("scribble.editor.undo"), false, this.history.canUndo(), true, this::undo);
		right -= 22;
		Ui.iconButton(g, this.hs, mx, my, right, 3, 20, this.note.starred ? "star_filled" : "star",
				Component.translatable(this.note.starred ? "scribble.note.unstar" : "scribble.note.star"), false, true, true, () -> {
					this.note.starred = !this.note.starred;
					this.markChanged();
					if (this.note.starred) {
						Notifications.info("star_filled", Component.translatable("scribble.notify.starred"), null);
					}
				});

		int titleX = 48;
		int titleMax = right - titleX - 8;
		String title = this.note.title.isBlank() ? Component.translatable("scribble.note.untitled").getString() : this.note.title;
		String shown = Ui.ellipsize(title, titleMax);
		int tw = this.font.width(shown);
		boolean th = Ui.hovered(mx, my, titleX - 3, 5, tw + 6, 16);
		Ui.hoverSound("title", th);
		if (th) {
			Ui.sprite(g, Sprites.BUTTON_HOVER, titleX - 4, 4, tw + 8, 18);
		}
		Ui.text(g, shown, titleX, 9, this.note.title.isBlank() ? Ui.TEXT_DIM : Ui.TEXT);
		this.hs.add(titleX - 4, 4, tw + 8, 18).tooltip(Component.translatable("scribble.note.rename")).click(this::renameDialog);
	}

	// --- format bar

	private int formatBarWidth() {
		return 4 + 72 + 6 + 4 * 18 + 7 + 2 * 18 + 7 + 3 * 18 + 7 + 6 * 18 + 7 + 2 * 18 + 4;
	}

	private void renderFormatBar(GuiGraphicsExtractor g, int mx, int my) {
		int fw = this.formatBarWidth();
		int x0 = Math.max(4, this.viewX() + (this.viewW() - fw) / 2);
		if (x0 + fw > this.width - 4) {
			x0 = Math.max(4, this.width - 4 - fw);
		}
		int y = FMT_Y;
		Ui.panel(g, x0, y, fw, FMT_H + 1);
		this.hs.add(x0, y, fw, FMT_H).noPointer();
		int x = x0 + 4;
		int by = y + 2;

		int sw = 72;
		int styleX = x;
		Component styleName = Component.literal(Ui.ellipsize(Component.translatable(this.editor.currentStyle().translationKey()).getString(), sw - 18));
		Ui.textButton(g, this.hs, mx, my, x, by, sw, 18, styleName, true, () -> this.openPopup(this.styleMenu(), styleX, y + FMT_H + 2));
		this.triangle(g, x + sw - 10, by + 8, Ui.TEXT);
		x += sw + 6;

		x = this.fmtToggle(g, mx, my, x, by, "bold", "scribble.format.bold", "Ctrl+B", TextFormat.Flag.BOLD);
		x = this.fmtToggle(g, mx, my, x, by, "italic", "scribble.format.italic", "Ctrl+I", TextFormat.Flag.ITALIC);
		x = this.fmtToggle(g, mx, my, x, by, "underline", "scribble.format.underline", "Ctrl+U", TextFormat.Flag.UNDERLINE);
		x = this.fmtToggle(g, mx, my, x, by, "strike", "scribble.format.strike", "Alt+Shift+5", TextFormat.Flag.STRIKE);
		x = this.fmtSep(g, x, y);

		TextFormat cf = this.editor.currentFormat();
		int textColor = cf.color() != 0 ? cf.color() : this.note.defaultInk();
		int colorX = x;
		Ui.iconButton(g, this.hs, mx, my, x, by, 18, "text_color", Component.translatable("scribble.format.color"), false, true, true,
				() -> this.openPopup(this.allColors(cf.color(), true, c -> {
					this.editor.setColor(c);
					this.setTool(Tool.TEXT);
				}), colorX, y + FMT_H + 2));
		g.fill(x + 3, by + 13, x + 15, by + 16, Ui.INK);
		g.fill(x + 4, by + 14, x + 14, by + 15, textColor | 0xFF000000);
		x += 18;
		int hlX = x;
		Ui.iconButton(g, this.hs, mx, my, x, by, 18, "highlight", Component.translatable("scribble.format.highlight"), false, true, true,
				() -> this.openPopup(new Popup.Swatches(cf.highlight(), true, c -> {
					this.editor.setHighlight(c);
					this.setTool(Tool.TEXT);
				}).section(Component.translatable("scribble.color.highlights"), HIGHLIGHTS), hlX, y + FMT_H + 2));
		g.fill(x + 3, by + 13, x + 15, by + 16, Ui.INK);
		g.fill(x + 4, by + 14, x + 14, by + 15, cf.highlight() != 0 ? cf.highlight() | 0xFF000000 : 0xFFFFFFFF);
		x += 18;
		x = this.fmtSep(g, x, y);

		Align align = this.editor.currentAlign();
		x = this.fmtButton(g, mx, my, x, by, "align_left", "scribble.format.align_left", null, align == Align.LEFT, () -> this.editor.setAlign(Align.LEFT));
		x = this.fmtButton(g, mx, my, x, by, "align_center", "scribble.format.align_center", null, align == Align.CENTER, () -> this.editor.setAlign(Align.CENTER));
		x = this.fmtButton(g, mx, my, x, by, "align_right", "scribble.format.align_right", null, align == Align.RIGHT, () -> this.editor.setAlign(Align.RIGHT));
		x = this.fmtSep(g, x, y);

		ParaStyle ps = this.editor.currentStyle();
		x = this.fmtButton(g, mx, my, x, by, "list_bullet", "scribble.style.bullet", "Ctrl+Shift+8", ps == ParaStyle.BULLET, () -> this.editor.setStyle(ParaStyle.BULLET));
		x = this.fmtButton(g, mx, my, x, by, "list_number", "scribble.style.numbered", "Ctrl+Shift+7", ps == ParaStyle.NUMBERED, () -> this.editor.setStyle(ParaStyle.NUMBERED));
		x = this.fmtButton(g, mx, my, x, by, "list_check", "scribble.style.checklist", "Ctrl+Shift+9", ps == ParaStyle.CHECKLIST, () -> this.editor.setStyle(ParaStyle.CHECKLIST));
		x = this.fmtButton(g, mx, my, x, by, "quote", "scribble.style.quote", null, ps == ParaStyle.QUOTE, () -> this.editor.setStyle(ParaStyle.QUOTE));
		x = this.fmtButton(g, mx, my, x, by, "indent_less", "scribble.format.outdent", "Shift+Tab", false, () -> this.editor.indent(-1));
		x = this.fmtButton(g, mx, my, x, by, "indent_more", "scribble.format.indent", "Tab", false, () -> this.editor.indent(1));
		x = this.fmtSep(g, x, y);

		x = this.fmtButton(g, mx, my, x, by, "page_break", "scribble.format.page_break", "Ctrl+Enter", false, () -> {
			this.setTool(Tool.TEXT);
			this.editor.insertPageBreak();
			Ui.pageTurn();
		});
		this.fmtButton(g, mx, my, x, by, "page_add", this.note.type.board ? "scribble.pages.add_board" : "scribble.pages.add", null, false, this::addPage);
	}

	private void triangle(GuiGraphicsExtractor g, int x, int y, int color) {
		g.fill(x, y, x + 5, y + 1, color);
		g.fill(x + 1, y + 1, x + 4, y + 2, color);
		g.fill(x + 2, y + 2, x + 3, y + 3, color);
	}

	private int fmtSep(GuiGraphicsExtractor g, int x, int y) {
		Ui.vgroove(g, x + 3, y + 5, y + FMT_H - 4);
		return x + 7;
	}

	private int fmtButton(GuiGraphicsExtractor g, int mx, int my, int x, int y, String icon, String key, @Nullable String shortcut,
						  boolean selected, Runnable action) {
		Component tip = Component.translatable(key);
		if (shortcut != null) {
			tip = tip.copy().append(Component.literal("  " + shortcut).withStyle(s -> s.withColor(0xA0A0A0)));
		}
		Ui.iconButton(g, this.hs, mx, my, x, y, 18, icon, tip, selected, true, true, action);
		return x + 18;
	}

	private int fmtToggle(GuiGraphicsExtractor g, int mx, int my, int x, int y, String icon, String key, String shortcut, TextFormat.Flag flag) {
		return this.fmtButton(g, mx, my, x, y, icon, key, shortcut, this.editor.isActive(flag), () -> this.editor.toggle(flag));
	}

	// --- tool rail

	private void renderToolRail(GuiGraphicsExtractor g, int mx, int my) {
		int top = VIEW_Y + 2;
		int w = this.railWidth();
		List<Tool> tools = this.tools();
		int perCol = Math.max(1, (this.viewH() - 10) / 22);
		int rows = Math.min(perCol, tools.size());
		Ui.panel(g, 4, top, w, rows * 22 + 8);
		this.hs.add(4, top, w, rows * 22 + 8).noPointer();
		for (int i = 0; i < tools.size(); i++) {
			Tool t = tools.get(i);
			int x = 8 + (i / perCol) * 22;
			int y = top + 4 + (i % perCol) * 22;
			Component tip = Component.translatable(t.translationKey(this.note.type));
			String key = t.hotkey != ' ' ? String.valueOf(Character.toUpperCase(t.hotkey)) : "Space";
			tip = tip.copy().append(Component.literal("  " + key).withStyle(s -> s.withColor(0xA0A0A0)));
			String icon = t == Tool.PAN && this.panning ? "tool_pan_grab" : this.toolIcon(t);
			Ui.iconButton(g, this.hs, mx, my, x, y, 20, icon, tip, this.tool == t, true, false, () -> {
				this.setTool(t);
				Ui.pop();
			});
		}
	}

	// --- properties panel

	private void renderPanel(GuiGraphicsExtractor g, int mx, int my) {
		int x0 = this.width - PANEL_W - 4;
		int y0 = VIEW_Y + 2;
		int h = this.viewH() - 4;
		Ui.panel(g, x0, y0, PANEL_W, h);
		this.panelScroll = Mth.clamp(this.panelScroll, 0, Math.max(0, this.panelContentHeight - h + 6));
		this.hs.add(x0, y0, PANEL_W, h).noPointer();

		g.enableScissor(x0 + 2, y0 + 2, x0 + PANEL_W - 2, y0 + h - 4);
		this.hs.clip(x0 + 2, y0 + 2, x0 + PANEL_W - 2, y0 + h - 4);
		int x = x0 + 8;
		int cw = PANEL_W - 18;
		int cy = y0 + 6 - (int) this.panelScroll;
		int startY = cy;

		Ui.animatedIcon(g, this.toolIcon(this.tool), x - 2, cy - 3, 1.0F, true, "panelTool");
		Ui.text(g, Component.translatable(this.tool.translationKey(this.note.type)), x + 16, cy + 1, Ui.ACCENT);
		cy += 15;

		switch (this.tool) {
			case TEXT -> {
				cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.text_color"));
				TextFormat cf = this.editor.currentFormat();
				int current = cf.color() != 0 ? cf.color() : this.note.defaultInk();
				cy = this.colorPicker(g, mx, my, x, cy, this.note.type.palette, current, this.editor::setColor);
				cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.highlight"));
				int[] hl = new int[HIGHLIGHTS.length + 1];
				System.arraycopy(HIGHLIGHTS, 0, hl, 1, HIGHLIGHTS.length);
				cy = this.swatchGrid(g, mx, my, x, cy, hl, null, cf.highlight(), this.editor::setHighlight);
			}
			case PEN, HIGHLIGHTER, SHAPES, FILL -> {
				cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.color"));
				Tool t = this.tool;
				cy = this.colorPicker(g, mx, my, x, cy, this.paletteFor(t), this.color(t), c -> this.setColor(t, c));
			}
			default -> {
			}
		}

		if (this.tool.usesSize()) {
			cy = this.section(g, x, cw, cy, Component.translatable(this.tool == Tool.STAMP ? "scribble.panel.scale" : "scribble.panel.size"));
			cy = this.slider(g, mx, my, x, cy, cw, this.tool);
		}

		if (this.tool == Tool.PEN && this.note.type.pen == NoteType.PenKind.PEN) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.pen_style"));
			int bx = x;
			for (Tool.PenStyle style : Tool.PenStyle.values()) {
				Ui.iconButton(g, this.hs, mx, my, bx, cy, 20, style.icon, Component.translatable("scribble.pen_style." + style.id),
						this.penStyle == style, true, false, () -> this.penStyle = style);
				bx += 22;
			}
			cy += 25;
		}

		if (this.tool == Tool.SHAPES) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.shape"));
			int bx = x;
			for (Tool.Shape s : Tool.Shape.values()) {
				Ui.iconButton(g, this.hs, mx, my, bx, cy, 20, s.icon, Component.translatable("scribble.shape." + s.id),
						this.shape == s, true, false, () -> this.shape = s);
				bx += 22;
			}
			cy += 25;
			if (this.shape != Tool.Shape.LINE) {
				int cx = x;
				cx += Ui.chip(g, this.hs, mx, my, cx, cy, Component.translatable("scribble.shape.outline"), null, !this.shapeFilled, () -> this.shapeFilled = false) + 3;
				Ui.chip(g, this.hs, mx, my, cx, cy, Component.translatable("scribble.shape.filled"), null, this.shapeFilled, () -> this.shapeFilled = true);
				cy += 20;
			}
		}

		if (this.tool == Tool.STAMP) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.stamps"));
			for (int i = 0; i < Sprites.STAMPS.length; i++) {
				String name = Sprites.STAMPS[i];
				int bx = x + (i % 4) * 23;
				int by = cy + (i / 4) * 23;
				boolean sel = this.stamp.equals(name);
				boolean hov = Ui.hovered(mx, my, bx, by, 21, 21);
				Ui.hoverSound("stamp" + name, hov);
				float s = Anim.bouncy("stamp" + name, hov ? 1.15F : 1.0F);
				Ui.pushScale(g, bx + 10.5F, by + 10.5F, s);
				Ui.sprite(g, sel ? Sprites.BUTTON_SELECTED : hov ? Sprites.BUTTON_HOVER : Sprites.BUTTON, bx, by, 21, 21);
				Ui.sprite(g, Sprites.stamp(name), bx + 2, by + 2, 16, 16);
				Ui.popScale(g);
				this.hs.add(bx, by, 21, 21).tooltip(Component.translatable("scribble.stamp." + name)).click(() -> {
					Ui.click();
					this.stamp = name;
				});
			}
			cy += ((Sprites.STAMPS.length + 3) / 4) * 23 + 2;
		}

		if (this.tool == Tool.ERASER) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.page"));
			Ui.textButton(g, this.hs, mx, my, x, cy, cw, 18, Component.translatable("scribble.panel.clear_page"), true, this::confirmClearPage);
			cy += 22;
		}

		if (this.tool == Tool.TEXT || this.tool == Tool.EYEDROPPER || this.tool == Tool.PAN || this.tool == Tool.FILL) {
			cy += 2;
			Component hint = Component.translatable("scribble.hint." + this.tool.id);
			for (var line : this.font.split(hint, cw)) {
				g.text(this.font, line, x, cy, Ui.TEXT_DIM, false);
				cy += 10;
			}
			cy += 4;
		}

		if (this.notebook) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.cover"));
			cy = this.swatchGrid(g, mx, my, x, cy, NoteType.COVERS, null, this.note.cover, c -> {
				this.note.cover = c;
				this.markChanged();
			});
		}

		if (this.note.type.paperColors) {
			cy = this.section(g, x, cw, cy, Component.translatable("scribble.panel.paper"));
			PaperColor[] papers = PaperColor.values();
			for (int i = 0; i < papers.length; i++) {
				PaperColor pc = papers[i];
				int sx = x + (i % 6) * 15;
				int sy = cy + (i / 6) * 15;
				Ui.swatch(g, this.hs, mx, my, sx, sy, 12, pc.argb, this.note.paper == pc, Component.translatable(pc.translationKey()), () -> {
					this.note.paper = pc;
					this.markChanged();
				});
			}
			cy += ((papers.length + 5) / 6) * 15 + 2;
		}

		cy = this.renderPagesSection(g, mx, my, x, cw, cy);

		this.panelContentHeight = cy - startY + 6;
		g.disableScissor();
		this.hs.unclip();
		if (this.panelContentHeight > h - 6) {
			Ui.scrollbar(g, this.hs, x0 + PANEL_W - 9, y0 + 5, h - 12, this.panelScroll, this.panelContentHeight - h + 6, (dmx, dmy) -> {
				this.panelScroll = (dmy - y0) / h * (this.panelContentHeight - h + 6);
			});
		}
	}

	private int section(GuiGraphicsExtractor g, int x, int w, int cy, Component title) {
		cy += 4;
		Ui.text(g, title, x, cy, Ui.TEXT_DIM);
		cy += 10;
		Ui.groove(g, x, x + w, cy);
		return cy + 5;
	}

	private int swatchGrid(GuiGraphicsExtractor g, int mx, int my, int x, int cy, int[] palette, Component @Nullable [] names,
						   int selected, java.util.function.IntConsumer onPick) {
		for (int i = 0; i < palette.length; i++) {
			int c = palette[i];
			int sx = x + (i % 6) * 15;
			int sy = cy + (i / 6) * 15;
			Ui.swatch(g, this.hs, mx, my, sx, sy, 12, c, c == selected, names != null ? names[i] : null, () -> onPick.accept(c));
		}
		return cy + ((palette.length + 5) / 6) * 15 + 2;
	}

	/** The note's own palette plus every Minecraft color, grouped into dyes, chat colors and block colors. */
	private int colorPicker(GuiGraphicsExtractor g, int mx, int my, int x, int cy, int[] kit, int selected,
							java.util.function.IntConsumer onPick) {
		cy = this.swatchGrid(g, mx, my, x, cy, kit, null, selected, onPick);
		cy += 2;
		// segmented tabs: Dyes | Chat | Blocks
		MinecraftColors.Group[] groups = MinecraftColors.Group.values();
		int textSum = 0;
		for (MinecraftColors.Group group : groups) {
			textSum += this.font.width(Component.translatable("scribble.color.group." + group.id));
		}
		int extra = Math.max(0, (PANEL_W - 18 - textSum) / groups.length);
		int tx = x;
		for (int i = 0; i < groups.length; i++) {
			MinecraftColors.Group group = groups[i];
			int tabW = this.font.width(Component.translatable("scribble.color.group." + group.id)) + extra;
			boolean sel = this.colorGroup == group;
			boolean hov = Ui.hovered(mx, my, tx, cy, tabW, 15);
			Ui.hoverSound("tab" + group, hov);
			Ui.sprite(g, sel ? Sprites.CHIP_SELECTED : hov ? Sprites.CHIP_HOVER : Sprites.CHIP, tx, cy, tabW - 1, 15);
			String label = Component.translatable("scribble.color.group." + group.id).getString();
			Ui.centered(g, Component.literal(label), tx + tabW / 2, cy + 3, sel ? 0xFF4A2A08 : Ui.TEXT);
			this.hs.add(tx, cy, tabW - 1, 15).click(() -> {
				Ui.click();
				this.colorGroup = group;
			});
			tx += tabW;
		}
		cy += 19;
		List<MinecraftColors.Swatch> swatches = MinecraftColors.get(this.colorGroup);
		Component[] names = new Component[swatches.size()];
		for (int i = 0; i < names.length; i++) {
			names[i] = swatches.get(i).name();
		}
		return this.swatchGrid(g, mx, my, x, cy, MinecraftColors.argb(swatches), names, selected, onPick);
	}

	private Popup allColors(int selected, boolean allowNone, java.util.function.IntConsumer onPick) {
		return new Popup.Swatches(selected, allowNone, onPick).columns(12)
				.section(Component.translatable("scribble.color.palette"), this.note.type.palette)
				.section(Component.translatable("scribble.color.group.dyes"), MinecraftColors.dyes())
				.section(Component.translatable("scribble.color.group.chat"), MinecraftColors.chat())
				.section(Component.translatable("scribble.color.group.blocks"), MinecraftColors.blocks());
	}

	private int slider(GuiGraphicsExtractor g, int mx, int my, int x, int cy, int w, Tool t) {
		int max = this.maxSize(t);
		int value = this.size(t);
		int trackW = w - 22;
		Ui.sprite(g, Sprites.SLIDER_TRACK, x, cy + 3, trackW, 6);
		int kx = x + (int) ((trackW - 8) * ((value - 1) / (float) (max - 1)));
		g.fill(x + 1, cy + 4, kx + 4, cy + 8, Ui.ACCENT_SOFT);
		boolean hov = Ui.hovered(mx, my, x, cy, trackW, 12);
		float s = Anim.bouncy("slider" + t, hov || this.activeDrag != null ? 1.2F : 1.0F);
		Ui.pushScale(g, kx + 4, cy + 6, s);
		Ui.sprite(g, Sprites.SLIDER_KNOB, kx, cy, 8, 12);
		Ui.popScale(g);
		Ui.text(g, String.valueOf(value), x + trackW + 5, cy + 2, Ui.TEXT);
		this.hs.add(x, cy, trackW, 12).drag((dmx, dmy) -> {
			float f = (float) Mth.clamp((dmx - x - 4) / (trackW - 8), 0, 1);
			int nv = 1 + Math.round(f * (max - 1));
			if (nv != this.size(t)) {
				ScribbleSounds.play(ScribbleSounds.HOVER, 0.8F + nv / (float) max, 0.15F);
			}
			this.sizes.put(t, nv);
		});
		cy += 16;
		if (t != Tool.STAMP) {
			InkPainter.Brush b = this.brush(t, false);
			int pw = Math.max(1, Math.min(w, b.size() * 2));
			int ph = pw;
			if (b.shape() == InkPainter.Shape.WIDE) {
				ph = Math.max(1, pw / 2);
			} else if (b.shape() == InkPainter.Shape.CHISEL) {
				pw = Math.max(1, pw / 3);
			}
			int boxH = Math.min(64, Math.max(ph, 6)) + 8;
			g.fill(x, cy, x + w, cy + boxH, this.surfaceColor());
			g.outline(x, cy, w, boxH, Ui.INK);
			int col = t == Tool.ERASER ? (this.note.type.isDarkSurface(this.note.paper) ? 0x60FFFFFF : 0x60000000) : (b.color() | 0xFF000000);
			int px = x + (w - pw) / 2;
			int py = cy + (boxH - Math.min(ph, 64)) / 2;
			g.fill(px, py, px + pw, py + Math.min(ph, 64), col);
			cy += boxH + 4;
		} else {
			int s2 = 16 * this.size(Tool.STAMP) / 2;
			int ds = Math.min(48, s2);
			int box = ds + 8;
			g.fill(x, cy, x + w, cy + box, this.surfaceColor());
			g.outline(x, cy, w, box, Ui.INK);
			Ui.sprite(g, Sprites.stamp(this.stamp), x + (w - ds) / 2, cy + 4, ds, ds);
			cy += box + 4;
		}
		return cy;
	}

	/** Approximate color of the writing surface, for previews. */
	private int surfaceColor() {
		return switch (this.note.type) {
			case WHITEBOARD -> 0xFFF4F6F8;
			case CHALKBOARD -> 0xFF2D4636;
			case BLUEPRINT -> 0xFF1F4F8F;
			case PARCHMENT -> 0xFFE8D3A2;
			default -> this.note.paper.argb;
		};
	}

	private int renderPagesSection(GuiGraphicsExtractor g, int mx, int my, int x, int cw, int cy) {
		int pages = this.pageCount();
		boolean board = this.note.type.board;
		cy += 4;
		Ui.text(g, Component.translatable(board ? "scribble.panel.boards" : "scribble.panel.pages", pages), x, cy + 5, Ui.TEXT_DIM);
		Ui.iconButton(g, this.hs, mx, my, x + cw - 38, cy, 18, "page_add",
				Component.translatable(board ? "scribble.pages.add_board" : "scribble.pages.add"), false, true, true, this::addPage);
		Ui.iconButton(g, this.hs, mx, my, x + cw - 19, cy, 18, "trash",
				Component.translatable(board ? "scribble.pages.remove_board" : "scribble.pages.remove"), false, pages > 1 || this.note.inkFor(0) != null, true, this::confirmRemovePage);
		cy += 21;
		Ui.groove(g, x, x + cw, cy);
		cy += 6;
		NoteType t = this.note.type;
		int thumbW = (cw - 6) / 2;
		int thumbH = Math.round(thumbW * (float) t.outerHeight() / t.outerWidth());
		int current = this.currentPage();
		TextLayout l = this.layout();
		for (int page = 0; page < pages; page++) {
			int tx = x + (page % 2) * (thumbW + 6);
			int ty = cy + (page / 2) * (thumbH + 15);
			boolean hov = Ui.hovered(mx, my, tx, ty, thumbW, thumbH);
			Ui.hoverSound("thumb" + page, hov);
			float s = Anim.bouncy("thumb" + page, hov ? 1.06F : 1.0F);
			Ui.pushScale(g, tx + thumbW / 2.0F, ty + thumbH / 2.0F, s);
			Ui.shadow(g, tx, ty, thumbW, thumbH, 0.4F);
			PageRenderer.thumbnail(g, this.note, l, this.metrics, page, pages, this.note.inkFor(page), tx, ty, thumbW, thumbH);
			boolean visible = this.notebook ? page == this.leftPage() || page == this.rightPage() : page == current;
			if (visible) {
				g.outline(tx - 2, ty - 2, thumbW + 4, thumbH + 4, Ui.ACCENT);
			}
			Ui.popScale(g);
			String label = String.valueOf(page + 1);
			Ui.text(g, label, tx + thumbW / 2 - this.font.width(label) / 2, ty + thumbH + 4, visible ? Ui.ACCENT : Ui.TEXT_DIM);
			int target = page;
			this.hs.add(tx, ty, thumbW, thumbH).tooltip(Component.translatable("scribble.pages.go", page + 1)).click(() -> {
				Ui.click();
				this.scrollToPage(target);
			});
		}
		cy += ((pages + 1) / 2) * (thumbH + 15);
		return cy;
	}

	private void renderStatusBar(GuiGraphicsExtractor g) {
		int y = this.height - STATUS_H;
		Ui.sprite(g, Sprites.TOOLBAR, -2, y, this.width + 4, STATUS_H + 2);
		int pages = this.pageCount();
		int shownPage = this.currentPage() + 1;
		String left = Component.translatable(this.note.type.board ? "scribble.status.board" : "scribble.status.page", shownPage, Math.max(pages, shownPage)).getString()
				+ "  ·  " + Component.translatable("scribble.status.words", this.note.wordCount()).getString()
				+ "  ·  " + Component.translatable("scribble.status.chars", this.note.charCount()).getString();
		Ui.textLight(g, left, 6, y + 4, Ui.TEXT_LIGHT_DIM);

		Component right = this.dirty ? Component.translatable("scribble.status.unsaved") : Component.translatable("scribble.status.saved");
		int rw = this.font.width(right);
		Ui.textLight(g, right, this.width - rw - 8, y + 4, this.dirty ? 0xFFFFD27A : 0xFFB8F0A0);

		boolean flashing = this.flash != null && Util.getMillis() - this.flashTime < 2500;
		Component middle = flashing ? this.flash : Component.translatable("scribble.hint.status." + this.tool.id);
		int lw = this.font.width(left);
		int space = this.width - lw - rw - 34;
		if (space > 40) {
			String m = Ui.ellipsize(middle.getString(), space);
			int mxp = 6 + lw + 12 + (space - this.font.width(m)) / 2;
			Ui.textLight(g, m, mxp, y + 4, flashing ? Ui.ACCENT_SOFT : Ui.TEXT_LIGHT_DIM);
		}
	}

	// ------------------------------------------------------------------ menus & dialogs

	private void openPopup(Popup p, int x, int y) {
		p.setCloser(() -> {
			if (this.popup == p) {
				this.popup = null;
			}
		});
		p.at(x, y, this.width, this.height);
		this.popup = p;
		Ui.pop();
	}

	private void openDialog(Dialog d) {
		d.setCloser(() -> {
			if (this.dialog == d) {
				this.dialog = null;
			}
		});
		this.popup = null;
		this.dialog = d;
		Ui.pop();
	}

	private Popup exportMenu() {
		Popup.Menu menu = new Popup.Menu();
		menu.header(Component.translatable("scribble.export.header"));
		for (NoteExporter.Format f : NoteExporter.Format.values()) {
			menu.item(f.icon, Component.translatable(f.translationKey()), () -> this.export(f));
		}
		menu.separator();
		menu.item("copy", Component.translatable("scribble.export.copy_text"), () -> {
			this.minecraft.keyboardHandler.setClipboard(NoteExporter.toPlainText(this.note));
			Notifications.success("copy", Component.translatable("scribble.status.copied"), null);
		});
		menu.item("folder", Component.translatable("scribble.export.open_folder"), this::openExports);
		return menu;
	}

	private void openExports() {
		try {
			Files.createDirectories(NotesStorage.exportsDir());
		} catch (Exception ignored) {
		}
		Blaze3D.openPath(NotesStorage.exportsDir());
	}

	private Popup soundMenu() {
		Popup.Menu menu = new Popup.Menu();
		menu.item(ScribbleSettings.sounds ? "sound_on" : "sound_off", Component.translatable("scribble.settings.sounds"), null, true, ScribbleSettings.sounds, () -> {
			ScribbleSettings.sounds = !ScribbleSettings.sounds;
			ScribbleSettings.save();
		});
		menu.item("keyboard", Component.translatable("scribble.settings.typing_sounds"), null, ScribbleSettings.sounds, ScribbleSettings.typingSounds, () -> {
			ScribbleSettings.typingSounds = !ScribbleSettings.typingSounds;
			ScribbleSettings.save();
		});
		return menu;
	}

	private void export(NoteExporter.Format format) {
		this.save();
		try {
			Path file = NoteExporter.export(this.note, format);
			Notifications.success(format.icon, Component.translatable("scribble.export.done"), Component.literal(file.getFileName().toString()),
					Component.translatable("scribble.export.open_folder"), this::openExports);
		} catch (Exception e) {
			Scribble.LOGGER.error("Export failed", e);
			Notifications.warn(Component.translatable("scribble.export.failed"), Component.literal(String.valueOf(e.getMessage())));
		}
	}

	private Popup zoomMenu() {
		Popup.Menu menu = new Popup.Menu();
		menu.item(null, Component.translatable("scribble.zoom.fit"), null, true, false, () -> {
			this.setZoom(this.fitZoom(), this.viewX() + this.viewW() / 2.0, this.viewY());
			this.scrollX = 0;
			this.clampScroll();
		});
		menu.separator();
		for (float z : ZOOMS) {
			menu.item(null, Component.literal(Math.round(z * 100) + "%"), null, true, Math.abs(z - this.zoom) < 0.01F,
					() -> this.setZoom(z, this.viewX() + this.viewW() / 2.0, this.viewY() + this.viewH() / 2.0));
		}
		return menu;
	}

	private Popup styleMenu() {
		Popup.Menu menu = new Popup.Menu();
		ParaStyle cur = this.editor.currentStyle();
		String[][] items = {
				{"body", "Ctrl+Alt+0"}, {"title", "Ctrl+Alt+1"}, {"heading", "Ctrl+Alt+2"},
				{"bullet", "Ctrl+Shift+8"}, {"numbered", "Ctrl+Shift+7"}, {"checklist", "Ctrl+Shift+9"}, {"quote", null}
		};
		for (String[] it : items) {
			ParaStyle s = ParaStyle.byId(it[0]);
			menu.item(null, Component.translatable(s.translationKey()), it[1], true, cur == s, () -> {
				this.editor.setStyle(s);
				this.setTool(Tool.TEXT);
			});
		}
		menu.separator();
		menu.item(null, Component.translatable("scribble.format.clear"), null, true, false, this.editor::clearFormatting);
		return menu;
	}

	private Popup textContextMenu() {
		Popup.Menu menu = new Popup.Menu();
		boolean sel = this.editor.hasSelection();
		menu.item(null, Component.translatable("scribble.edit.cut"), "Ctrl+X", sel, false, () -> this.minecraft.keyboardHandler.setClipboard(this.editor.cut()));
		menu.item("copy", Component.translatable("scribble.edit.copy"), "Ctrl+C", sel, false, () -> this.minecraft.keyboardHandler.setClipboard(this.editor.copy()));
		menu.item(null, Component.translatable("scribble.edit.paste"), "Ctrl+V", true, false, () -> this.editor.paste(this.minecraft.keyboardHandler.getClipboard()));
		menu.item(null, Component.translatable("scribble.edit.select_all"), "Ctrl+A", true, false, this.editor::selectAll);
		menu.separator();
		menu.item("bold", Component.translatable("scribble.format.bold"), "Ctrl+B", true, false, () -> this.editor.toggle(TextFormat.Flag.BOLD));
		menu.item("italic", Component.translatable("scribble.format.italic"), "Ctrl+I", true, false, () -> this.editor.toggle(TextFormat.Flag.ITALIC));
		menu.item("underline", Component.translatable("scribble.format.underline"), "Ctrl+U", true, false, () -> this.editor.toggle(TextFormat.Flag.UNDERLINE));
		menu.item("strike", Component.translatable("scribble.format.strike"), null, true, false, () -> this.editor.toggle(TextFormat.Flag.STRIKE));
		menu.item(null, Component.translatable("scribble.format.clear"), null, true, false, this.editor::clearFormatting);
		return menu;
	}

	private void renameDialog() {
		this.openDialog(new Dialog.Input(Component.translatable("scribble.note.rename"), this.note.title, 64, title -> {
			this.note.title = title;
			this.markChanged();
		}));
	}

	private void addPage() {
		this.history.push(new TextSnap(), null);
		int pages = this.pageCount();
		this.note.minPages = pages + 1;
		this.invalidate();
		this.scrollToPage(pages);
		Ui.pageTurn();
		Notifications.success("page_add", Component.translatable(this.note.type.board ? "scribble.status.board_added" : "scribble.status.page_added"), null);
	}

	private void confirmRemovePage() {
		int page = this.currentPage();
		this.openDialog(new Dialog.Confirm(
				Component.translatable(this.note.type.board ? "scribble.pages.remove_board" : "scribble.pages.remove"),
				Component.translatable("scribble.pages.remove_confirm", page + 1),
				Component.translatable("scribble.pages.remove_button"),
				() -> this.removePage(page)));
	}

	private void removePage(int page) {
		TextLayout l = this.layout();
		boolean hasText = false;
		for (TextLayout.Line line : l.lines) {
			if (line.page() == page && (line.end() > line.start() || this.note.paragraphs.get(line.para()).style == ParaStyle.PAGE_BREAK)) {
				hasText = true;
				break;
			}
		}
		this.history.push(new FullSnap(), null);
		InkLayer layer = this.note.inkFor(page);
		ScribbleSounds.playVaried(ScribbleSounds.CRUMPLE, 1.0F, 0.6F);
		if (hasText) {
			if (layer != null) {
				layer.clear();
			}
			Notifications.info("info", Component.translatable("scribble.status.page_has_text"), null);
		} else {
			int pages = this.pageCount();
			Map<Integer, InkLayer> shifted = new HashMap<>();
			for (Map.Entry<Integer, InkLayer> e : this.note.ink.entrySet()) {
				if (e.getKey() < page) {
					shifted.put(e.getKey(), e.getValue());
				} else if (e.getKey() > page) {
					shifted.put(e.getKey() - 1, e.getValue());
				} else {
					e.getValue().release();
				}
			}
			for (int i = page; i < pages; i++) {
				this.note.removedInkPages.add(i);
			}
			this.note.ink.clear();
			for (Map.Entry<Integer, InkLayer> e : shifted.entrySet()) {
				e.getValue().unsaved = true;
				e.getValue().markAllDirty();
				this.note.ink.put(e.getKey(), e.getValue());
			}
			this.note.minPages = Math.max(1, Math.min(this.note.minPages, pages - 1));
			Notifications.info("trash", Component.translatable("scribble.status.page_removed"), null);
		}
		this.invalidate();
		if (this.notebook) {
			this.spread = Math.min(this.spread, this.maxSpread());
		}
	}

	private void confirmClearPage() {
		int page = this.currentPage();
		this.openDialog(new Dialog.Confirm(
				Component.translatable("scribble.panel.clear_page"),
				Component.translatable("scribble.pages.clear_confirm", page + 1),
				Component.translatable("scribble.panel.clear_page"),
				() -> {
					InkLayer layer = this.note.inkFor(page);
					if (layer != null) {
						this.history.push(new InkSnap(page), null);
						layer.clear();
						this.markChanged();
						ScribbleSounds.playVaried(this.note.type == NoteType.CHALKBOARD ? ScribbleSounds.ERASER_CHALK
								: this.note.type == NoteType.WHITEBOARD ? ScribbleSounds.ERASER_DRY : ScribbleSounds.ERASER_RUBBER, 0.9F, 0.8F);
					}
				}));
	}

	// ------------------------------------------------------------------ mouse

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x();
		double my = event.y();
		int button = event.button();

		if (this.dialog != null) {
			Hotspots.Hotspot h = this.hs.at(mx, my);
			if (h != null && h.onClick != null && button == InputConstants.MOUSE_BUTTON_LEFT) {
				h.onClick.run();
				return true;
			}
			this.dialog.mouseClicked(event, doubleClick);
			return true;
		}
		if (this.popup != null) {
			if (this.popup.contains(mx, my)) {
				Hotspots.Hotspot h = this.hs.at(mx, my);
				if (h != null && h.onClick != null && button == InputConstants.MOUSE_BUTTON_LEFT) {
					h.onClick.run();
				}
				return true;
			}
			this.popup = null;
			if (!this.inView(mx, my)) {
				return true;
			}
		}

		Hotspots.Hotspot h = this.hs.at(mx, my);
		if (h != null) {
			if (button == InputConstants.MOUSE_BUTTON_LEFT && h.onDrag != null) {
				this.activeDrag = h.onDrag;
				h.onDrag.drag(mx, my);
				return true;
			}
			if (button == InputConstants.MOUSE_BUTTON_LEFT && h.onClick != null) {
				h.onClick.run();
				return true;
			}
			if (button == InputConstants.MOUSE_BUTTON_RIGHT && h.onRightClick != null) {
				h.onRightClick.run();
				return true;
			}
			if (!this.inView(mx, my) || this.overChromePanel(mx, my)) {
				return true;
			}
		}

		if (!this.inView(mx, my)) {
			return super.mouseClicked(event, doubleClick);
		}

		if (button == InputConstants.MOUSE_BUTTON_MIDDLE || this.tool == Tool.PAN || (this.spaceDown && button == InputConstants.MOUSE_BUTTON_LEFT)) {
			this.panning = true;
			this.panMouseX = mx;
			this.panMouseY = my;
			ScribbleSounds.playVaried(ScribbleSounds.PAPER_PICKUP, 1.3F, 0.25F);
			return true;
		}
		if (this.flipping()) {
			return true;
		}

		int page = this.pageAt(mx, my);
		if (page < 0) {
			return true;
		}
		double px = this.toPageX(page, mx);
		double py = this.toPageY(page, my);

		if (this.tool == Tool.TEXT) {
			if (button == InputConstants.MOUSE_BUTTON_RIGHT) {
				this.openPopup(this.textContextMenu(), (int) mx, (int) my);
				return true;
			}
			if (button != InputConstants.MOUSE_BUTTON_LEFT) {
				return true;
			}
			if (this.tryToggleCheckbox(page, px, py)) {
				return true;
			}
			long now = Util.getMillis();
			if (now - this.lastClickTime < 350) {
				this.clickCount++;
			} else {
				this.clickCount = 1;
			}
			this.lastClickTime = now;
			TextLayout.Pos pos = this.layout().hit(this.note, this.metrics, page, px, py);
			if (this.clickCount == 2) {
				this.editor.selectWord(pos);
			} else if (this.clickCount >= 3) {
				this.editor.selectParagraph(pos.para());
			} else {
				this.editor.moveTo(pos, event.hasShiftDown());
				this.selecting = true;
			}
			this.editor.goalX = -1;
			this.history.breakCoalescing();
			return true;
		}

		float ix = (float) (px * InkLayer.SCALE);
		float iy = (float) (py * InkLayer.SCALE);
		switch (this.tool) {
			case PEN, HIGHLIGHTER, ERASER -> {
				boolean erase = button == InputConstants.MOUSE_BUTTON_RIGHT && this.tool == Tool.PEN;
				if (button != InputConstants.MOUSE_BUTTON_LEFT && !erase) {
					return true;
				}
				this.erasingWithRightButton = erase;
				InkLayer layer = this.note.inkForEditing(page);
				this.history.push(new InkSnap(page), null);
				InkPainter.beginStroke(layer);
				this.strokeSeed = ThreadLocalRandom.current().nextInt();
				InkPainter.Brush b = this.brush(this.tool, erase);
				if (event.hasShiftDown() && this.lastStrokePage == page) {
					InkPainter.line(layer, this.lastInkX, this.lastInkY, ix, iy, b, this.strokeSeed);
				} else {
					InkPainter.stamp(layer, ix, iy, b, this.strokeSeed);
				}
				this.drawing = true;
				this.drawPage = page;
				this.lastInkX = ix;
				this.lastInkY = iy;
				this.markChanged();
			}
			case SHAPES -> {
				if (button != InputConstants.MOUSE_BUTTON_LEFT) {
					return true;
				}
				InkLayer layer = this.note.inkForEditing(page);
				this.history.push(new InkSnap(page), null);
				this.shapeBase = layer.snapshot();
				this.shapeStartX = ix;
				this.shapeStartY = iy;
				this.strokeSeed = ThreadLocalRandom.current().nextInt();
				this.shaping = true;
				this.drawPage = page;
				this.drawShape(ix, iy, event.hasShiftDown());
			}
			case FILL -> {
				if (button != InputConstants.MOUSE_BUTTON_LEFT) {
					return true;
				}
				InkLayer layer = this.note.inkForEditing(page);
				InkSnap snap = new InkSnap(page);
				if (InkPainter.floodFill(layer, (int) ix, (int) iy, this.color(Tool.FILL))) {
					this.history.push(snap, null);
					this.markChanged();
					ScribbleSounds.playVaried(ScribbleSounds.BUCKET, 1.0F, 0.6F);
				}
			}
			case STAMP -> {
				if (button != InputConstants.MOUSE_BUTTON_LEFT) {
					return true;
				}
				InkLayer layer = this.note.inkForEditing(page);
				this.history.push(new InkSnap(page), null);
				InkPainter.sprite(layer, SpriteData.get(Sprites.stamp(this.stamp)), (int) ix, (int) iy, this.size(Tool.STAMP));
				this.markChanged();
				ScribbleSounds.playVaried(ScribbleSounds.STAMP, 1.0F, 0.7F);
			}
			case EYEDROPPER -> {
				InkLayer layer = this.note.inkFor(page);
				int picked = layer == null ? 0 : layer.get((int) ix, (int) iy);
				if ((picked >>> 24) != 0) {
					Tool target = this.previousTool.usesColor() && this.previousTool != Tool.TEXT ? this.previousTool : Tool.PEN;
					this.setColor(target, picked | 0xFF000000);
					ScribbleSounds.playVaried(ScribbleSounds.POP, 1.3F, 0.5F);
					Notifications.push("tool_eyedropper", Component.translatable("scribble.status.picked", String.format("#%06X", picked & 0xFFFFFF)),
							null, picked | 0xFF000000, null, null);
					this.setTool(target);
				} else {
					this.flash(Component.translatable("scribble.status.pick_nothing"));
				}
			}
			default -> {
			}
		}
		return true;
	}

	private boolean tryToggleCheckbox(int page, double px, double py) {
		TextLayout l = this.layout();
		int ts = this.note.type.textScale;
		for (int i = 0; i < l.lines.size(); i++) {
			TextLayout.Line line = l.lines.get(i);
			if (line.page() != page || l.firstLine[line.para()] != i) {
				continue;
			}
			Paragraph p = this.note.paragraphs.get(line.para());
			if (p.style != ParaStyle.CHECKLIST) {
				continue;
			}
			if (px >= line.x() - 12 * ts && px < line.x() - 1 && py >= line.slotTop() && py < line.bottom()) {
				this.editor.toggleChecked(line.para());
				ScribbleSounds.playVaried(ScribbleSounds.POP, p.checked ? 1.4F : 0.9F, 0.5F);
				return true;
			}
		}
		return false;
	}

	private void drawShape(float ix, float iy, boolean constrain) {
		InkLayer layer = this.note.inkForEditing(this.drawPage);
		if (this.shapeBase != null) {
			layer.restore(this.shapeBase);
		}
		InkPainter.beginStroke(layer);
		float x1 = ix;
		float y1 = iy;
		if (constrain) {
			float dx = ix - this.shapeStartX;
			float dy = iy - this.shapeStartY;
			if (this.shape == Tool.Shape.LINE) {
				double angle = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
				double len = Math.sqrt(dx * dx + dy * dy);
				x1 = this.shapeStartX + (float) (Math.cos(angle) * len);
				y1 = this.shapeStartY + (float) (Math.sin(angle) * len);
			} else {
				float s = Math.max(Math.abs(dx), Math.abs(dy));
				x1 = this.shapeStartX + Math.signum(dx) * s;
				y1 = this.shapeStartY + Math.signum(dy) * s;
			}
		}
		InkPainter.Brush b = this.brush(Tool.SHAPES, false);
		switch (this.shape) {
			case LINE -> InkPainter.line(layer, this.shapeStartX, this.shapeStartY, x1, y1, b, this.strokeSeed);
			case RECT -> InkPainter.rect(layer, this.shapeStartX, this.shapeStartY, x1, y1, b, this.shapeFilled, this.strokeSeed);
			case ELLIPSE -> InkPainter.ellipse(layer, this.shapeStartX, this.shapeStartY, x1, y1, b, this.shapeFilled, this.strokeSeed);
		}
		this.markChanged();
	}

	private void updateSelection(double mx, double my) {
		int page = this.pageAt(mx, my);
		if (page < 0) {
			return;
		}
		TextLayout.Pos pos = this.layout().hit(this.note, this.metrics, page, this.toPageX(page, mx), this.toPageY(page, my));
		this.editor.moveTo(pos, true);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		double mx = event.x();
		double my = event.y();
		if (this.activeDrag != null) {
			this.activeDrag.drag(mx, my);
			return true;
		}
		if (this.panning) {
			this.scrollX -= mx - this.panMouseX;
			this.scrollY -= my - this.panMouseY;
			this.panMouseX = mx;
			this.panMouseY = my;
			this.clampScroll();
			return true;
		}
		if (this.selecting) {
			this.updateSelection(mx, my);
			return true;
		}
		if (this.drawing) {
			InkLayer layer = this.note.inkForEditing(this.drawPage);
			float ix = (float) (this.toPageX(this.drawPage, mx) * InkLayer.SCALE);
			float iy = (float) (this.toPageY(this.drawPage, my) * InkLayer.SCALE);
			if (Float.isNaN(ix) || Float.isNaN(iy)) {
				return true;
			}
			InkPainter.line(layer, this.lastInkX, this.lastInkY, ix, iy, this.brush(this.tool, this.erasingWithRightButton), this.strokeSeed);
			this.lastInkX = ix;
			this.lastInkY = iy;
			this.markChanged();
			return true;
		}
		if (this.shaping) {
			float ix = (float) (this.toPageX(this.drawPage, mx) * InkLayer.SCALE);
			float iy = (float) (this.toPageY(this.drawPage, my) * InkLayer.SCALE);
			if (!Float.isNaN(ix) && !Float.isNaN(iy)) {
				this.drawShape(ix, iy, event.hasShiftDown());
			}
			return true;
		}
		return super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (this.activeDrag != null) {
			this.activeDrag.release();
			this.activeDrag = null;
		}
		if (this.drawing) {
			this.lastStrokePage = this.drawPage;
		}
		if (this.panning) {
			ScribbleSounds.playVaried(ScribbleSounds.PAPER_DROP, 1.4F, 0.2F);
		}
		this.selecting = false;
		this.drawing = false;
		this.erasingWithRightButton = false;
		this.shaping = false;
		this.shapeBase = null;
		this.panning = false;
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
		if (this.dialog != null || this.popup != null) {
			return true;
		}
		if (this.panelOpen && mx >= this.width - PANEL_W - 4 && my > this.viewY() && my < this.viewY() + this.viewH()) {
			this.panelScroll -= scrollY * 20;
			return true;
		}
		if (this.inView(mx, my)) {
			if (this.minecraft.hasControlDown()) {
				int idx = 0;
				for (int i = 0; i < ZOOMS.length; i++) {
					if (ZOOMS[i] <= this.zoom + 0.001F) {
						idx = i;
					}
				}
				int next = Mth.clamp(idx + (scrollY > 0 ? 1 : -1), 0, ZOOMS.length - 1);
				this.setZoom(ZOOMS[next], mx, my);
			} else if (this.notebook && this.maxScrollY() <= 0) {
				long now = Util.getMillis();
				if (now - this.lastWheelFlip > 280 && scrollY != 0) {
					this.lastWheelFlip = now;
					this.flipToSpread(this.spread + (scrollY < 0 ? 1 : -1));
				}
			} else if (this.minecraft.hasShiftDown()) {
				this.scrollX -= scrollY * 30;
			} else {
				this.scrollY -= scrollY * 30;
				this.scrollX -= scrollX * 30;
			}
			this.clampScroll();
			if (this.selecting) {
				this.updateSelection(mx, my);
			}
			return true;
		}
		return super.mouseScrolled(mx, my, scrollX, scrollY);
	}

	// ------------------------------------------------------------------ keyboard

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (this.dialog != null) {
			this.dialog.keyPressed(event);
			return true;
		}
		if (this.popup != null && event.isEscape()) {
			this.popup = null;
			return true;
		}
		int key = event.shortcutKey();
		boolean ctrl = event.hasControlDownWithQuirk();
		boolean shift = event.hasShiftDown();
		boolean alt = event.hasAltDown();

		if (event.input() == InputConstants.KEY_SPACE && this.tool != Tool.TEXT) {
			this.spaceDown = true;
			return true;
		}

		if (event.isEscape()) {
			if (this.tool == Tool.TEXT && this.editor.hasSelection()) {
				this.editor.moveTo(this.editor.cursor, false);
			} else {
				this.onClose();
			}
			return true;
		}

		if (this.notebook && alt && (key == K_LEFT || key == K_RIGHT)) {
			this.flipToSpread(this.spread + (key == K_RIGHT ? 1 : -1));
			return true;
		}

		if (ctrl) {
			switch (key) {
				case 'z' -> {
					if (shift) {
						this.redo();
					} else {
						this.undo();
					}
					return true;
				}
				case 'y' -> {
					this.redo();
					return true;
				}
				case 's' -> {
					this.save();
					Notifications.success("save", Component.translatable("scribble.status.saved_now"), null);
					return true;
				}
				case 'b' -> {
					this.editor.toggle(TextFormat.Flag.BOLD);
					return true;
				}
				case 'i' -> {
					this.editor.toggle(TextFormat.Flag.ITALIC);
					return true;
				}
				case 'u' -> {
					this.editor.toggle(TextFormat.Flag.UNDERLINE);
					return true;
				}
				case '=', '+' -> {
					this.zoomStep(1);
					return true;
				}
				case '-' -> {
					this.zoomStep(-1);
					return true;
				}
				case '0' -> {
					if (alt) {
						this.editor.setStyle(ParaStyle.BODY);
					} else {
						this.setZoom(this.fitZoom(), this.viewX() + this.viewW() / 2.0, this.viewY() + this.viewH() / 2.0);
					}
					return true;
				}
				case '1' -> {
					if (alt) {
						this.editor.setStyle(ParaStyle.TITLE);
						return true;
					}
				}
				case '2' -> {
					if (alt) {
						this.editor.setStyle(ParaStyle.HEADING);
						return true;
					}
				}
				case '7' -> {
					if (shift) {
						this.editor.setStyle(ParaStyle.NUMBERED);
						return true;
					}
				}
				case '8' -> {
					if (shift) {
						this.editor.setStyle(ParaStyle.BULLET);
						return true;
					}
				}
				case '9' -> {
					if (shift) {
						this.editor.setStyle(ParaStyle.CHECKLIST);
						return true;
					}
				}
				case K_ENTER, K_KP_ENTER -> {
					this.setTool(Tool.TEXT);
					this.editor.insertPageBreak();
					Ui.pageTurn();
					return true;
				}
				default -> {
				}
			}
		}
		if (alt && shift && key == '5') {
			this.editor.toggle(TextFormat.Flag.STRIKE);
			return true;
		}

		if (this.tool == Tool.TEXT) {
			if (this.textKey(event, key, ctrl, shift)) {
				return true;
			}
		} else if (!ctrl && !alt) {
			if (this.notebook && (key == K_LEFT || key == K_RIGHT)) {
				this.flipToSpread(this.spread + (key == K_RIGHT ? 1 : -1));
				return true;
			}
			for (Tool t : this.tools()) {
				if (t.hotkey == key) {
					this.setTool(t);
					Ui.pop();
					return true;
				}
			}
			if (key == 'l' || key == 'o') {
				this.setTool(Tool.SHAPES);
				this.shape = key == 'l' ? Tool.Shape.LINE : Tool.Shape.ELLIPSE;
				Ui.pop();
				return true;
			}
			if (key == '[' || key == ']') {
				Tool t = this.tool;
				if (t.usesSize()) {
					this.sizes.put(t, Mth.clamp(this.size(t) + (key == ']' ? 1 : -1), 1, this.maxSize(t)));
				}
				return true;
			}
			if (key >= '1' && key <= '9' && this.tool.usesColor()) {
				int[] pal = this.paletteFor(this.tool);
				int idx = key - '1';
				if (idx < pal.length) {
					this.setColor(this.tool, pal[idx]);
				}
				return true;
			}
		}
		return super.keyPressed(event);
	}

	private boolean textKey(KeyEvent event, int key, boolean ctrl, boolean shift) {
		TextLayout l = this.layout();
		switch (key) {
			case K_BACKSPACE -> {
				this.editor.backspace(ctrl);
				ScribbleSounds.typing();
			}
			case K_DELETE -> {
				this.editor.delete(ctrl);
				ScribbleSounds.typing();
			}
			case K_ENTER, K_KP_ENTER -> {
				this.editor.newline();
				if (ScribbleSettings.typingSounds) {
					ScribbleSounds.playVaried(ScribbleSounds.TYPE, 0.7F, 0.45F);
				}
			}
			case K_TAB -> this.editor.indent(shift ? -1 : 1);
			case K_LEFT -> {
				this.editor.left(shift, ctrl);
				this.editor.goalX = -1;
			}
			case K_RIGHT -> {
				this.editor.right(shift, ctrl);
				this.editor.goalX = -1;
			}
			case K_UP, K_DOWN, K_PAGEUP, K_PAGEDOWN -> {
				int li = l.lineIndexOf(this.editor.cursor);
				TextLayout.Line line = l.lines.get(li);
				if (this.editor.goalX < 0) {
					this.editor.goalX = l.caretX(this.note, this.metrics, line, this.editor.cursor.offset());
				}
				int step = switch (key) {
					case K_UP -> -1;
					case K_DOWN -> 1;
					case K_PAGEUP -> -this.note.type.slotsPerPage();
					default -> this.note.type.slotsPerPage();
				};
				int target = li + step;
				int goal = this.editor.goalX;
				if (target < 0) {
					this.editor.docStart(shift);
				} else if (target >= l.lines.size()) {
					this.editor.docEnd(shift);
				} else {
					TextLayout.Line tl = l.lines.get(target);
					this.editor.moveTo(new TextLayout.Pos(tl.para(), l.offsetAt(this.note, this.metrics, target, goal)), shift);
				}
				this.editor.goalX = goal;
			}
			case K_HOME -> {
				if (ctrl) {
					this.editor.docStart(shift);
				} else {
					TextLayout.Line line = l.lineOf(this.editor.cursor);
					this.editor.moveTo(new TextLayout.Pos(line.para(), line.start()), shift);
				}
				this.editor.goalX = -1;
			}
			case K_END -> {
				if (ctrl) {
					this.editor.docEnd(shift);
				} else {
					int li = l.lineIndexOf(this.editor.cursor);
					TextLayout.Line line = l.lines.get(li);
					int end = line.end();
					if (li != l.lastLine[line.para()] && end > line.start()) {
						end--;
					}
					this.editor.moveTo(new TextLayout.Pos(line.para(), end), shift);
				}
				this.editor.goalX = -1;
			}
			default -> {
				if (event.isSelectAll()) {
					this.editor.selectAll();
				} else if (event.isCopy()) {
					if (this.editor.hasSelection()) {
						this.minecraft.keyboardHandler.setClipboard(this.editor.copy());
						this.flash(Component.translatable("scribble.status.copied_selection"));
					}
				} else if (event.isCut()) {
					if (this.editor.hasSelection()) {
						this.minecraft.keyboardHandler.setClipboard(this.editor.cut());
					}
				} else if (event.isPaste()) {
					this.editor.paste(this.minecraft.keyboardHandler.getClipboard());
					ScribbleSounds.playVaried(ScribbleSounds.PAPER_DROP, 1.3F, 0.3F);
				} else {
					return false;
				}
			}
		}
		this.ensureCaretVisible();
		return true;
	}

	@Override
	public boolean keyReleased(KeyEvent event) {
		if (event.input() == InputConstants.KEY_SPACE) {
			this.spaceDown = false;
		}
		return super.keyReleased(event);
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		if (this.dialog != null) {
			return this.dialog.charTyped(event);
		}
		if (this.tool != Tool.TEXT || !event.isAllowedChatCharacter()) {
			return false;
		}
		this.editor.type(event.codepointAsString());
		ScribbleSounds.typing();
		return true;
	}

	// ------------------------------------------------------------------ file drop

	@Override
	public void onFilesDrop(List<Path> files) {
		for (Path file : files) {
			String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
			try {
				if (name.endsWith(".png")) {
					int page = this.currentPage();
					InkLayer layer = this.note.inkForEditing(page);
					this.history.push(new InkSnap(page), null);
					try (InputStream in = Files.newInputStream(file); NativeImage image = NativeImage.read(in)) {
						int[] px = image.getPixels();
						InkPainter.image(layer, px, image.getWidth(), image.getHeight());
					}
					this.markChanged();
					ScribbleSounds.playVaried(ScribbleSounds.PAPER_DROP, 1.0F, 0.6F);
					Notifications.success("file_png", Component.translatable("scribble.status.image_imported"), null);
				} else if (name.endsWith(".txt") || name.endsWith(".md")) {
					this.setTool(Tool.TEXT);
					this.editor.type(Files.readString(file, StandardCharsets.UTF_8));
					Notifications.success("file_txt", Component.translatable("scribble.import.done"), Component.literal(file.getFileName().toString()));
				}
			} catch (Exception e) {
				Scribble.LOGGER.error("Could not import {}", file, e);
				Notifications.warn(Component.translatable("scribble.import.failed"), Component.literal(file.getFileName().toString()));
			}
		}
	}
}
