package com.vess7y.scribble.client.ui;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.util.Util;

/**
 * Tiny procedural animation helpers: frame delta time and keyed damped springs, so any UI element can wobble,
 * bounce or glide without keeping its own state.
 */
public final class Anim {
	private static final Map<Object, float[]> SPRINGS = new HashMap<>();
	private static long lastFrame = Util.getMillis();
	private static float dt = 1 / 60.0F;
	private static long frame;

	private Anim() {
	}

	/** Call once at the start of each rendered frame. */
	public static void beginFrame() {
		long now = Util.getMillis();
		dt = Math.min(0.05F, Math.max(0.001F, (now - lastFrame) / 1000.0F));
		lastFrame = now;
		frame++;
		if (frame % 600 == 0 && SPRINGS.size() > 4000) {
			SPRINGS.clear();
		}
	}

	public static float dt() {
		return dt;
	}

	public static float time() {
		return (Util.getMillis() % 1_000_000L) / 1000.0F;
	}

	/**
	 * Advances the spring with the given key toward {@code target} and returns its value.
	 *
	 * @param stiffness how strongly it pulls (higher = snappier)
	 * @param damping   0..1-ish; lower values overshoot and wobble more
	 */
	public static float spring(Object key, float target, float stiffness, float damping) {
		float[] s = SPRINGS.computeIfAbsent(key, k -> new float[]{target, 0});
		int steps = 4;
		float h = dt / steps;
		for (int i = 0; i < steps; i++) {
			float force = (target - s[0]) * stiffness - s[1] * damping * 2 * (float) Math.sqrt(stiffness);
			s[1] += force * h;
			s[0] += s[1] * h;
		}
		return s[0];
	}

	/** A bouncy default spring, nice for hover pops. */
	public static float bouncy(Object key, float target) {
		return spring(key, target, 260, 0.45F);
	}

	/** A smooth, non-overshooting spring. */
	public static float smooth(Object key, float target) {
		return spring(key, target, 140, 1.0F);
	}

	/** Gives the spring a velocity kick (e.g. a click squash). */
	public static void kick(Object key, float velocity) {
		float[] s = SPRINGS.get(key);
		if (s != null) {
			s[1] += velocity;
		}
	}

	public static void set(Object key, float value) {
		SPRINGS.put(key, new float[]{value, 0});
	}

	public static float easeOutBack(float t) {
		float c1 = 1.70158F;
		float c3 = c1 + 1;
		return 1 + c3 * (float) Math.pow(t - 1, 3) + c1 * (float) Math.pow(t - 1, 2);
	}

	public static float easeInOutCubic(float t) {
		return t < 0.5F ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
	}

	public static float clamp01(float t) {
		return Math.max(0, Math.min(1, t));
	}
}
