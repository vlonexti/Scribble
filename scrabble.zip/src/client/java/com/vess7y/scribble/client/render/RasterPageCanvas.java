package com.vess7y.scribble.client.render;

import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.text.TextMetrics;
import java.util.List;
import net.minecraft.resources.Identifier;

/**
 * Software rasterizer for pages, used for PNG and PDF export. Every page unit becomes {@code scale}×{@code scale}
 * pixels, so the result keeps the crisp pixel look of the game.
 */
public final class RasterPageCanvas implements PageCanvas {
	public final int width;
	public final int height;
	public final int scale;
	private final int[] pixels;
	private final int originX;
	private final int originY;
	private final TextMetrics metrics;
	private final BitmapFont font;

	public RasterPageCanvas(NoteType type, int scale, TextMetrics metrics, int background) {
		this.scale = scale;
		this.width = type.outerWidth() * scale;
		this.height = type.outerHeight() * scale;
		this.pixels = new int[this.width * this.height];
		java.util.Arrays.fill(this.pixels, background);
		this.originX = type.outerLeft * scale;
		this.originY = type.outerTop * scale;
		this.metrics = metrics;
		this.font = BitmapFont.get(net.minecraft.resources.Identifier.withDefaultNamespace("default"));
	}

	public int[] pixels() {
		return this.pixels;
	}

	public NativeImage toImage() {
		NativeImage image = new NativeImage(this.width, this.height, false);
		for (int y = 0; y < this.height; y++) {
			for (int x = 0; x < this.width; x++) {
				image.setPixel(x, y, this.pixels[y * this.width + x]);
			}
		}
		return image;
	}

	private void blend(int x, int y, int argb) {
		if (x < 0 || y < 0 || x >= this.width || y >= this.height) {
			return;
		}
		int sa = argb >>> 24;
		if (sa == 0) {
			return;
		}
		int i = y * this.width + x;
		if (sa == 255) {
			this.pixels[i] = argb;
			return;
		}
		int dst = this.pixels[i];
		int da = dst >>> 24;
		float a = sa / 255.0F;
		float b = da / 255.0F * (1 - a);
		float oa = a + b;
		if (oa <= 0) {
			return;
		}
		int r = (int) ((((argb >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * b) / oa);
		int g = (int) ((((argb >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * b) / oa);
		int bl = (int) (((argb & 0xFF) * a + (dst & 0xFF) * b) / oa);
		this.pixels[i] = ((int) (oa * 255 + 0.5F) << 24) | (r << 16) | (g << 8) | bl;
	}

	private void fillPx(int x0, int y0, int x1, int y1, int argb) {
		x0 = Math.max(0, x0);
		y0 = Math.max(0, y0);
		x1 = Math.min(this.width, x1);
		y1 = Math.min(this.height, y1);
		for (int y = y0; y < y1; y++) {
			for (int x = x0; x < x1; x++) {
				this.blend(x, y, argb);
			}
		}
	}

	@Override
	public void fill(int x0, int y0, int x1, int y1, int argb) {
		this.fillPx(this.originX + x0 * this.scale, this.originY + y0 * this.scale,
				this.originX + x1 * this.scale, this.originY + y1 * this.scale, argb);
	}

	@Override
	public void sprite(Identifier sprite, int x, int y, int width, int height) {
		SpriteData data = SpriteData.get(sprite);
		int px0 = this.originX + x * this.scale;
		int py0 = this.originY + y * this.scale;
		int pw = width * this.scale;
		int ph = height * this.scale;
		for (int ty = 0; ty < ph; ty++) {
			int v = this.sample(data, ty, ph, height, data.height());
			for (int tx = 0; tx < pw; tx++) {
				int u = this.sample(data, tx, pw, width, data.width());
				this.blend(px0 + tx, py0 + ty, data.get(u, v));
			}
		}
	}

	/** Maps a target pixel to a source texel along one axis. */
	private int sample(SpriteData data, int t, int targetPx, int targetUnits, int srcSize) {
		return switch (data.mode()) {
			case STRETCH -> Math.min(srcSize - 1, t * srcSize / Math.max(1, targetPx));
			case TILE -> (t / this.scale) % srcSize;
			case NINE_SLICE -> {
				int b = data.border();
				int unit = t / this.scale;
				if (unit < b) {
					yield unit;
				} else if (unit >= targetUnits - b) {
					yield srcSize - (targetUnits - unit);
				}
				int inner = Math.max(1, srcSize - 2 * b);
				yield b + Math.floorMod(unit - b, inner);
			}
		};
	}

	@Override
	public void text(List<Run> runs, int x, int y, int scale) {
		float unit = scale * this.scale;
		float penX = this.originX + x * this.scale;
		float top = this.originY + y * this.scale;
		for (Run run : runs) {
			for (int i = 0; i < run.text().length(); i++) {
				char c = run.text().charAt(i);
				int advance = this.metrics.charWidth(c, run.bold());
				BitmapFont.Glyph glyph = c == ' ' ? null : this.font.glyph(c);
				if (glyph != null) {
					this.glyph(glyph, penX, top, unit, run.italic(), run.color());
					if (run.bold()) {
						this.glyph(glyph, penX + unit, top, unit, run.italic(), run.color());
					}
				}
				if (run.underline()) {
					this.fillPx(Math.round(penX - unit), Math.round(top + 8 * unit), Math.round(penX + advance * unit), Math.round(top + 9 * unit), run.color());
				}
				if (run.strike()) {
					this.fillPx(Math.round(penX - unit), Math.round(top + 3.5F * unit), Math.round(penX + advance * unit), Math.round(top + 4.5F * unit), run.color());
				}
				penX += advance * unit;
			}
		}
	}

	private void glyph(BitmapFont.Glyph g, float x, float y, float unit, boolean italic, int color) {
		float texel = g.pixelScale() * unit;
		for (int gy = 0; gy < g.height(); gy++) {
			float fy = g.top() + gy * g.pixelScale();
			float shear = italic ? (1.0F - 0.25F * (fy + g.pixelScale() / 2)) * unit : 0;
			int y0 = Math.round(y + fy * unit);
			int y1 = Math.round(y + fy * unit + texel);
			for (int gx = 0; gx < g.width(); gx++) {
				if (g.mask()[gy * g.width() + gx]) {
					int x0 = Math.round(x + gx * texel + shear);
					this.fillPx(x0, y0, x0 + Math.max(1, Math.round(texel)), y1, color);
				}
			}
		}
	}

	@Override
	public void ink(InkLayer layer, int x, int y, int width, int height) {
		int px0 = this.originX + x * this.scale;
		int py0 = this.originY + y * this.scale;
		int pw = width * this.scale;
		int ph = height * this.scale;
		for (int ty = 0; ty < ph; ty++) {
			int sy = ty * layer.height / ph;
			for (int tx = 0; tx < pw; tx++) {
				int p = layer.pixels[sy * layer.width + tx * layer.width / pw];
				if ((p >>> 24) != 0) {
					this.blend(px0 + tx, py0 + ty, p);
				}
			}
		}
	}
}
