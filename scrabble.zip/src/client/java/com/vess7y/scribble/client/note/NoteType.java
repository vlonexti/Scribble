package com.vess7y.scribble.client.note;

/**
 * The different kinds of notes. Each defines its page geometry, how text sits on the page,
 * and which pens / erasers / colors fit it.
 */
public enum NoteType {
	// paper types are US Letter (8.5 x 11 in) at 30 page units per inch; ruled lines are 11 units (~0.37 in) apart
	LINED("lined", new Spec().page(255, 330).margins(40, 19, 14, 8).lineHeight(11).notebook()
			.pen(PenKind.PEN).eraser(EraserKind.PENCIL).paper(PaperColor.WHITE).palette(Palettes.PAPER)),
	BLANK("blank", new Spec().page(255, 330).margins(30, 30, 30, 30).lineHeight(11)
			.pen(PenKind.PEN).eraser(EraserKind.PENCIL).paper(PaperColor.WHITE).palette(Palettes.PAPER)),
	GRID("grid", new Spec().page(255, 330).margins(33, 22, 22, 22).lineHeight(11)
			.pen(PenKind.PEN).eraser(EraserKind.PENCIL).paper(PaperColor.WHITE).palette(Palettes.PAPER)),
	DOTTED("dotted", new Spec().page(255, 330).margins(22, 22, 22, 22).lineHeight(11)
			.pen(PenKind.PEN).eraser(EraserKind.PENCIL).paper(PaperColor.CREAM).palette(Palettes.PAPER)),
	STICKY("sticky", new Spec().page(180, 180).margins(14, 22, 14, 10).lineHeight(11).outer(0, 5, 0, 0)
			.pen(PenKind.PEN).eraser(EraserKind.PENCIL).paper(PaperColor.YELLOW).palette(Palettes.PAPER)),
	PARCHMENT("parchment", new Spec().page(255, 330).margins(30, 30, 30, 30).lineHeight(11).noPaperColors()
			.pen(PenKind.QUILL).eraser(EraserKind.PENCIL).ink(0xFF2A1E14, 0xFF8E1E1E).palette(Palettes.QUILL)),
	WHITEBOARD("whiteboard", new Spec().page(400, 300).textScale(2).lineHeight(24).margins(16, 14, 16, 12).outer(6, 6, 6, 14).board()
			.pen(PenKind.MARKER).eraser(EraserKind.DRY_ERASE).ink(0xFF22252A, 0xFF2457C5).palette(Palettes.MARKER)),
	CHALKBOARD("chalkboard", new Spec().page(400, 260).textScale(2).lineHeight(24).margins(16, 14, 16, 12).outer(6, 6, 6, 14).board()
			.pen(PenKind.CHALK).eraser(EraserKind.CHALK).ink(0xFFF4F4F0, 0xFFFFE680).palette(Palettes.CHALK)),
	BLUEPRINT("blueprint", new Spec().page(420, 280).lineHeight(12).margins(18, 18, 18, 42).board()
			.pen(PenKind.WHITE_PENCIL).eraser(EraserKind.PENCIL).ink(0xFFEAF4FF, 0xFFFFE680).palette(Palettes.BLUEPRINT));

	/** Notebook cover colors (leather / cardboard tones). */
	public static final int[] COVERS = {
			0xFFD9653B, 0xFFC23B3B, 0xFF3B6FC2, 0xFF3B8F5A, 0xFF7A4BB0, 0xFFE0A030,
			0xFF2E2E36, 0xFF8A5A34, 0xFFE07AA0, 0xFF3BA8A8, 0xFFB8B0A0, 0xFF5A6E3A
	};

	public final String id;
	public final int pageWidth;
	public final int pageHeight;
	public final int textScale;
	private final int lineHeight;
	/** Shown as a spiral notebook you flip through, instead of a scrolling document. */
	public final boolean notebook;
	public final int marginLeft;
	public final int marginTop;
	public final int marginRight;
	public final int marginBottom;
	public final int outerLeft;
	public final int outerTop;
	public final int outerRight;
	public final int outerBottom;
	public final boolean board;
	public final boolean paperColors;
	public final PaperColor defaultPaper;
	public final PenKind pen;
	public final EraserKind eraser;
	public final int[] palette;
	private final int ink;
	private final int accent;

	NoteType(String id, Spec s) {
		this.id = id;
		this.pageWidth = s.w;
		this.pageHeight = s.h;
		this.textScale = s.textScale;
		this.lineHeight = s.lineHeight;
		this.notebook = s.notebook;
		this.marginLeft = s.ml;
		this.marginTop = s.mt;
		this.marginRight = s.mr;
		this.marginBottom = s.mb;
		this.outerLeft = s.ol;
		this.outerTop = s.ot;
		this.outerRight = s.or;
		this.outerBottom = s.ob;
		this.board = s.board;
		this.paperColors = s.paperColors;
		this.defaultPaper = s.paper;
		this.pen = s.pen;
		this.eraser = s.eraser;
		this.palette = s.palette;
		this.ink = s.ink;
		this.accent = s.accent;
	}

	public int lineHeight() {
		return this.lineHeight;
	}

	public int contentWidth() {
		return this.pageWidth - this.marginLeft - this.marginRight;
	}

	public int slotsPerPage() {
		return Math.max(1, (this.pageHeight - this.marginTop - this.marginBottom) / this.lineHeight());
	}

	public int outerWidth() {
		return this.outerLeft + this.pageWidth + this.outerRight;
	}

	public int outerHeight() {
		return this.outerTop + this.pageHeight + this.outerBottom;
	}

	/** Default text color for this note type on the given paper. */
	public int defaultInk(PaperColor paper) {
		if (this.paperColors) {
			return paper.isDark() ? 0xFFF0F0F2 : 0xFF1E1E24;
		}
		return this.ink;
	}

	/** Color used for headings. */
	public int accent(PaperColor paper) {
		if (this.paperColors) {
			return paper.isDark() ? 0xFF9FC8FF : 0xFF2A4FB8;
		}
		return this.accent;
	}

	public boolean isDarkSurface(PaperColor paper) {
		return this == CHALKBOARD || this == BLUEPRINT || (this.paperColors && paper.isDark());
	}

	public String translationKey() {
		return "scribble.type." + this.id;
	}

	public String iconName() {
		return "type_" + this.id;
	}

	public static NoteType byId(String id) {
		for (NoteType t : values()) {
			if (t.id.equals(id)) {
				return t;
			}
		}
		return LINED;
	}

	public enum PenKind {
		PEN("pen", "tool_pen"),
		QUILL("quill", "tool_quill"),
		MARKER("marker", "tool_marker"),
		CHALK("chalk", "tool_chalk"),
		WHITE_PENCIL("white_pencil", "tool_pencil");

		public final String id;
		public final String icon;

		PenKind(String id, String icon) {
			this.id = id;
			this.icon = icon;
		}

		public String translationKey() {
			return "scribble.pen." + this.id;
		}
	}

	public enum EraserKind {
		PENCIL("pencil", "eraser_pencil"),
		DRY_ERASE("dry_erase", "eraser_dry"),
		CHALK("chalk", "eraser_chalk");

		public final String id;
		public final String icon;

		EraserKind(String id, String icon) {
			this.id = id;
			this.icon = icon;
		}

		public String translationKey() {
			return "scribble.eraser." + this.id;
		}
	}

	public static final class Palettes {
		public static final int[] PAPER = {
				0xFF1E1E24, 0xFF2A4FB8, 0xFFC8302C, 0xFF2E8B3E, 0xFF6A3AB0, 0xFFE07A1E,
				0xFF6B4423, 0xFF7A7A80, 0xFFE05A9A, 0xFF1E8C8C, 0xFFC9A227, 0xFFFFFFFF
		};
		public static final int[] QUILL = {
				0xFF2A1E14, 0xFF6B4423, 0xFF8E1E1E, 0xFF1E3A8E, 0xFF2E5A2E, 0xFFB8860B,
				0xFF5A2E7A, 0xFF4A4A4A
		};
		public static final int[] MARKER = {
				0xFF22252A, 0xFF2457C5, 0xFFD3302F, 0xFF2E9A45, 0xFFE8761E, 0xFF7442B8,
				0xFF7A4A24, 0xFF1E9A9A
		};
		public static final int[] CHALK = {
				0xFFF4F4F0, 0xFFFFE680, 0xFFFF9AB8, 0xFF8FD0FF, 0xFFA8E890, 0xFFFFB870,
				0xFFCDB4FF, 0xFFFF7A7A
		};
		public static final int[] BLUEPRINT = {
				0xFFEAF4FF, 0xFF9FD0FF, 0xFFFFE680, 0xFFFF8A8A, 0xFF8AF0D8, 0xFFFFFFFF
		};
		/** The 16 Minecraft dye colors, offered as an extended palette everywhere. */
		public static final int[] DYES = {
				0xFFF9FFFE, 0xFF9D9D97, 0xFF474F52, 0xFF1D1D21, 0xFF835432, 0xFFB02E26,
				0xFFF9801D, 0xFFFED83D, 0xFF80C71F, 0xFF5E7C16, 0xFF169C9C, 0xFF3AB3DA,
				0xFF3C44AA, 0xFF8932B8, 0xFFC74EBD, 0xFFF38BAA
		};
	}

	private static final class Spec {
		int w = 240, h = 320, textScale = 1, lineHeight = 12;
		boolean notebook;
		int ml, mt, mr, mb;
		int ol, ot, or, ob;
		boolean board;
		boolean paperColors = true;
		PaperColor paper = PaperColor.WHITE;
		PenKind pen = PenKind.PEN;
		EraserKind eraser = EraserKind.PENCIL;
		int[] palette = Palettes.PAPER;
		int ink = 0xFF1E1E24;
		int accent = 0xFF2A4FB8;

		Spec page(int w, int h) {
			this.w = w;
			this.h = h;
			return this;
		}

		Spec lineHeight(int lh) {
			this.lineHeight = lh;
			return this;
		}

		Spec notebook() {
			this.notebook = true;
			return this;
		}

		Spec textScale(int s) {
			this.textScale = s;
			return this;
		}

		Spec margins(int l, int t, int r, int b) {
			this.ml = l;
			this.mt = t;
			this.mr = r;
			this.mb = b;
			return this;
		}

		Spec outer(int l, int t, int r, int b) {
			this.ol = l;
			this.ot = t;
			this.or = r;
			this.ob = b;
			return this;
		}

		Spec board() {
			this.board = true;
			this.paperColors = false;
			return this;
		}

		Spec noPaperColors() {
			this.paperColors = false;
			return this;
		}

		Spec paper(PaperColor p) {
			this.paper = p;
			return this;
		}

		Spec pen(PenKind p) {
			this.pen = p;
			return this;
		}

		Spec eraser(EraserKind e) {
			this.eraser = e;
			return this;
		}

		Spec palette(int[] p) {
			this.palette = p;
			return this;
		}

		Spec ink(int ink, int accent) {
			this.ink = ink;
			this.accent = accent;
			return this;
		}
	}
}
