package com.vess7y.scribble.client.render;

import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.text.TextLayout;
import com.vess7y.scribble.client.text.TextMetrics;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.jspecify.annotations.Nullable;

/**
 * Draws pages into the GUI at a given position and zoom.
 */
public final class PageRenderer {
	private PageRenderer() {
	}

	/**
	 * @param x    screen x of the page's top-left corner (the page itself, not its outer decorations)
	 * @param zoom screen pixels per page unit
	 */
	public static void draw(GuiGraphicsExtractor g, Note note, TextLayout layout, TextMetrics m, int page, int pageCount,
							@Nullable InkLayer ink, float x, float y, float zoom, boolean detailed, boolean editor) {
		g.pose().pushMatrix();
		g.pose().translate(x, y);
		g.pose().scale(zoom, zoom);
		PageComposer.draw(new GuiPageCanvas(g, detailed), note, layout, m, page, pageCount, ink, editor);
		g.pose().popMatrix();
	}

	/** Draws a soft drop shadow under a page's outer bounds. */
	public static void shadow(GuiGraphicsExtractor g, NoteType t, float x, float y, float zoom) {
		int x0 = Math.round(x - t.outerLeft * zoom);
		int y0 = Math.round(y - t.outerTop * zoom);
		int x1 = Math.round(x + (t.pageWidth + t.outerRight) * zoom);
		int y1 = Math.round(y + (t.pageHeight + t.outerBottom) * zoom);
		g.fill(x0 + 2, y0 + 3, x1 + 3, y1 + 4, 0x40000000);
		g.fill(x0 + 1, y0 + 2, x1 + 2, y1 + 2, 0x50000000);
	}

	/** Draws a page scaled to fit inside the box, centered. Returns the zoom used. */
	public static float thumbnail(GuiGraphicsExtractor g, Note note, TextLayout layout, TextMetrics m, int page, int pageCount,
								  @Nullable InkLayer ink, int bx, int by, int bw, int bh) {
		NoteType t = note.type;
		float zoom = Math.min((float) bw / t.outerWidth(), (float) bh / t.outerHeight());
		float x = bx + (bw - t.outerWidth() * zoom) / 2 + t.outerLeft * zoom;
		float y = by + (bh - t.outerHeight() * zoom) / 2 + t.outerTop * zoom;
		draw(g, note, layout, m, page, pageCount, ink, x, y, zoom, zoom >= 0.75F, false);
		return zoom;
	}
}
