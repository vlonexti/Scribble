package com.vess7y.scribble.client.text;

import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Flows a note's paragraphs onto its pages. Each page has a fixed number of line "slots" (the ruled lines
 * on lined paper); lines of text are word wrapped into those slots and spill over onto new pages.
 */
public final class TextLayout {
	public final List<Line> lines = new ArrayList<>();
	public final int[] firstLine;
	public final int[] lastLine;
	/** List numbers for numbered paragraphs (0 for others). */
	public final int[] numbers;
	public final int textPages;
	private final NoteType type;

	private TextLayout(NoteType type, int paragraphs, int textPages) {
		this.type = type;
		this.firstLine = new int[paragraphs];
		this.lastLine = new int[paragraphs];
		this.numbers = new int[paragraphs];
		this.textPages = textPages;
	}

	/**
	 * @param x      left edge of the text in page units (after indent and alignment)
	 * @param y      top of the glyphs in page units
	 * @param scale  page units per font pixel
	 * @param width  width of the visible text in page units
	 */
	public record Line(int para, int start, int end, int page, int x, int y, int scale, int slotTop, int slotHeight, int width) {
		public int bottom() {
			return this.slotTop + this.slotHeight;
		}
	}

	public record Pos(int para, int offset) implements Comparable<Pos> {
		@Override
		public int compareTo(Pos o) {
			return this.para != o.para ? Integer.compare(this.para, o.para) : Integer.compare(this.offset, o.offset);
		}
	}

	public static TextLayout build(Note note, TextMetrics m) {
		NoteType t = note.type;
		int ts = t.textScale;
		int lh = t.lineHeight();
		int spp = t.slotsPerPage();
		List<Paragraph> paras = note.paragraphs;

		List<Line> lines = new ArrayList<>();
		int[] first = new int[paras.size()];
		int[] last = new int[paras.size()];
		int[] numbers = new int[paras.size()];
		int[] counters = new int[16];
		int slot = 0;

		for (int i = 0; i < paras.size(); i++) {
			Paragraph p = paras.get(i);
			int level = Math.min(15, p.indent);
			if (p.style == ParaStyle.NUMBERED) {
				counters[level]++;
				Arrays.fill(counters, level + 1, counters.length, 0);
				numbers[i] = counters[level];
			} else if (!p.style.isList() || p.indent == 0) {
				Arrays.fill(counters, 0);
			} else {
				Arrays.fill(counters, level, counters.length, 0);
			}

			first[i] = lines.size();
			if (p.style == ParaStyle.PAGE_BREAK) {
				int page = slot / spp;
				int s = slot % spp;
				int top = t.marginTop + s * lh;
				lines.add(new Line(i, 0, 0, page, t.marginLeft, top + lh - 9 * ts, ts, top, lh, 0));
				last[i] = lines.size() - 1;
				slot = (page + 1) * spp;
				continue;
			}

			int scale = ts * p.style.scale;
			int slots = p.style.scale;
			int indentPx = (p.indent * 12 + p.style.gutter) * ts;
			int avail = Math.max(16, t.contentWidth() - indentPx);
			int availFont = Math.max(8, avail / scale);

			for (int[] seg : wrap(p, m, availFont)) {
				if (slot % spp + slots > spp) {
					slot = (slot / spp + 1) * spp;
				}
				int page = slot / spp;
				int s = slot % spp;
				int slotTop = t.marginTop + s * lh;
				int slotHeight = slots * lh;
				int visibleEnd = seg[1];
				while (visibleEnd > seg[0] && p.charAt(visibleEnd - 1) == ' ') {
					visibleEnd--;
				}
				int widthPx = m.width(p, seg[0], visibleEnd) * scale;
				int x0 = t.marginLeft + indentPx;
				int x = switch (p.align) {
					case LEFT -> x0;
					case CENTER -> x0 + (avail - widthPx) / 2;
					case RIGHT -> x0 + avail - widthPx;
				};
				int y = slotTop + slotHeight - 9 * scale;
				lines.add(new Line(i, seg[0], seg[1], page, x, y, scale, slotTop, slotHeight, widthPx));
				slot += slots;
			}
			last[i] = lines.size() - 1;
		}

		int textPages = slot == 0 ? 1 : (slot - 1) / spp + 1;
		TextLayout layout = new TextLayout(t, paras.size(), textPages);
		layout.lines.addAll(lines);
		System.arraycopy(first, 0, layout.firstLine, 0, first.length);
		System.arraycopy(last, 0, layout.lastLine, 0, last.length);
		System.arraycopy(numbers, 0, layout.numbers, 0, numbers.length);
		return layout;
	}

	/** Greedy word wrap. Returns [start, end) pairs; trailing spaces stay on the line they follow. */
	private static List<int[]> wrap(Paragraph p, TextMetrics m, int maxWidth) {
		List<int[]> out = new ArrayList<>();
		int len = p.length();
		if (len == 0) {
			out.add(new int[]{0, 0});
			return out;
		}
		int start = 0;
		while (start < len) {
			int w = 0;
			int i = start;
			int lastBreak = -1;
			while (i < len) {
				char c = p.charAt(i);
				int cw = m.charWidth(c, p.formatAt(i).bold());
				if (w + cw > maxWidth && i > start && c != ' ') {
					break;
				}
				w += cw;
				if (c == ' ') {
					lastBreak = i + 1;
				}
				i++;
			}
			int end;
			if (i >= len) {
				end = len;
			} else if (lastBreak > start) {
				end = lastBreak;
			} else {
				end = i;
			}
			out.add(new int[]{start, end});
			start = end;
		}
		return out;
	}

	// ------------------------------------------------------------------ queries

	public int pageCount(Note note) {
		return Math.max(Math.max(this.textPages, note.minPages), note.highestInkPage() + 1);
	}

	public int lineIndexOf(Pos pos) {
		int para = Math.max(0, Math.min(pos.para(), this.firstLine.length - 1));
		int best = this.firstLine[para];
		for (int i = this.firstLine[para]; i <= this.lastLine[para]; i++) {
			if (this.lines.get(i).start() <= pos.offset()) {
				best = i;
			}
		}
		return best;
	}

	public Line lineOf(Pos pos) {
		return this.lines.get(this.lineIndexOf(pos));
	}

	/** X position (page units) of a caret at {@code offset} within {@code line}. */
	public int caretX(Note note, TextMetrics m, Line line, int offset) {
		Paragraph p = note.paragraphs.get(line.para());
		int clamped = Math.max(line.start(), Math.min(offset, line.end()));
		return line.x() + m.width(p, line.start(), clamped) * line.scale();
	}

	/** Character offset in {@code line} closest to page-unit x. */
	public int offsetAt(Note note, TextMetrics m, int lineIndex, double px) {
		Line line = this.lines.get(lineIndex);
		Paragraph p = note.paragraphs.get(line.para());
		boolean lastOfPara = lineIndex == this.lastLine[line.para()];
		int end = line.end();
		if (!lastOfPara && end > line.start()) {
			end--;
		}
		double cx = line.x();
		for (int i = line.start(); i < end; i++) {
			int cw = m.charWidth(p.charAt(i), p.formatAt(i).bold()) * line.scale();
			if (px < cx + cw / 2.0) {
				return i;
			}
			cx += cw;
		}
		return end;
	}

	/** Maps a point on a page to the nearest caret position. */
	public Pos hit(Note note, TextMetrics m, int page, double px, double py) {
		int firstOnPage = -1;
		int lastOnPage = -1;
		for (int i = 0; i < this.lines.size(); i++) {
			if (this.lines.get(i).page() == page) {
				if (firstOnPage < 0) {
					firstOnPage = i;
				}
				lastOnPage = i;
			}
		}
		if (firstOnPage < 0) {
			// empty page: snap to the closest text before or after it
			for (int i = 0; i < this.lines.size(); i++) {
				if (this.lines.get(i).page() > page) {
					Line l = this.lines.get(i);
					return new Pos(l.para(), l.start());
				}
			}
			int lastPara = note.paragraphs.size() - 1;
			return new Pos(lastPara, note.paragraphs.get(lastPara).length());
		}
		int target = lastOnPage;
		for (int i = firstOnPage; i <= lastOnPage; i++) {
			if (py < this.lines.get(i).bottom()) {
				target = i;
				break;
			}
		}
		Line line = this.lines.get(target);
		return new Pos(line.para(), this.offsetAt(note, m, target, px));
	}

	public NoteType type() {
		return this.type;
	}
}
