package com.vess7y.scribble.client.render;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.Scribble;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jspecify.annotations.Nullable;

/**
 * A tiny software reader for Minecraft's bitmap fonts, so exported images use the exact in-game glyphs.
 * Only "bitmap" and "reference" providers are understood, which covers the default font.
 */
public final class BitmapFont {
	private static final Map<Identifier, BitmapFont> CACHE = new HashMap<>();
	private static final Identifier DEFAULT = Identifier.withDefaultNamespace("default");

	private final Int2ObjectOpenHashMap<Glyph> glyphs = new Int2ObjectOpenHashMap<>();

	/**
	 * @param pixelScale font pixels per glyph texel
	 * @param top        offset of the glyph's first row from the text's y, in font pixels
	 */
	public record Glyph(boolean[] mask, int width, int height, float pixelScale, float top) {
	}

	public static synchronized BitmapFont get(Identifier fontId) {
		return CACHE.computeIfAbsent(fontId, id -> {
			BitmapFont font = new BitmapFont();
			font.load(Minecraft.getInstance().getResourceManager(), id, 0);
			return font;
		});
	}

	public static synchronized void invalidate() {
		CACHE.clear();
	}

	public @Nullable Glyph glyph(int codepoint) {
		Glyph g = this.glyphs.get(codepoint);
		if (g == null && this != get(DEFAULT)) {
			return get(DEFAULT).glyphs.get(codepoint);
		}
		return g;
	}

	private void load(ResourceManager resources, Identifier fontId, int depth) {
		if (depth > 8) {
			return;
		}
		Identifier jsonId = Identifier.fromNamespaceAndPath(fontId.getNamespace(), "font/" + fontId.getPath() + ".json");
		Optional<Resource> resource = resources.getResource(jsonId);
		if (resource.isEmpty()) {
			return;
		}
		try (Reader reader = new InputStreamReader(resource.get().open(), StandardCharsets.UTF_8)) {
			JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
			for (JsonElement el : root.getAsJsonArray("providers")) {
				JsonObject provider = el.getAsJsonObject();
				String type = provider.get("type").getAsString().replace("minecraft:", "");
				switch (type) {
					case "reference" -> this.load(resources, Identifier.parse(provider.get("id").getAsString()), depth + 1);
					case "bitmap" -> this.loadBitmap(resources, provider);
					default -> {
					}
				}
			}
		} catch (Exception e) {
			Scribble.LOGGER.warn("Could not read font {} for export", fontId, e);
		}
	}

	private void loadBitmap(ResourceManager resources, JsonObject provider) throws Exception {
		Identifier file = Identifier.parse(provider.get("file").getAsString()).withPrefix("textures/");
		int height = provider.has("height") ? provider.get("height").getAsInt() : 8;
		int ascent = provider.get("ascent").getAsInt();
		JsonArray chars = provider.getAsJsonArray("chars");
		Optional<Resource> res = resources.getResource(file);
		if (res.isEmpty() || chars.isEmpty()) {
			return;
		}
		try (InputStream in = res.get().open(); NativeImage image = NativeImage.read(in)) {
			int rows = chars.size();
			int cols = chars.get(0).getAsString().codePointCount(0, chars.get(0).getAsString().length());
			int cellW = image.getWidth() / cols;
			int cellH = image.getHeight() / rows;
			float pixelScale = (float) height / cellH;
			for (int row = 0; row < rows; row++) {
				int[] cps = chars.get(row).getAsString().codePoints().toArray();
				for (int col = 0; col < cps.length; col++) {
					int cp = cps[col];
					if (cp == 0 || this.glyphs.containsKey(cp)) {
						continue;
					}
					boolean[] mask = new boolean[cellW * cellH];
					for (int y = 0; y < cellH; y++) {
						for (int x = 0; x < cellW; x++) {
							mask[y * cellW + x] = image.getLuminanceOrAlpha(col * cellW + x, row * cellH + y) != 0;
						}
					}
					this.glyphs.put(cp, new Glyph(mask, cellW, cellH, pixelScale, 7.0F - ascent));
				}
			}
		}
	}
}
