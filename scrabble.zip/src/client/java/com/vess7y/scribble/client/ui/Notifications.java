package com.vess7y.scribble.client.ui;

import com.vess7y.scribble.client.render.Sprites;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import com.vess7y.scribble.client.ScribbleSounds;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

/**
 * Little cozy notification cards that bounce in at the top right, wait a moment and slide away. Hovering pauses
 * them; clicking runs their action (like "Undo" or "Open folder") or dismisses them.
 */
public final class Notifications {
	private static final int WIDTH = 150;
	private static final long LIFE = 3800;
	private static final long IN_MS = 380;
	private static final long OUT_MS = 260;
	private static final List<Notice> NOTICES = new ArrayList<>();

	private static final class Notice {
		final String icon;
		final Component title;
		final @Nullable Component body;
		final int accent;
		final @Nullable Runnable action;
		final @Nullable Component actionLabel;
		long born = Util.getMillis();
		long elapsed;
		long last = Util.getMillis();
		long dismissedAt = -1;

		Notice(String icon, Component title, @Nullable Component body, int accent, @Nullable Component actionLabel, @Nullable Runnable action) {
			this.icon = icon;
			this.title = title;
			this.body = body;
			this.accent = accent;
			this.actionLabel = actionLabel;
			this.action = action;
		}
	}

	private Notifications() {
	}

	public static void info(String icon, Component title, @Nullable Component body) {
		push(icon, title, body, Ui.ACCENT_SOFT, null, null);
	}

	public static void success(String icon, Component title, @Nullable Component body) {
		push(icon, title, body, 0xFF7BC96F, null, null);
	}

	public static void success(String icon, Component title, @Nullable Component body, Component actionLabel, Runnable action) {
		push(icon, title, body, 0xFF7BC96F, actionLabel, action);
	}

	public static void warn(Component title, @Nullable Component body) {
		push("warn", title, body, 0xFFE8604C, null, null);
	}

	public static void push(String icon, Component title, @Nullable Component body, int accent,
							@Nullable Component actionLabel, @Nullable Runnable action) {
		NOTICES.add(new Notice(icon, title, body, accent, actionLabel, action));
		while (NOTICES.size() > 4) {
			NOTICES.removeFirst();
		}
		ScribbleSounds.play(accent == 0xFF7BC96F ? ScribbleSounds.SUCCESS : ScribbleSounds.CHIME, 1.0F, 0.45F);
	}

	/** Draws the notification stack with its top-right corner at (right, top). */
	public static void render(GuiGraphicsExtractor g, Hotspots hs, int right, int top, double mx, double my) {
		long now = Util.getMillis();
		int y = top;
		Iterator<Notice> it = NOTICES.iterator();
		while (it.hasNext()) {
			Notice n = it.next();
			List<FormattedCharSequence> lines = n.body == null ? List.of() : Ui.font().split(n.body, WIDTH - 32);
			int h = 22 + Math.min(2, lines.size()) * 10 + (n.actionLabel != null ? 12 : 0);
			int x = right - WIDTH;
			boolean hover = Ui.hovered(mx, my, x, y, WIDTH, h);
			if (!hover && n.dismissedAt < 0) {
				n.elapsed += now - n.last;
			}
			n.last = now;
			if (n.dismissedAt < 0 && n.elapsed > LIFE) {
				n.dismissedAt = now;
			}
			float slide;
			float alpha = 1;
			long age = now - n.born;
			if (n.dismissedAt >= 0) {
				float t = Anim.clamp01((now - n.dismissedAt) / (float) OUT_MS);
				if (t >= 1) {
					it.remove();
					continue;
				}
				slide = t * t;
				alpha = 1 - t;
			} else {
				slide = 1 - Anim.easeOutBack(Anim.clamp01(age / (float) IN_MS));
			}
			int ox = Math.round(slide * (WIDTH + 12));
			g.pose().pushMatrix();
			g.pose().translate(ox, 0);
			Ui.shadow(g, x, y, WIDTH, h, 0.7F * alpha);
			Ui.sprite(g, Sprites.NOTIFY, x, y, WIDTH, h, ((int) (alpha * 255) << 24) | 0xFFFFFF);
			// colored tab on the left with a bobbing icon
			g.fill(x + 3, y + 4, x + 5, y + h - 6, n.accent);
			float bob = (float) Math.sin(Anim.time() * 5 + n.born) * 1.2F;
			Ui.animatedIcon(g, n.icon, x + 8, Math.round(y + 3 + bob), alpha, hover, n);
			Ui.text(g, Ui.ellipsize(n.title.getString(), WIDTH - 34), x + 27, y + 5, Ui.TEXT);
			int ly = y + 16;
			for (int i = 0; i < Math.min(2, lines.size()); i++) {
				g.text(Ui.font(), lines.get(i), x + 27, ly, Ui.TEXT_DIM, false);
				ly += 10;
			}
			if (n.actionLabel != null) {
				Ui.text(g, n.actionLabel, x + 27, ly + 1, Ui.ACCENT);
				g.fill(x + 27, ly + 10, x + 27 + Ui.font().width(n.actionLabel), ly + 11, Ui.ACCENT);
			}
			// time left bar
			if (n.dismissedAt < 0) {
				float left = 1 - Anim.clamp01(n.elapsed / (float) LIFE);
				g.fill(x + 6, y + h - 5, x + 6 + Math.round((WIDTH - 12) * left), y + h - 4, (n.accent & 0xFFFFFF) | 0x90000000);
			}
			g.pose().popMatrix();
			Runnable action = n.action;
			hs.add(x, y, WIDTH, h).click(() -> {
				if (action != null) {
					Ui.click();
					action.run();
				}
				n.dismissedAt = Util.getMillis();
			});
			y += h + 4;
		}
	}
}
