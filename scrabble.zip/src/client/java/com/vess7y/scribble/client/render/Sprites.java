package com.vess7y.scribble.client.render;

import com.vess7y.scribble.Scribble;
import net.minecraft.resources.Identifier;

/**
 * Sprite ids from the GUI atlas ({@code assets/scribble/textures/gui/sprites}).
 */
public final class Sprites {
	public static final Identifier DESK = Scribble.id("bg/desk");
	public static final Identifier DESK_DARK = Scribble.id("bg/desk_dark");
	public static final Identifier PAPER_GRAIN = Scribble.id("bg/paper_grain");
	public static final Identifier WHITEBOARD = Scribble.id("bg/whiteboard");
	public static final Identifier CHALKBOARD = Scribble.id("bg/chalkboard");
	public static final Identifier BLUEPRINT = Scribble.id("bg/blueprint");
	public static final Identifier PARCHMENT = Scribble.id("bg/parchment");
	public static final Identifier CORK = Scribble.id("bg/cork");

	public static final Identifier FRAME_WHITEBOARD = Scribble.id("frame/whiteboard");
	public static final Identifier FRAME_CHALKBOARD = Scribble.id("frame/chalkboard");
	public static final Identifier CHALK_TRAY = Scribble.id("deco/chalk_tray");
	public static final Identifier CHALK_STICKS = Scribble.id("deco/chalk_sticks");
	public static final Identifier MARKER_TRAY = Scribble.id("deco/marker_tray");
	public static final Identifier MARKERS = Scribble.id("deco/markers");
	public static final Identifier SPIRAL = Scribble.id("deco/spiral");
	public static final Identifier HOLE = Scribble.id("deco/hole");
	public static final Identifier TAPE = Scribble.id("deco/tape");
	public static final Identifier CHECKBOX = Scribble.id("deco/checkbox");
	public static final Identifier CHECKBOX_CHECKED = Scribble.id("deco/checkbox_checked");
	public static final Identifier PIN = Scribble.id("deco/pin");
	public static final Identifier RING = Scribble.id("deco/ring");

	public static final Identifier PANEL = Scribble.id("ui/panel");
	public static final Identifier PANEL_DARK = Scribble.id("ui/panel_dark");
	public static final Identifier TOOLBAR = Scribble.id("ui/toolbar");
	public static final Identifier TOOLBAR_LIGHT = Scribble.id("ui/toolbar_light");
	public static final Identifier SHADOW = Scribble.id("ui/shadow");
	public static final Identifier NOTIFY = Scribble.id("ui/notify");
	public static final Identifier BUTTON = Scribble.id("ui/button");
	public static final Identifier BUTTON_HOVER = Scribble.id("ui/button_hover");
	public static final Identifier BUTTON_SELECTED = Scribble.id("ui/button_selected");
	public static final Identifier BUTTON_DISABLED = Scribble.id("ui/button_disabled");
	public static final Identifier FIELD = Scribble.id("ui/field");
	public static final Identifier FIELD_FOCUSED = Scribble.id("ui/field_focused");
	public static final Identifier CHIP = Scribble.id("ui/chip");
	public static final Identifier CHIP_HOVER = Scribble.id("ui/chip_hover");
	public static final Identifier CHIP_SELECTED = Scribble.id("ui/chip_selected");
	public static final Identifier SCROLL_TRACK = Scribble.id("ui/scroll_track");
	public static final Identifier SCROLL_THUMB = Scribble.id("ui/scroll_thumb");
	public static final Identifier SLIDER_TRACK = Scribble.id("ui/slider_track");
	public static final Identifier SLIDER_KNOB = Scribble.id("ui/slider_knob");
	public static final Identifier SWATCH = Scribble.id("ui/swatch");
	public static final Identifier SWATCH_SELECTED = Scribble.id("ui/swatch_selected");
	public static final Identifier BADGE = Scribble.id("ui/badge");
	public static final Identifier CARD = Scribble.id("ui/card");
	public static final Identifier CARD_HOVER = Scribble.id("ui/card_hover");
	public static final Identifier LOGO = Scribble.id("ui/logo");
	public static final Identifier PENCIL = Scribble.id("ui/pencil");
	public static final int LOGO_WIDTH = 96;
	public static final int LOGO_HEIGHT = 26;

	public static final String[] STAMPS = {
			"heart", "star", "creeper", "diamond", "check", "cross", "exclaim",
			"question", "arrow", "sun", "smile", "sword", "pickaxe"
	};

	private Sprites() {
	}

	public static Identifier icon(String name) {
		return Scribble.id("icon/" + name);
	}

	public static Identifier stamp(String name) {
		return Scribble.id("stamp/" + name);
	}

	/** Raw texture location of a GUI sprite, for reading its pixels from the resource manager. */
	public static Identifier textureOf(Identifier sprite) {
		return Identifier.fromNamespaceAndPath(sprite.getNamespace(), "textures/gui/sprites/" + sprite.getPath() + ".png");
	}
}
