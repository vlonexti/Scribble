package com.vess7y.scribble.client.text;

import com.vess7y.scribble.client.note.Align;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import org.jspecify.annotations.Nullable;

/**
 * Editing operations on a note's rich text: caret and selection, typing, deleting, formatting and paragraph styles.
 * Layout dependent movement (up / down / home / end) lives in the editor screen.
 */
public final class TextEditor {
	/** Rich copy of the last copied text, used when pasting text we copied ourselves. */
	private static List<Paragraph> richClipboard = List.of();
	private static String richClipboardText = "";

	private final Note note;
	private final Consumer<@Nullable String> beforeEdit;
	private final Runnable afterEdit;
	public TextLayout.Pos cursor = new TextLayout.Pos(0, 0);
	public TextLayout.Pos anchor = this.cursor;
	/** Format for the next typed characters, set by toggling B / I / U with no selection. */
	public @Nullable TextFormat pending;
	/** Remembered x for vertical caret movement, or -1. */
	public int goalX = -1;

	/**
	 * @param beforeEdit called before every modification with a coalesce key (for undo history)
	 * @param afterEdit  called after every modification
	 */
	public TextEditor(Note note, Consumer<@Nullable String> beforeEdit, Runnable afterEdit) {
		this.note = note;
		this.beforeEdit = beforeEdit;
		this.afterEdit = afterEdit;
	}

	private List<Paragraph> paras() {
		return this.note.paragraphs;
	}

	private Paragraph para(int i) {
		return this.note.paragraphs.get(i);
	}

	// ------------------------------------------------------------------ selection

	public boolean hasSelection() {
		return !this.cursor.equals(this.anchor);
	}

	public TextLayout.Pos selStart() {
		return this.cursor.compareTo(this.anchor) <= 0 ? this.cursor : this.anchor;
	}

	public TextLayout.Pos selEnd() {
		return this.cursor.compareTo(this.anchor) <= 0 ? this.anchor : this.cursor;
	}

	public void clamp() {
		this.cursor = this.clamp(this.cursor);
		this.anchor = this.clamp(this.anchor);
	}

	private TextLayout.Pos clamp(TextLayout.Pos p) {
		int para = Math.max(0, Math.min(p.para(), this.paras().size() - 1));
		return new TextLayout.Pos(para, Math.max(0, Math.min(p.offset(), this.para(para).length())));
	}

	public void moveTo(TextLayout.Pos pos, boolean extend) {
		this.cursor = this.clamp(pos);
		if (!extend) {
			this.anchor = this.cursor;
		}
		this.pending = null;
	}

	public void select(TextLayout.Pos from, TextLayout.Pos to) {
		this.anchor = this.clamp(from);
		this.cursor = this.clamp(to);
		this.pending = null;
	}

	public void selectAll() {
		int last = this.paras().size() - 1;
		this.select(new TextLayout.Pos(0, 0), new TextLayout.Pos(last, this.para(last).length()));
	}

	public void selectWord(TextLayout.Pos at) {
		Paragraph p = this.para(at.para());
		int s = at.offset();
		int e = at.offset();
		while (s > 0 && isWordChar(p.charAt(s - 1))) {
			s--;
		}
		while (e < p.length() && isWordChar(p.charAt(e))) {
			e++;
		}
		this.select(new TextLayout.Pos(at.para(), s), new TextLayout.Pos(at.para(), e));
	}

	public void selectParagraph(int para) {
		this.select(new TextLayout.Pos(para, 0), new TextLayout.Pos(para, this.para(para).length()));
	}

	private static boolean isWordChar(char c) {
		return Character.isLetterOrDigit(c) || c == '_' || c == '\'';
	}

	public String selectedText() {
		StringBuilder sb = new StringBuilder();
		TextLayout.Pos s = this.selStart();
		TextLayout.Pos e = this.selEnd();
		for (int i = s.para(); i <= e.para(); i++) {
			Paragraph p = this.para(i);
			int from = i == s.para() ? s.offset() : 0;
			int to = i == e.para() ? e.offset() : p.length();
			if (i > s.para()) {
				sb.append('\n');
			}
			sb.append(p.text(), from, to);
		}
		return sb.toString();
	}

	private List<Paragraph> selectedParagraphs() {
		List<Paragraph> out = new ArrayList<>();
		TextLayout.Pos s = this.selStart();
		TextLayout.Pos e = this.selEnd();
		for (int i = s.para(); i <= e.para(); i++) {
			Paragraph p = this.para(i);
			out.add(p.slice(i == s.para() ? s.offset() : 0, i == e.para() ? e.offset() : p.length()));
		}
		return out;
	}

	// ------------------------------------------------------------------ caret movement

	public void left(boolean extend, boolean word) {
		if (this.hasSelection() && !extend) {
			this.moveTo(this.selStart(), false);
			return;
		}
		TextLayout.Pos c = this.cursor;
		if (c.offset() > 0) {
			int off = word ? this.wordBoundary(c.para(), c.offset(), -1) : c.offset() - 1;
			this.moveTo(new TextLayout.Pos(c.para(), off), extend);
		} else if (c.para() > 0) {
			this.moveTo(new TextLayout.Pos(c.para() - 1, this.para(c.para() - 1).length()), extend);
		}
	}

	public void right(boolean extend, boolean word) {
		if (this.hasSelection() && !extend) {
			this.moveTo(this.selEnd(), false);
			return;
		}
		TextLayout.Pos c = this.cursor;
		Paragraph p = this.para(c.para());
		if (c.offset() < p.length()) {
			int off = word ? this.wordBoundary(c.para(), c.offset(), 1) : c.offset() + 1;
			this.moveTo(new TextLayout.Pos(c.para(), off), extend);
		} else if (c.para() < this.paras().size() - 1) {
			this.moveTo(new TextLayout.Pos(c.para() + 1, 0), extend);
		}
	}

	public void docStart(boolean extend) {
		this.moveTo(new TextLayout.Pos(0, 0), extend);
	}

	public void docEnd(boolean extend) {
		int last = this.paras().size() - 1;
		this.moveTo(new TextLayout.Pos(last, this.para(last).length()), extend);
	}

	private int wordBoundary(int para, int offset, int dir) {
		Paragraph p = this.para(para);
		int i = offset;
		if (dir < 0) {
			while (i > 0 && !isWordChar(p.charAt(i - 1))) {
				i--;
			}
			while (i > 0 && isWordChar(p.charAt(i - 1))) {
				i--;
			}
		} else {
			while (i < p.length() && isWordChar(p.charAt(i))) {
				i++;
			}
			while (i < p.length() && !isWordChar(p.charAt(i))) {
				i++;
			}
		}
		return i;
	}

	// ------------------------------------------------------------------ editing

	private void edit(@Nullable String key) {
		this.beforeEdit.accept(key);
	}

	private void done() {
		this.goalX = -1;
		this.afterEdit.run();
	}

	/** Deletes the selection without recording history. Returns true if something was removed. */
	private boolean removeSelection() {
		if (!this.hasSelection()) {
			return false;
		}
		TextLayout.Pos s = this.selStart();
		TextLayout.Pos e = this.selEnd();
		Paragraph first = this.para(s.para());
		if (s.para() == e.para()) {
			first.delete(s.offset(), e.offset());
		} else {
			Paragraph last = this.para(e.para());
			first.delete(s.offset(), first.length());
			last.delete(0, e.offset());
			first.append(last);
			this.paras().subList(s.para() + 1, e.para() + 1).clear();
		}
		this.cursor = s;
		this.anchor = s;
		return true;
	}

	public void deleteSelection() {
		if (this.hasSelection()) {
			this.edit(null);
			this.removeSelection();
			this.done();
		}
	}

	private TextFormat typingFormat() {
		if (this.pending != null) {
			return this.pending;
		}
		return this.para(this.cursor.para()).formatForInsert(this.cursor.offset());
	}

	/** Types text. Newlines split paragraphs. */
	public void type(String s) {
		if (s.isEmpty()) {
			return;
		}
		this.edit(s.indexOf('\n') < 0 && s.length() == 1 ? (s.equals(" ") ? "space" : "type") : null);
		TextFormat f = this.typingFormat();
		this.removeSelection();
		String[] lines = s.replace("\r\n", "\n").replace('\r', '\n').replace('\t', ' ').split("\n", -1);
		List<Paragraph> clip = new ArrayList<>();
		Paragraph current = this.para(this.cursor.para());
		for (String line : lines) {
			Paragraph p = new Paragraph();
			p.insert(0, line, f);
			p.style = current.style == ParaStyle.PAGE_BREAK ? ParaStyle.BODY : current.style;
			p.indent = current.indent;
			p.align = current.align;
			clip.add(p);
		}
		this.insertParagraphs(clip, false);
		TextFormat keep = this.pending;
		this.done();
		this.pending = keep;
	}

	/** Inserts rich paragraphs at the caret. The first and last merge with the text around the caret. */
	private void insertParagraphs(List<Paragraph> clip, boolean keepStyles) {
		int pi = this.cursor.para();
		Paragraph cur = this.para(pi);
		if (cur.style == ParaStyle.PAGE_BREAK) {
			cur.style = ParaStyle.BODY;
		}
		Paragraph tail = cur.split(this.cursor.offset());
		Paragraph first = clip.get(0);
		cur.append(first);
		if (clip.size() == 1) {
			int off = cur.length();
			cur.append(tail);
			this.cursor = new TextLayout.Pos(pi, off);
		} else {
			if (keepStyles && cur.length() == first.length()) {
				cur.style = first.style;
				cur.indent = first.indent;
				cur.align = first.align;
				cur.checked = first.checked;
			}
			List<Paragraph> middle = new ArrayList<>();
			for (int i = 1; i < clip.size(); i++) {
				middle.add(clip.get(i).copy());
			}
			Paragraph last = middle.get(middle.size() - 1);
			int off = last.length();
			last.append(tail);
			this.paras().addAll(pi + 1, middle);
			this.cursor = new TextLayout.Pos(pi + middle.size(), off);
		}
		this.anchor = this.cursor;
	}

	public void newline() {
		this.edit(null);
		this.removeSelection();
		int pi = this.cursor.para();
		Paragraph cur = this.para(pi);
		if (cur.isEmpty() && (cur.style.isList() || cur.style == ParaStyle.QUOTE)) {
			// Enter on an empty list item ends the list, like in word processors
			if (cur.indent > 0) {
				cur.indent--;
			} else {
				cur.style = ParaStyle.BODY;
			}
			this.done();
			return;
		}
		Paragraph tail = cur.split(this.cursor.offset());
		if (cur.style == ParaStyle.TITLE || cur.style == ParaStyle.HEADING || cur.style == ParaStyle.PAGE_BREAK) {
			tail.style = ParaStyle.BODY;
			if (cur.style == ParaStyle.PAGE_BREAK) {
				tail.indent = 0;
			}
		}
		tail.checked = false;
		this.paras().add(pi + 1, tail);
		this.moveTo(new TextLayout.Pos(pi + 1, 0), false);
		this.done();
	}

	public void backspace(boolean word) {
		if (this.hasSelection()) {
			this.deleteSelection();
			return;
		}
		TextLayout.Pos c = this.cursor;
		Paragraph p = this.para(c.para());
		if (c.offset() > 0) {
			this.edit("delete");
			int from = word ? this.wordBoundary(c.para(), c.offset(), -1) : c.offset() - 1;
			p.delete(from, c.offset());
			this.moveTo(new TextLayout.Pos(c.para(), from), false);
			this.done();
			return;
		}
		if (p.style != ParaStyle.BODY && p.style != ParaStyle.PAGE_BREAK) {
			this.edit(null);
			if (p.indent > 0 && p.style.isList()) {
				p.indent--;
			} else {
				p.style = ParaStyle.BODY;
			}
			this.done();
			return;
		}
		if (p.indent > 0) {
			this.edit(null);
			p.indent--;
			this.done();
			return;
		}
		if (c.para() == 0) {
			return;
		}
		this.edit(null);
		Paragraph prev = this.para(c.para() - 1);
		if (prev.style == ParaStyle.PAGE_BREAK) {
			this.paras().remove(c.para() - 1);
			this.moveTo(new TextLayout.Pos(c.para() - 1, 0), false);
		} else {
			int off = prev.length();
			prev.append(p);
			this.paras().remove(c.para());
			this.moveTo(new TextLayout.Pos(c.para() - 1, off), false);
		}
		this.done();
	}

	public void delete(boolean word) {
		if (this.hasSelection()) {
			this.deleteSelection();
			return;
		}
		TextLayout.Pos c = this.cursor;
		Paragraph p = this.para(c.para());
		if (c.offset() < p.length()) {
			this.edit("delete_fwd");
			int to = word ? this.wordBoundary(c.para(), c.offset(), 1) : c.offset() + 1;
			p.delete(c.offset(), to);
			this.done();
			return;
		}
		if (c.para() >= this.paras().size() - 1) {
			return;
		}
		this.edit(null);
		Paragraph next = this.para(c.para() + 1);
		if (next.style != ParaStyle.PAGE_BREAK) {
			p.append(next);
		}
		this.paras().remove(c.para() + 1);
		this.done();
	}

	public void insertPageBreak() {
		this.edit(null);
		this.removeSelection();
		int pi = this.cursor.para();
		Paragraph cur = this.para(pi);
		Paragraph tail = cur.split(this.cursor.offset());
		if (tail.style.isList() || tail.style == ParaStyle.TITLE || tail.style == ParaStyle.HEADING) {
			tail.style = ParaStyle.BODY;
		}
		Paragraph brk = new Paragraph();
		brk.style = ParaStyle.PAGE_BREAK;
		int insertAt = pi + 1;
		if (cur.isEmpty() && cur.style != ParaStyle.PAGE_BREAK) {
			this.paras().set(pi, brk);
			insertAt = pi + 1;
		} else {
			this.paras().add(insertAt++, brk);
		}
		this.paras().add(insertAt, tail);
		this.moveTo(new TextLayout.Pos(insertAt, 0), false);
		this.done();
	}

	// ------------------------------------------------------------------ clipboard

	public String copy() {
		String text = this.selectedText();
		richClipboard = this.selectedParagraphs();
		richClipboardText = text;
		return text;
	}

	public String cut() {
		String text = this.copy();
		this.deleteSelection();
		return text;
	}

	public void paste(String clipboard) {
		if (clipboard.isEmpty()) {
			return;
		}
		if (clipboard.equals(richClipboardText) && !richClipboard.isEmpty()) {
			this.edit(null);
			this.removeSelection();
			List<Paragraph> copies = new ArrayList<>();
			for (Paragraph p : richClipboard) {
				copies.add(p.copy());
			}
			this.insertParagraphs(copies, true);
			this.done();
		} else {
			this.type(clipboard);
		}
	}

	// ------------------------------------------------------------------ formatting

	/** Format at the caret (or of the selection start). */
	public TextFormat currentFormat() {
		if (this.pending != null && !this.hasSelection()) {
			return this.pending;
		}
		if (this.hasSelection()) {
			TextLayout.Pos s = this.selStart();
			Paragraph p = this.para(s.para());
			if (s.offset() < p.length()) {
				return p.formatAt(s.offset());
			}
		}
		return this.para(this.cursor.para()).formatForInsert(this.cursor.offset());
	}

	public boolean isActive(TextFormat.Flag flag) {
		return this.currentFormat().get(flag);
	}

	public void toggle(TextFormat.Flag flag) {
		boolean value = !this.isActive(flag);
		this.applyFormat(f -> f.with(flag, value));
	}

	public void setColor(int color) {
		this.applyFormat(f -> f.withColor(color));
	}

	public void setHighlight(int color) {
		this.applyFormat(f -> f.withHighlight(color));
	}

	public void clearFormatting() {
		this.applyFormat(f -> TextFormat.PLAIN);
	}

	private void applyFormat(UnaryOperator<TextFormat> op) {
		if (!this.hasSelection()) {
			this.pending = op.apply(this.typingFormat());
			return;
		}
		this.edit(null);
		TextLayout.Pos s = this.selStart();
		TextLayout.Pos e = this.selEnd();
		for (int i = s.para(); i <= e.para(); i++) {
			Paragraph p = this.para(i);
			p.applyFormat(i == s.para() ? s.offset() : 0, i == e.para() ? e.offset() : p.length(), op);
		}
		this.done();
	}

	public ParaStyle currentStyle() {
		return this.para(this.cursor.para()).style;
	}

	public Align currentAlign() {
		return this.para(this.cursor.para()).align;
	}

	private void forSelectedParagraphs(Consumer<Paragraph> op) {
		this.edit(null);
		for (int i = this.selStart().para(); i <= this.selEnd().para(); i++) {
			op.accept(this.para(i));
		}
		this.done();
	}

	public void setStyle(ParaStyle style) {
		boolean all = true;
		for (int i = this.selStart().para(); i <= this.selEnd().para(); i++) {
			all &= this.para(i).style == style;
		}
		ParaStyle target = all && style != ParaStyle.BODY ? ParaStyle.BODY : style;
		this.forSelectedParagraphs(p -> {
			if (p.style != ParaStyle.PAGE_BREAK) {
				p.style = target;
				if (target != ParaStyle.CHECKLIST) {
					p.checked = false;
				}
			}
		});
	}

	public void setAlign(Align align) {
		this.forSelectedParagraphs(p -> p.align = align);
	}

	public void indent(int delta) {
		this.forSelectedParagraphs(p -> p.indent = Math.max(0, Math.min(6, p.indent + delta)));
	}

	public void toggleChecked(int para) {
		this.edit(null);
		Paragraph p = this.para(para);
		p.checked = !p.checked;
		this.done();
	}
}
