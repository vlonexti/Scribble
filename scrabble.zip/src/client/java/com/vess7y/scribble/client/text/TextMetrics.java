package com.vess7y.scribble.client.text;

import com.vess7y.scribble.client.note.Paragraph;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

/**
 * Character widths in font pixels, cached. Notes always use Minecraft's own default font, so whatever font the
 * active resource packs provide is what notes are written in. Used both for layout and for the software
 * rasterizer so exported pages line up exactly with what is shown in game.
 */
public final class TextMetrics {
	private static TextMetrics instance = new TextMetrics();

	private final Int2IntOpenHashMap cache = new Int2IntOpenHashMap();

	private TextMetrics() {
		this.cache.defaultReturnValue(-1);
	}

	public static TextMetrics get() {
		return instance;
	}

	/** Forget cached widths; called when Scribble screens open so resource pack font changes are picked up. */
	public static void invalidate() {
		instance = new TextMetrics();
	}

	public int charWidth(char c, boolean bold) {
		int key = c | (bold ? 0x10000 : 0);
		int w = this.cache.get(key);
		if (w < 0) {
			Font font = Minecraft.getInstance().font;
			w = font.width(Component.literal(String.valueOf(c)).withStyle(Style.EMPTY.withBold(bold)));
			this.cache.put(key, w);
		}
		return w;
	}

	public int width(Paragraph p, int start, int end) {
		int w = 0;
		for (int i = start; i < end; i++) {
			w += this.charWidth(p.charAt(i), p.formatAt(i).bold());
		}
		return w;
	}

	public int width(String s, boolean bold) {
		int w = 0;
		for (int i = 0; i < s.length(); i++) {
			w += this.charWidth(s.charAt(i), bold);
		}
		return w;
	}
}
