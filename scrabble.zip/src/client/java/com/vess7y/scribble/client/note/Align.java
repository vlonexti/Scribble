package com.vess7y.scribble.client.note;

public enum Align {
	LEFT("left"),
	CENTER("center"),
	RIGHT("right");

	public final String id;

	Align(String id) {
		this.id = id;
	}

	public static Align byId(String id) {
		for (Align a : values()) {
			if (a.id.equals(id)) {
				return a;
			}
		}
		return LEFT;
	}
}
