package com.vess7y.scribble.client.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import org.jspecify.annotations.Nullable;

/**
 * Floating cream panels (dropdown menus, color pickers) that pop in with a little bounce. A screen shows at most
 * one; clicking outside closes it.
 */
public abstract class Popup {
	protected int x, y, w, h;
	private Runnable closer = () -> {
	};
	private final Object animKey = new Object();
	private boolean opened;

	public void setCloser(Runnable closer) {
		this.closer = closer;
	}

	public void close() {
		this.closer.run();
	}

	public boolean contains(double mx, double my) {
		return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
	}

	/** Positions the popup below/at the anchor, kept inside the screen. */
	public Popup at(int anchorX, int anchorY, int screenW, int screenH) {
		this.measure();
		this.x = Math.max(2, Math.min(anchorX, screenW - this.w - 2));
		this.y = anchorY;
		if (this.y + this.h > screenH - 2) {
			this.y = Math.max(2, screenH - this.h - 2);
		}
		return this;
	}

	protected abstract void measure();

	protected abstract void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my);

	public void render(GuiGraphicsExtractor g, Hotspots hs, double mx, double my) {
		if (!this.opened) {
			this.opened = true;
			Anim.set(this.animKey, 0.82F);
		}
		float s = Anim.bouncy(this.animKey, 1.0F);
		Ui.pushScale(g, this.x + this.w / 2.0F, this.y, s);
		Ui.panel(g, this.x, this.y, this.w, this.h);
		hs.add(this.x, this.y, this.w, this.h).noPointer();
		this.renderContent(g, hs, mx, my);
		Ui.popScale(g);
	}

	protected Runnable closing(Runnable action) {
		return () -> {
			this.close();
			action.run();
		};
	}

	// ------------------------------------------------------------------ menu

	public static final class Menu extends Popup {
		private static final int ROW = 18;
		private final List<Item> items = new ArrayList<>();

		private record Item(@Nullable String icon, Component label, @Nullable String shortcut, @Nullable Runnable action,
							boolean enabled, boolean checked, int kind) {
		}

		public Menu item(@Nullable String icon, Component label, Runnable action) {
			this.items.add(new Item(icon, label, null, action, true, false, 0));
			return this;
		}

		public Menu item(@Nullable String icon, Component label, @Nullable String shortcut, boolean enabled, boolean checked, Runnable action) {
			this.items.add(new Item(icon, label, shortcut, action, enabled, checked, 0));
			return this;
		}

		public Menu separator() {
			this.items.add(new Item(null, Component.empty(), null, null, false, false, 1));
			return this;
		}

		public Menu header(Component label) {
			this.items.add(new Item(null, label, null, null, false, false, 2));
			return this;
		}

		@Override
		protected void measure() {
			int maxW = 60;
			int height = 8;
			for (Item it : this.items) {
				if (it.kind == 1) {
					height += 5;
					continue;
				}
				int iw = Ui.font().width(it.label) + 32;
				if (it.shortcut != null) {
					iw += Ui.font().width(it.shortcut) + 12;
				}
				maxW = Math.max(maxW, iw);
				height += it.kind == 2 ? 13 : ROW;
			}
			this.w = maxW + 8;
			this.h = height;
		}

		@Override
		protected void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my) {
			int cy = this.y + 4;
			for (Item it : this.items) {
				if (it.kind == 1) {
					Ui.groove(g, this.x + 6, this.x + this.w - 6, cy + 2);
					cy += 5;
					continue;
				}
				if (it.kind == 2) {
					Ui.text(g, it.label, this.x + 8, cy + 3, Ui.TEXT_DIM);
					cy += 13;
					continue;
				}
				boolean hover = it.enabled && Ui.hovered(mx, my, this.x + 3, cy, this.w - 6, ROW);
				float slide = Anim.smooth(it, hover ? 1 : 0);
				if (slide > 0.02F) {
					int a = (int) (slide * 255);
					g.fill(this.x + 4, cy, this.x + this.w - 4, cy + ROW, (a << 24) | 0xFFE2B0);
					g.fill(this.x + 4, cy, this.x + 6, cy + ROW, (a << 24) | (Ui.ACCENT & 0xFFFFFF));
				}
				int dx = Math.round(slide * 2);
				if (it.checked) {
					Ui.icon(g, "check", this.x + 6 + dx, cy + 1);
				} else if (it.icon != null) {
					Ui.animatedIcon(g, it.icon, this.x + 6 + dx, cy + 1, it.enabled ? 1.0F : 0.4F, hover, it);
				}
				int color = !it.enabled ? 0xFFB8A48C : Ui.TEXT;
				Ui.text(g, it.label, this.x + 26 + dx, cy + 5, color);
				if (it.shortcut != null) {
					int sw = Ui.font().width(it.shortcut);
					Ui.text(g, it.shortcut, this.x + this.w - 8 - sw, cy + 5, Ui.TEXT_DIM);
				}
				if (it.enabled && it.action != null) {
					Runnable run = this.closing(it.action);
					hs.add(this.x + 3, cy, this.w - 6, ROW).click(() -> {
						Ui.click();
						run.run();
					});
				}
				cy += ROW;
			}
		}
	}

	// ------------------------------------------------------------------ swatches

	public static final class Swatches extends Popup {
		private static final int SIZE = 12;
		private static final int GAP = 2;
		private final List<Section> sections = new ArrayList<>();
		private final int selected;
		private final IntConsumer onPick;
		private final boolean allowNone;
		private int cols = 8;

		private record Section(Component title, int[] colors, Component @Nullable [] names) {
		}

		public Swatches(int selected, boolean allowNone, IntConsumer onPick) {
			this.selected = selected;
			this.allowNone = allowNone;
			this.onPick = onPick;
		}

		public Swatches columns(int cols) {
			this.cols = cols;
			return this;
		}

		public Swatches section(Component title, int[] colors) {
			this.sections.add(new Section(title, colors, null));
			return this;
		}

		public Swatches section(Component title, List<com.vess7y.scribble.client.note.MinecraftColors.Swatch> swatches) {
			Component[] names = new Component[swatches.size()];
			for (int i = 0; i < names.length; i++) {
				names[i] = swatches.get(i).name();
			}
			this.sections.add(new Section(title, com.vess7y.scribble.client.note.MinecraftColors.argb(swatches), names));
			return this;
		}

		@Override
		protected void measure() {
			this.w = this.cols * (SIZE + GAP) - GAP + 14;
			int height = 8;
			for (Section s : this.sections) {
				height += 12 + this.rows(s.colors.length) * (SIZE + GAP);
			}
			if (this.allowNone) {
				height += SIZE + GAP + 2;
			}
			this.h = height + 4;
		}

		private int rows(int n) {
			return (n + this.cols - 1) / this.cols;
		}

		@Override
		protected void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my) {
			int cy = this.y + 7;
			if (this.allowNone) {
				Ui.swatch(g, hs, mx, my, this.x + 7, cy, SIZE, 0, this.selected == 0,
						Component.translatable("scribble.color.none"), this.closing(() -> this.onPick.accept(0)));
				Ui.text(g, Component.translatable("scribble.color.none"), this.x + 7 + SIZE + 4, cy + 2, Ui.TEXT_DIM);
				cy += SIZE + GAP + 2;
			}
			for (Section s : this.sections) {
				Ui.text(g, s.title, this.x + 7, cy, Ui.TEXT_DIM);
				cy += 12;
				for (int i = 0; i < s.colors.length; i++) {
					int c = s.colors[i];
					int sx = this.x + 7 + (i % this.cols) * (SIZE + GAP);
					int sy = cy + (i / this.cols) * (SIZE + GAP);
					Component name = s.names != null ? s.names[i] : null;
					Ui.swatch(g, hs, mx, my, sx, sy, SIZE, c, c == this.selected, name, this.closing(() -> this.onPick.accept(c)));
				}
				cy += this.rows(s.colors.length) * (SIZE + GAP);
			}
		}
	}
}
