package com.vess7y.scribble.client.note;

/**
 * Block level style of a paragraph, similar to the paragraph styles of a word processor.
 */
public enum ParaStyle {
	BODY("body", 1, 0),
	TITLE("title", 2, 0),
	HEADING("heading", 1, 0),
	BULLET("bullet", 1, 10),
	NUMBERED("numbered", 1, 14),
	CHECKLIST("checklist", 1, 12),
	QUOTE("quote", 1, 9),
	PAGE_BREAK("page_break", 1, 0);

	public final String id;
	/** Text scale multiplier (and number of line slots a line occupies). */
	public final int scale;
	/** Room reserved in front of the text for the bullet / number / checkbox, in unscaled page units. */
	public final int gutter;

	ParaStyle(String id, int scale, int gutter) {
		this.id = id;
		this.scale = scale;
		this.gutter = gutter;
	}

	public boolean isList() {
		return this == BULLET || this == NUMBERED || this == CHECKLIST;
	}

	public String translationKey() {
		return "scribble.style." + this.id;
	}

	public static ParaStyle byId(String id) {
		for (ParaStyle s : values()) {
			if (s.id.equals(id)) {
				return s;
			}
		}
		return BODY;
	}
}
