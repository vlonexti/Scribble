package com.vess7y.scribble.client.render;

import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import com.vess7y.scribble.client.text.TextLayout;
import com.vess7y.scribble.client.text.TextMetrics;
import java.util.ArrayList;
import java.util.List;
import org.jspecify.annotations.Nullable;

/**
 * Draws a complete page (surface, rulings, decorations, text and ink) onto any {@link PageCanvas}.
 */
public final class PageComposer {
	private PageComposer() {
	}

	public static void draw(PageCanvas c, Note note, TextLayout layout, TextMetrics m, int page, int pageCount,
							@Nullable InkLayer ink, boolean editor) {
		NoteType t = note.type;
		int w = t.pageWidth;
		int h = t.pageHeight;

		drawSurface(c, note, w, h);
		drawRulings(c, note, page, w, h);
		drawText(c, note, layout, m, page, editor);
		if (ink != null) {
			c.ink(ink, 0, 0, w, h);
		}
		drawOverlay(c, note, layout, m, page, pageCount, w, h);
	}

	// ------------------------------------------------------------------ surfaces

	private static void drawSurface(PageCanvas c, Note note, int w, int h) {
		switch (note.type) {
			case WHITEBOARD -> {
				c.sprite(Sprites.WHITEBOARD, 0, 0, w, h);
				c.sprite(Sprites.FRAME_WHITEBOARD, -6, -6, w + 12, h + 12);
				int trayW = w * 2 / 3;
				int trayX = (w - trayW) / 2;
				c.sprite(Sprites.MARKER_TRAY, trayX, h + 4, trayW, 8);
				c.sprite(Sprites.MARKERS, trayX + 12, h - 1, 52, 6);
			}
			case CHALKBOARD -> {
				c.sprite(Sprites.CHALKBOARD, 0, 0, w, h);
				c.sprite(Sprites.FRAME_CHALKBOARD, -6, -6, w + 12, h + 12);
				int trayW = w * 2 / 3;
				int trayX = (w - trayW) / 2;
				c.sprite(Sprites.CHALK_TRAY, trayX, h + 4, trayW, 8);
				c.sprite(Sprites.CHALK_STICKS, trayX + 14, h, 48, 6);
			}
			case BLUEPRINT -> c.sprite(Sprites.BLUEPRINT, 0, 0, w, h);
			case PARCHMENT -> {
				c.sprite(Sprites.PARCHMENT, 0, 0, w, h);
				// aged, darker edges
				for (int i = 0; i < 6; i++) {
					int a = (6 - i) * 9;
					int col = (a << 24) | 0x5A3A14;
					c.fill(i, i, w - i, i + 1, col);
					c.fill(i, h - i - 1, w - i, h - i, col);
					c.fill(i, i + 1, i + 1, h - i - 1, col);
					c.fill(w - i - 1, i + 1, w - i, h - i - 1, col);
				}
			}
			default -> {
				c.fill(0, 0, w, h, note.paper.argb);
				c.sprite(Sprites.PAPER_GRAIN, 0, 0, w, h);
				if (note.type == NoteType.STICKY) {
					c.fill(0, 0, w, 18, 0x10000000);
					for (int i = 0; i < 8; i++) {
						c.fill(0, h - 8 + i, w, h - 7 + i, ((i + 1) * 4 << 24));
					}
				}
			}
		}
	}

	private static void drawRulings(PageCanvas c, Note note, int page, int w, int h) {
		NoteType t = note.type;
		boolean dark = note.paper.isDark();
		int lh = t.lineHeight();
		switch (t) {
			case LINED -> {
				// loose-leaf notebook paper: a ruled line under every writing line, top to bottom
				int line = dark ? 0x48C8DCFF : 0x9A86B4E0;
				int header = dark ? 0x70C8DCFF : 0xC07AA6D8;
				for (int s = 0; s < t.slotsPerPage(); s++) {
					int y = t.marginTop + (s + 1) * lh;
					c.fill(0, y, w, y + 1, s == 0 ? header : line);
				}
				int marginX = t.marginLeft - 5;
				int red = dark ? 0x70FF9090 : 0xB8E8808A;
				c.fill(marginX, 0, marginX + 1, h, red);
				c.fill(marginX + 2, 0, marginX + 3, h, (red & 0xFFFFFF) | 0x50000000);
				drawHoles(c, page, w, h);
			}
			case GRID -> {
				int minor = dark ? 0x26FFFFFF : 0x58A8CBEA;
				int major = dark ? 0x40FFFFFF : 0x90A8CBEA;
				for (int i = 0, x = 0; x <= w; x += lh, i++) {
					c.fill(x, 0, x + 1, h, i % 5 == 0 ? major : minor);
				}
				for (int i = 0, y = 0; y <= h; y += lh, i++) {
					c.fill(0, y, w, y + 1, i % 5 == 0 ? major : minor);
				}
			}
			case DOTTED -> {
				int dot = dark ? 0x70FFFFFF : 0x90808080;
				for (int y = lh; y < h - 4; y += lh) {
					for (int x = lh; x < w - 4; x += lh) {
						c.fill(x, y, x + 1, y + 1, dot);
					}
				}
			}
			case BLUEPRINT -> {
				for (int i = 0, x = 0; x <= w; x += lh, i++) {
					c.fill(x, 0, x + 1, h, i % 4 == 0 ? 0x40FFFFFF : 0x1CFFFFFF);
				}
				for (int i = 0, y = 0; y <= h; y += lh, i++) {
					c.fill(0, y, w, y + 1, i % 4 == 0 ? 0x40FFFFFF : 0x1CFFFFFF);
				}
				outline(c, 6, 6, w - 6, h - 6, 0xD0EAF4FF);
				outline(c, 8, 8, w - 8, h - 8, 0x70EAF4FF);
			}
			default -> {
			}
		}
	}

	/** Three binder holes along the bound edge: left on right-hand (even) pages, right on left-hand pages. */
	private static void drawHoles(PageCanvas c, int page, int w, int h) {
		int x = page % 2 == 0 ? 9 : w - 17;
		for (int i = 0; i < 3; i++) {
			c.sprite(Sprites.HOLE, x, h * (18 + i * 32) / 100 - 4, 8, 8);
		}
	}

	private static void drawOverlay(PageCanvas c, Note note, TextLayout layout, TextMetrics m, int page, int pageCount, int w, int h) {
		switch (note.type) {
			case STICKY -> c.sprite(Sprites.TAPE, w / 2 - 18, -5, 36, 10);
			case BLUEPRINT -> {
				// title block in the bottom right corner, like a real drawing sheet
				int x0 = w - 132;
				int y0 = h - 36;
				int x1 = w - 10;
				int y1 = h - 10;
				c.fill(x0, y0, x1, y1, 0x30001A40);
				outline(c, x0, y0, x1, y1, 0xD0EAF4FF);
				c.fill(x0, y0 + 13, x1, y0 + 14, 0x90EAF4FF);
				c.fill(x1 - 34, y0 + 13, x1 - 33, y1, 0x90EAF4FF);
				String title = note.title.isEmpty() ? "UNTITLED" : note.title.toUpperCase(java.util.Locale.ROOT);
				title = trimToWidth(m, title, x1 - x0 - 8);
				if (c.detailedText()) {
					c.text(List.of(new PageCanvas.Run(title, false, false, false, false, 0xFFEAF4FF)), x0 + 4, y0 + 3, 1);
					c.text(List.of(new PageCanvas.Run("SCRIBBLE", false, false, false, false, 0xFF9FD0FF)), x0 + 4, y0 + 16, 1);
					c.text(List.of(new PageCanvas.Run((page + 1) + "/" + pageCount, false, false, false, false, 0xFFFFE680)), x1 - 30, y0 + 16, 1);
				}
			}
			default -> {
			}
		}
	}

	private static void outline(PageCanvas c, int x0, int y0, int x1, int y1, int col) {
		c.fill(x0, y0, x1, y0 + 1, col);
		c.fill(x0, y1 - 1, x1, y1, col);
		c.fill(x0, y0 + 1, x0 + 1, y1 - 1, col);
		c.fill(x1 - 1, y0 + 1, x1, y1 - 1, col);
	}

	private static String trimToWidth(TextMetrics m, String s, int maxWidth) {
		if (m.width(s, false) <= maxWidth) {
			return s;
		}
		while (!s.isEmpty() && m.width(s + "...", false) > maxWidth) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "...";
	}

	// ------------------------------------------------------------------ text

	private static void drawText(PageCanvas c, Note note, TextLayout layout, TextMetrics m, int page, boolean editor) {
		NoteType t = note.type;
		int ts = t.textScale;
		int ink = note.defaultInk();
		int accent = t.accent(note.paper);
		boolean dark = t.isDarkSurface(note.paper);
		int muted = dark ? 0xFFA8A8B4 : 0xFF7A7A84;

		for (int li = 0; li < layout.lines.size(); li++) {
			TextLayout.Line line = layout.lines.get(li);
			if (line.page() != page) {
				continue;
			}
			Paragraph p = note.paragraphs.get(line.para());
			boolean firstOfPara = layout.firstLine[line.para()] == li;

			if (p.style == ParaStyle.PAGE_BREAK) {
				if (editor) {
					int y = line.slotTop() + line.slotHeight() / 2;
					for (int x = t.marginLeft; x < t.pageWidth - t.marginRight; x += 6) {
						c.fill(x, y, x + 3, y + 1, dark ? 0x90FFFFFF : 0x90707070);
					}
				}
				continue;
			}

			if (p.style == ParaStyle.QUOTE) {
				c.fill(line.x() - 6 * ts, line.slotTop() + 2 * ts, line.x() - 4 * ts, line.bottom() - ts, dark ? 0x80FFFFFF : 0x60404050);
			}

			if (firstOfPara) {
				int bulletColor = p.isEmpty() ? (p.style == ParaStyle.HEADING ? accent : ink) : resolveColor(p, p.formatAt(0), ink, accent, muted);
				drawListMarker(c, note, layout, m, line, p, bulletColor);
			}

			if (line.end() <= line.start()) {
				continue;
			}

			List<PageCanvas.Run> runs = new ArrayList<>();
			int x = line.x();
			for (Paragraph.Run r : p.runs(line.start(), line.end())) {
				TextFormat f = effective(p, r.format());
				int color = resolveColor(p, r.format(), ink, accent, muted);
				String s = p.text().substring(r.start(), r.end());
				int runWidth = m.width(p, r.start(), r.end()) * line.scale();
				if (f.highlight() != 0) {
					c.fill(x - ts, line.y() - ts, x + runWidth, line.y() + 8 * line.scale() + ts, f.highlight());
				}
				if (!c.detailedText()) {
					int barColor = (color & 0x00FFFFFF) | 0xA0000000;
					c.fill(x, line.y() + 2 * line.scale(), x + runWidth - (s.endsWith(" ") ? 4 * line.scale() : 0), line.y() + 6 * line.scale(), barColor);
				} else {
					runs.add(new PageCanvas.Run(s, f.bold(), f.italic(), f.underline(), f.strike(), color));
				}
				x += runWidth;
			}
			if (!runs.isEmpty()) {
				c.text(runs, line.x(), line.y(), line.scale());
			}
		}
	}

	private static void drawListMarker(PageCanvas c, Note note, TextLayout layout, TextMetrics m, TextLayout.Line line, Paragraph p, int color) {
		int ts = note.type.textScale;
		switch (p.style) {
			case BULLET -> {
				int size = 3 * ts;
				int bx = line.x() - 8 * ts;
				int by = line.y() + 2 * ts;
				switch (p.indent % 3) {
					case 0 -> c.fill(bx, by, bx + size, by + size, color);
					case 1 -> {
						c.fill(bx, by, bx + size, by + ts, color);
						c.fill(bx, by + size - ts, bx + size, by + size, color);
						c.fill(bx, by, bx + ts, by + size, color);
						c.fill(bx + size - ts, by, bx + size, by + size, color);
					}
					default -> c.fill(bx, by + ts, bx + size, by + 2 * ts, color);
				}
			}
			case NUMBERED -> {
				int n = layout.numbers[line.para()];
				String label = (p.indent % 2 == 1 ? letters(n) : String.valueOf(n)) + ".";
				int lw = m.width(label, false) * ts;
				if (c.detailedText()) {
					c.text(List.of(new PageCanvas.Run(label, false, false, false, false, color)), line.x() - 3 * ts - lw, line.y(), ts);
				} else {
					c.fill(line.x() - 3 * ts - lw, line.y() + 2 * ts, line.x() - 4 * ts, line.y() + 6 * ts, (color & 0xFFFFFF) | 0xA0000000);
				}
			}
			case CHECKLIST -> {
				if (p.checked) {
					c.sprite(Sprites.CHECKBOX_CHECKED, line.x() - 11 * ts, line.y() - ts, 9 * ts, 9 * ts);
				} else {
					c.sprite(Sprites.CHECKBOX, line.x() - 11 * ts, line.y(), 8 * ts, 8 * ts);
				}
			}
			default -> {
			}
		}
	}

	private static String letters(int n) {
		StringBuilder sb = new StringBuilder();
		n = Math.max(1, n);
		while (n > 0) {
			n--;
			sb.insert(0, (char) ('a' + n % 26));
			n /= 26;
		}
		return sb.toString();
	}

	/** Paragraph style adjustments applied on top of the stored character format. */
	public static TextFormat effective(Paragraph p, TextFormat f) {
		return switch (p.style) {
			case HEADING -> f.withBold(true);
			case QUOTE -> f.withItalic(true);
			case CHECKLIST -> p.checked ? f.withStrike(true) : f;
			default -> f;
		};
	}

	public static int resolveColor(Paragraph p, TextFormat f, int ink, int accent, int muted) {
		if (p.style == ParaStyle.CHECKLIST && p.checked) {
			return muted;
		}
		if (f.color() != 0) {
			return f.color();
		}
		return switch (p.style) {
			case HEADING, TITLE -> p.style == ParaStyle.HEADING ? accent : ink;
			case QUOTE -> muted;
			default -> ink;
		};
	}
}
