package com.vess7y.scribble.client.export;

import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.client.NotesStorage;
import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import com.vess7y.scribble.client.render.PageComposer;
import com.vess7y.scribble.client.render.RasterPageCanvas;
import com.vess7y.scribble.client.text.TextLayout;
import com.vess7y.scribble.client.text.TextMetrics;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Exports notes to plain text, Markdown, PNG images and PDF.
 */
public final class NoteExporter {
	/** Raster pixels per page unit for image exports. */
	private static final int RASTER_SCALE = 4;
	/** PDF points per page unit; makes paper pages roughly US Letter sized. */
	private static final float POINTS_PER_UNIT = 2.55F;

	public enum Format {
		TXT("txt", "file_txt"),
		MARKDOWN("md", "file_md"),
		PNG("png", "file_png"),
		PDF("pdf", "file_pdf");

		public final String extension;
		public final String icon;

		Format(String extension, String icon) {
			this.extension = extension;
			this.icon = icon;
		}

		public String translationKey() {
			return "scribble.export." + this.extension;
		}
	}

	private NoteExporter() {
	}

	/** Exports and returns the written file (the first page for multi-page PNG exports). */
	public static Path export(Note note, Format format) throws IOException {
		Path dir = NotesStorage.exportsDir();
		Files.createDirectories(dir);
		String base = fileBaseName(note);
		switch (format) {
			case TXT -> {
				Path file = dir.resolve(base + ".txt");
				Files.writeString(file, toPlainText(note), StandardCharsets.UTF_8);
				return file;
			}
			case MARKDOWN -> {
				Path file = dir.resolve(base + ".md");
				Files.writeString(file, toMarkdown(note), StandardCharsets.UTF_8);
				return file;
			}
			case PNG -> {
				List<RasterPageCanvas> pages = rasterize(note, 0);
				Path first = null;
				for (int i = 0; i < pages.size(); i++) {
					Path file = dir.resolve(pages.size() == 1 ? base + ".png" : base + "_p" + (i + 1) + ".png");
					try (NativeImage image = pages.get(i).toImage()) {
						image.writeToFile(file);
					}
					if (first == null) {
						first = file;
					}
				}
				return first;
			}
			case PDF -> {
				List<PdfWriter.Page> pdfPages = new ArrayList<>();
				for (RasterPageCanvas canvas : rasterize(note, 0xFFFFFFFF)) {
					pdfPages.add(new PdfWriter.Page(canvas.pixels(), canvas.width, canvas.height));
				}
				Path file = dir.resolve(base + ".pdf");
				PdfWriter.write(file, pdfPages, POINTS_PER_UNIT / RASTER_SCALE);
				return file;
			}
		}
		throw new IllegalArgumentException(format.name());
	}

	public static List<RasterPageCanvas> rasterize(Note note, int background) {
		NotesStorage.loadInk(note);
		TextMetrics metrics = TextMetrics.get();
		TextLayout layout = TextLayout.build(note, metrics);
		int pages = layout.pageCount(note);
		List<RasterPageCanvas> out = new ArrayList<>();
		for (int page = 0; page < pages; page++) {
			RasterPageCanvas canvas = new RasterPageCanvas(note.type, RASTER_SCALE, metrics, background);
			InkLayer ink = note.inkFor(page);
			PageComposer.draw(canvas, note, layout, metrics, page, pages, ink, false);
			out.add(canvas);
		}
		return out;
	}

	public static String fileBaseName(Note note) {
		String title = note.title.isBlank() ? "Untitled" : note.title;
		String safe = title.replaceAll("[^A-Za-z0-9 _-]", "").strip().replace(' ', '_');
		if (safe.isEmpty()) {
			safe = "note";
		}
		if (safe.length() > 48) {
			safe = safe.substring(0, 48);
		}
		return safe + "_" + new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
	}

	// ------------------------------------------------------------------ text formats

	public static String toPlainText(Note note) {
		StringBuilder sb = new StringBuilder();
		if (!note.title.isBlank()) {
			sb.append(note.title).append('\n').append("=".repeat(Math.min(60, note.title.length()))).append("\n\n");
		}
		int[] numbers = numbers(note);
		for (int i = 0; i < note.paragraphs.size(); i++) {
			Paragraph p = note.paragraphs.get(i);
			String indent = "  ".repeat(p.indent);
			switch (p.style) {
				case PAGE_BREAK -> sb.append("\n-------- page break --------\n");
				case BULLET -> sb.append(indent).append("• ").append(p.text());
				case NUMBERED -> sb.append(indent).append(numbers[i]).append(". ").append(p.text());
				case CHECKLIST -> sb.append(indent).append(p.checked ? "[x] " : "[ ] ").append(p.text());
				case QUOTE -> sb.append(indent).append("> ").append(p.text());
				case TITLE -> sb.append(p.text().toUpperCase(java.util.Locale.ROOT));
				default -> sb.append(indent).append(p.text());
			}
			sb.append('\n');
		}
		return sb.toString();
	}

	public static String toMarkdown(Note note) {
		StringBuilder sb = new StringBuilder();
		if (!note.title.isBlank()) {
			sb.append("# ").append(escape(note.title)).append("\n\n");
		}
		int[] numbers = numbers(note);
		ParaStyle prev = null;
		for (int i = 0; i < note.paragraphs.size(); i++) {
			Paragraph p = note.paragraphs.get(i);
			String indent = "    ".repeat(p.indent);
			if (prev != null && prev.isList() != p.style.isList()) {
				sb.append('\n');
			}
			String body = inlineMarkdown(p);
			switch (p.style) {
				case PAGE_BREAK -> sb.append("\n---\n");
				case TITLE -> sb.append("## ").append(body).append('\n');
				case HEADING -> sb.append("### ").append(body).append('\n');
				case BULLET -> sb.append(indent).append("- ").append(body);
				case NUMBERED -> sb.append(indent).append(numbers[i]).append(". ").append(body);
				case CHECKLIST -> sb.append(indent).append(p.checked ? "- [x] " : "- [ ] ").append(body);
				case QUOTE -> sb.append("> ").append(body).append('\n');
				default -> sb.append(body).append('\n');
			}
			sb.append('\n');
			prev = p.style;
		}
		return sb.toString().replaceAll("\n{3,}", "\n\n");
	}

	private static String inlineMarkdown(Paragraph p) {
		if (p.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (Paragraph.Run run : p.runs(0, p.length())) {
			String text = escape(p.text().substring(run.start(), run.end()));
			TextFormat f = run.format();
			String lead = text.substring(0, text.length() - text.stripLeading().length());
			String trail = text.substring(text.stripTrailing().length());
			String core = text.strip();
			if (core.isEmpty()) {
				sb.append(text);
				continue;
			}
			if (f.strike()) {
				core = "~~" + core + "~~";
			}
			if (f.italic()) {
				core = "*" + core + "*";
			}
			if (f.bold()) {
				core = "**" + core + "**";
			}
			if (f.underline()) {
				core = "<u>" + core + "</u>";
			}
			if (f.highlight() != 0) {
				core = "<mark>" + core + "</mark>";
			}
			sb.append(lead).append(core).append(trail);
		}
		return sb.toString();
	}

	private static String escape(String s) {
		return s.replaceAll("([\\\\`*_{}\\[\\]#|<>~])", "\\\\$1");
	}

	private static int[] numbers(Note note) {
		return TextLayout.build(note, TextMetrics.get()).numbers;
	}
}
