package com.vess7y.scribble.client.ui;

import org.lwjgl.sdl.SDLMouse;

/**
 * Hides the operating system's mouse cursor while one of our big toon tools follows the mouse instead. Vanilla never
 * hides the cursor itself (it only uses relative mouse mode while playing), so toggling it here is safe as long as
 * every screen that hides it shows it again when it goes away.
 */
public final class OsCursor {
	private static boolean hidden;

	private OsCursor() {
	}

	public static void setHidden(boolean hide) {
		if (hide == hidden) {
			return;
		}
		hidden = hide;
		if (hide) {
			SDLMouse.SDL_HideCursor();
		} else {
			SDLMouse.SDL_ShowCursor();
		}
	}

	public static void show() {
		setHidden(false);
	}
}
