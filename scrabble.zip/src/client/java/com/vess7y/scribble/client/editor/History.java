package com.vess7y.scribble.client.editor;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

/**
 * Undo / redo stacks of state snapshots. Consecutive edits with the same coalesce key (e.g. typing) within a
 * short time share a single undo step.
 */
public final class History {
	private static final int LIMIT = 60;
	private static final long COALESCE_MS = 1500;

	public interface Snapshot {
		/** A snapshot of the same kind describing the current state (used to redo / undo the restore). */
		Snapshot captureCurrent();

		void restore();
	}

	private final Deque<Snapshot> undo = new ArrayDeque<>();
	private final Deque<Snapshot> redo = new ArrayDeque<>();
	private @Nullable String lastKey;
	private long lastTime;

	public void push(Snapshot snapshot, @Nullable String coalesceKey) {
		long now = Util.getMillis();
		if (coalesceKey != null && coalesceKey.equals(this.lastKey) && now - this.lastTime < COALESCE_MS) {
			this.lastTime = now;
			return;
		}
		this.lastKey = coalesceKey;
		this.lastTime = now;
		this.undo.push(snapshot);
		while (this.undo.size() > LIMIT) {
			this.undo.removeLast();
		}
		this.redo.clear();
	}

	public void breakCoalescing() {
		this.lastKey = null;
	}

	public boolean canUndo() {
		return !this.undo.isEmpty();
	}

	public boolean canRedo() {
		return !this.redo.isEmpty();
	}

	public boolean undo() {
		if (this.undo.isEmpty()) {
			return false;
		}
		Snapshot s = this.undo.pop();
		this.redo.push(s.captureCurrent());
		s.restore();
		this.lastKey = null;
		return true;
	}

	public boolean redo() {
		if (this.redo.isEmpty()) {
			return false;
		}
		Snapshot s = this.redo.pop();
		this.undo.push(s.captureCurrent());
		s.restore();
		this.lastKey = null;
		return true;
	}
}
