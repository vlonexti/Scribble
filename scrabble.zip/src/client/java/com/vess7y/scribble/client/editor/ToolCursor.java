package com.vess7y.scribble.client.editor;

import com.vess7y.scribble.client.ui.Anim;
import com.vess7y.scribble.client.ui.Ui;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import com.vess7y.scribble.client.ScribbleSounds;
import net.minecraft.util.Util;

/**
 * The big toon tool that follows the mouse while drawing: it leans with the motion, swings on a spring, scrubs when
 * erasing and sheds crumbs or chalk dust, with soft scribble sounds.
 */
public final class ToolCursor {
	public enum Effect {
		/** Ballpoint pen. */
		PEN,
		/** Pencil and crayon. */
		PENCIL,
		QUILL,
		HIGHLIGHTER,
		/** Pens and pencils: scribble sound only. */
		SCRIBBLE,
		/** Felt marker squeak. */
		MARKER,
		/** Chalk: dust falls from the tip. */
		CHALK,
		/** Rubber eraser crumbs. */
		CRUMBS,
		/** Chalk eraser: puffs of dust. */
		CHALK_ERASER,
		/** Whiteboard eraser: faint flecks. */
		DRY_ERASER,
		NONE
	}

	private record Particle(float[] state, int color, float life, boolean puff) {
		// state: x, y, vx, vy, age, size
	}

	private final List<Particle> particles = new ArrayList<>();
	private final Random random = new Random();
	private float angle;
	private float angVel;
	private double lastX = Double.NaN;
	private double lastY;
	private float velX;
	private float velY;
	private float press;
	private long lastSound;
	private double soundDist;

	/**
	 * @param anchorX icon pixel (0..16) that sits on the mouse, usually the tool's tip
	 * @param active  whether the tool is currently touching the page
	 */
	public void render(GuiGraphicsExtractor g, double mx, double my, String icon, int anchorX, int anchorY,
					   boolean active, Effect effect, int color, boolean visible) {
		float dt = Anim.dt();
		if (Double.isNaN(this.lastX)) {
			this.lastX = mx;
			this.lastY = my;
		}
		double dx = mx - this.lastX;
		double dy = my - this.lastY;
		this.lastX = mx;
		this.lastY = my;
		float k = 1 - (float) Math.pow(0.001, dt);
		this.velX += ((float) (dx / dt) - this.velX) * k;
		this.velY += ((float) (dy / dt) - this.velY) * k;
		float speed = (float) Math.sqrt(this.velX * this.velX + this.velY * this.velY);

		boolean eraser = effect == Effect.CRUMBS || effect == Effect.CHALK_ERASER || effect == Effect.DRY_ERASER;
		float target = Math.max(-0.6F, Math.min(0.6F, this.velX * 0.0022F));
		if (active && eraser && speed > 15) {
			target += (float) Math.sin(Anim.time() * 38) * 0.14F;
		}
		this.angVel += ((target - this.angle) * 160 - this.angVel * 14) * dt;
		this.angle += this.angVel * dt;
		this.press += ((active ? 1 : 0) - this.press) * Math.min(1, dt * 18);

		if (active) {
			double dist = Math.sqrt(dx * dx + dy * dy);
			this.spawn(mx, my, dist, effect, color);
			this.soundDist += dist;
			long now = Util.getMillis();
			if (this.soundDist > 8 && now - this.lastSound > 170) {
				this.sound(effect);
				this.lastSound = now;
				this.soundDist = 0;
			}
		}

		this.renderParticles(g, dt);
		if (!visible) {
			return;
		}
		float scale = 2.0F - this.press * 0.18F;
		g.pose().pushMatrix();
		g.pose().translate((float) mx, (float) my + this.press * 1.5F);
		g.pose().rotate(this.angle);
		g.pose().scale(scale, scale);
		// soft shadow of the tool on the page
		g.pose().pushMatrix();
		g.pose().translate(1.5F + (1 - this.press) * 2, 2.0F + (1 - this.press) * 2);
		Ui.sprite(g, com.vess7y.scribble.client.render.Sprites.icon(icon), -anchorX, -anchorY, 16, 16, 0x40000000);
		g.pose().popMatrix();
		Ui.icon(g, icon, -anchorX, -anchorY);
		g.pose().popMatrix();
	}

	private void spawn(double mx, double my, double dist, Effect effect, int color) {
		int n = switch (effect) {
			case CRUMBS -> (int) Math.min(4, dist / 3);
			case CHALK_ERASER -> (int) Math.min(3, dist / 4);
			case DRY_ERASER -> this.random.nextFloat() < dist / 20 ? 1 : 0;
			case CHALK -> this.random.nextFloat() < dist / 6 ? 1 : 0;
			default -> 0;
		};
		for (int i = 0; i < n; i++) {
			float x = (float) mx + (this.random.nextFloat() - 0.5F) * 8;
			float y = (float) my + (this.random.nextFloat() - 0.5F) * 4;
			switch (effect) {
				case CRUMBS -> {
					int c = this.random.nextFloat() < 0.7F ? 0xFFF4A0B4 : 0xFFB8B0B4;
					this.particles.add(new Particle(new float[]{x, y, (this.random.nextFloat() - 0.5F) * 90 - this.velX * 0.15F,
							-40 - this.random.nextFloat() * 60, 0, this.random.nextFloat() < 0.3F ? 2 : 1}, c, 0.7F + this.random.nextFloat() * 0.4F, false));
				}
				case CHALK_ERASER -> this.particles.add(new Particle(new float[]{x, y, (this.random.nextFloat() - 0.5F) * 30,
						-10 - this.random.nextFloat() * 20, 0, 2}, 0xFFF0F0E8, 1.1F + this.random.nextFloat() * 0.5F, true));
				case DRY_ERASER -> this.particles.add(new Particle(new float[]{x, y, (this.random.nextFloat() - 0.5F) * 40,
						-20, 0, 1}, 0xFF8A8F98, 0.5F, false));
				case CHALK -> this.particles.add(new Particle(new float[]{x, y, (this.random.nextFloat() - 0.5F) * 20,
						5, 0, 1}, color | 0xFF000000, 0.8F, false));
				default -> {
				}
			}
		}
		while (this.particles.size() > 220) {
			this.particles.removeFirst();
		}
	}

	private void renderParticles(GuiGraphicsExtractor g, float dt) {
		Iterator<Particle> it = this.particles.iterator();
		while (it.hasNext()) {
			Particle p = it.next();
			float[] s = p.state;
			s[4] += dt;
			if (s[4] > p.life) {
				it.remove();
				continue;
			}
			if (p.puff) {
				s[2] *= 1 - dt * 2;
				s[3] *= 1 - dt * 2;
				s[5] += dt * 4;
			} else {
				s[3] += 320 * dt;
			}
			s[0] += s[2] * dt;
			s[1] += s[3] * dt;
			float fade = 1 - s[4] / p.life;
			int a = (int) (((p.color >>> 24) * (p.puff ? 0.45F : 1)) * fade);
			int size = Math.max(1, Math.round(s[5]));
			int x = Math.round(s[0]);
			int y = Math.round(s[1]);
			g.fill(x, y, x + size, y + size, (a << 24) | (p.color & 0xFFFFFF));
		}
	}

	private void sound(Effect effect) {
		switch (effect) {
			case PEN, SCRIBBLE -> ScribbleSounds.playVaried(ScribbleSounds.PEN, 1.0F, 0.35F);
			case PENCIL -> ScribbleSounds.playVaried(ScribbleSounds.PENCIL, 1.0F, 0.4F);
			case QUILL -> ScribbleSounds.playVaried(ScribbleSounds.QUILL, 1.0F, 0.4F);
			case HIGHLIGHTER -> ScribbleSounds.playVaried(ScribbleSounds.HIGHLIGHTER, 1.0F, 0.3F);
			case MARKER -> ScribbleSounds.playVaried(ScribbleSounds.MARKER, 1.0F, 0.3F);
			case CHALK -> ScribbleSounds.playVaried(ScribbleSounds.CHALK, 1.0F, 0.45F);
			case CRUMBS -> ScribbleSounds.playVaried(ScribbleSounds.ERASER_RUBBER, 1.0F, 0.45F);
			case CHALK_ERASER -> ScribbleSounds.playVaried(ScribbleSounds.ERASER_CHALK, 1.0F, 0.5F);
			case DRY_ERASER -> ScribbleSounds.playVaried(ScribbleSounds.ERASER_DRY, 1.0F, 0.45F);
			default -> {
			}
		}
	}

	public void reset() {
		this.lastX = Double.NaN;
	}
}
