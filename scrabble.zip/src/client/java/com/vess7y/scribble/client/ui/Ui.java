package com.vess7y.scribble.client.ui;

import com.mojang.blaze3d.platform.cursor.CursorTypes;
import com.vess7y.scribble.client.ScribbleSounds;
import com.vess7y.scribble.client.render.Sprites;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import org.jspecify.annotations.Nullable;

/**
 * Drawing helpers for Scribble's cozy, toon-styled UI: cream "toy" buttons with chunky brown outlines, warm wood,
 * soft shadows and springy hover / press animations.
 */
public final class Ui {
	/** Outline brown used by every sprite. */
	public static final int INK = 0xFF3B2A1E;
	/** Text on cream panels. */
	public static final int TEXT = 0xFF4A3426;
	public static final int TEXT_DIM = 0xFF9A7F63;
	/** Text on wood. */
	public static final int TEXT_LIGHT = 0xFFFFF4DC;
	public static final int TEXT_LIGHT_DIM = 0xFFE0C49C;
	public static final int ACCENT = 0xFFE07A2A;
	public static final int ACCENT_SOFT = 0xFFFFB347;
	public static final int CREAM = 0xFFFFF3D6;
	public static final int GOOD = 0xFF4E9A3A;
	public static final int BAD = 0xFFD2483A;
	public static final int SEPARATOR = 0x403B2A1E;

	private Ui() {
	}

	public static Font font() {
		return Minecraft.getInstance().font;
	}

	public static boolean hovered(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && my >= y && mx < x + w && my < y + h;
	}

	public static void sprite(GuiGraphicsExtractor g, Identifier sprite, int x, int y, int w, int h) {
		g.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, x, y, w, h);
	}

	public static void sprite(GuiGraphicsExtractor g, Identifier sprite, int x, int y, int w, int h, int color) {
		g.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, x, y, w, h, color);
	}

	public static void icon(GuiGraphicsExtractor g, String name, int x, int y) {
		sprite(g, Sprites.icon(name), x, y, 16, 16);
	}

	public static void icon(GuiGraphicsExtractor g, String name, int x, int y, float alpha) {
		g.blitSprite(RenderPipelines.GUI_TEXTURED, Sprites.icon(name), x, y, 16, 16, alpha);
	}

	/** Soft drop shadow under a rectangle. */
	public static void shadow(GuiGraphicsExtractor g, int x, int y, int w, int h, float strength) {
		int a = Math.max(0, Math.min(255, (int) (255 * strength)));
		sprite(g, Sprites.SHADOW, x - 9, y - 6, w + 18, h + 18, (a << 24) | 0xFFFFFF);
	}

	/** A floating cream panel with a soft shadow. */
	public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h) {
		shadow(g, x, y, w, h, 0.8F);
		sprite(g, Sprites.PANEL, x, y, w, h);
	}

	/** Dark text on cream, no shadow (toon style). */
	public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
		g.text(font(), s, x, y, color, false);
	}

	public static void text(GuiGraphicsExtractor g, Component c, int x, int y, int color) {
		g.text(font(), c, x, y, color, false);
	}

	/** Light text with a soft brown shadow, for wood and the desk. */
	public static void textLight(GuiGraphicsExtractor g, Component c, int x, int y, int color) {
		g.text(font(), c, x + 1, y + 1, 0xA0281A10, false);
		g.text(font(), c, x, y, color, false);
	}

	public static void textLight(GuiGraphicsExtractor g, String s, int x, int y, int color) {
		textLight(g, Component.literal(s), x, y, color);
	}

	public static void centered(GuiGraphicsExtractor g, Component c, int cx, int y, int color) {
		g.text(font(), c, cx - font().width(c) / 2, y, color, false);
	}

	public static String ellipsize(String s, int maxWidth) {
		Font f = font();
		if (f.width(s) <= maxWidth) {
			return s;
		}
		String dots = "...";
		return f.plainSubstrByWidth(s, Math.max(0, maxWidth - f.width(dots))) + dots;
	}

	/** Soft dashed separator line. */
	public static void groove(GuiGraphicsExtractor g, int x0, int x1, int y) {
		for (int x = x0; x < x1; x += 4) {
			g.fill(x, y, Math.min(x1, x + 2), y + 1, SEPARATOR);
		}
	}

	public static void vgroove(GuiGraphicsExtractor g, int x, int y0, int y1) {
		for (int y = y0; y < y1; y += 4) {
			g.fill(x, y, x + 1, Math.min(y1, y + 2), SEPARATOR);
		}
	}

	// ------------------------------------------------------------------ sounds

	public static void sound(SoundEvent event, float pitch, float volume) {
		Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(event, pitch, volume));
	}

	public static void click() {
		ScribbleSounds.playVaried(ScribbleSounds.CLICK, 1.0F, 0.55F);
	}

	public static void pageTurn() {
		ScribbleSounds.playVaried(ScribbleSounds.PAGE_FLIP, 1.0F, 0.8F);
	}

	public static void pop() {
		ScribbleSounds.playVaried(ScribbleSounds.POP, 1.0F, 0.5F);
	}

	private static final java.util.Set<Object> HOVERED = new java.util.HashSet<>();
	private static final java.util.Set<Object> HOVERED_NOW = new java.util.HashSet<>();

	/** Plays a soft tick the moment the mouse enters something interactive. */
	public static void hoverSound(Object key, boolean hover) {
		if (hover) {
			HOVERED_NOW.add(key);
			if (!HOVERED.contains(key)) {
				ScribbleSounds.playVaried(ScribbleSounds.HOVER, 1.0F, 0.18F);
			}
		}
	}

	/** Call at the end of each frame so hover sounds only fire on enter. */
	public static void endFrame() {
		HOVERED.clear();
		HOVERED.addAll(HOVERED_NOW);
		HOVERED_NOW.clear();
	}

	// ------------------------------------------------------------------ animated widgets

	/** Scales everything drawn until {@link #popScale} around a center point. */
	public static void pushScale(GuiGraphicsExtractor g, float cx, float cy, float s) {
		g.pose().pushMatrix();
		g.pose().translate(cx, cy);
		g.pose().scale(s, s);
		g.pose().translate(-cx, -cy);
	}

	public static void popScale(GuiGraphicsExtractor g) {
		g.pose().popMatrix();
	}

	private static float hoverScale(Object key, boolean hover, boolean selected) {
		return Anim.bouncy(key, hover ? 1.12F : selected ? 1.04F : 1.0F);
	}

	private static Runnable pressing(Object key, Runnable action) {
		return () -> {
			Anim.kick(key, -6.0F);
			click();
			action.run();
		};
	}

	/**
	 * A toy icon button. Flat buttons only show their body when hovered or selected (toolbar style).
	 */
	public static Hotspots.Hotspot iconButton(GuiGraphicsExtractor g, Hotspots hs, double mx, double my,
											  int x, int y, int size, String icon, @Nullable Component tooltip,
											  boolean selected, boolean enabled, boolean flat, @Nullable Runnable action) {
		boolean hover = enabled && hovered(mx, my, x, y, size, size);
		Object key = "ib" + icon + x + ',' + y;
		hoverSound(key, hover && action != null);
		float s = enabled ? hoverScale(key, hover, selected) : 1.0F;
		pushScale(g, x + size / 2.0F, y + size / 2.0F, s);
		Identifier bg;
		if (!enabled) {
			bg = flat ? null : Sprites.BUTTON_DISABLED;
		} else if (selected) {
			bg = Sprites.BUTTON_SELECTED;
		} else if (hover) {
			bg = Sprites.BUTTON_HOVER;
		} else {
			bg = flat ? null : Sprites.BUTTON;
		}
		if (bg != null) {
			sprite(g, bg, x, y, size, size);
		}
		int off = (size - 16) / 2;
		int lift = bg != null && !selected ? -1 : 0;
		animatedIcon(g, icon, x + off, y + off + lift, enabled ? 1.0F : 0.35F, enabled && hover, key);
		popScale(g);
		Hotspots.Hotspot h = hs.add(x, y, size, size).tooltip(tooltip);
		if (enabled && action != null) {
			h.click(pressing(key, action));
		} else {
			h.noPointer();
		}
		return h;
	}

	/**
	 * Draws an icon with a small personality animation while hovered: hands wave, pens scribble, erasers rub,
	 * the trash lid pops open, the bell rings, and so on.
	 */
	public static void animatedIcon(GuiGraphicsExtractor g, String icon, int x, int y, float alpha, boolean hover, Object key) {
		float h = Anim.smooth(key + "#h", hover ? 1 : 0);
		float t = Anim.time();
		String name = icon;
		float rot = 0;
		float dx = 0;
		float dy = 0;
		if (h > 0.01F) {
			if (icon.equals("tool_pan")) {
				rot = (float) Math.sin(t * 10) * 0.28F * h;
			} else if (icon.startsWith("trash")) {
				if (hover) {
					name = "trash_open";
				}
				dy = -(float) Math.abs(Math.sin(t * 9)) * 0.8F * h;
			} else if (icon.equals("bell")) {
				rot = (float) Math.sin(t * 20) * 0.35F * h;
			} else if (icon.startsWith("star")) {
				rot = (float) Math.sin(t * 7) * 0.25F * h;
			} else if (icon.startsWith("eraser")) {
				dx = (float) Math.sin(t * 18) * 1.6F * h;
			} else if (icon.startsWith("tool_p") || icon.equals("tool_marker") || icon.equals("tool_chalk") || icon.equals("tool_quill")
					|| icon.equals("tool_crayon") || icon.equals("tool_highlighter") || icon.equals("rename") || icon.equals("highlight")) {
				rot = (float) Math.sin(t * 15) * 0.18F * h;
				dy = (float) Math.sin(t * 30) * 0.7F * h;
			} else if (icon.equals("export")) {
				dy = -(float) Math.abs(Math.sin(t * 7)) * 2.0F * h;
			} else if (icon.equals("undo")) {
				rot = -0.45F * h;
			} else if (icon.equals("redo")) {
				rot = 0.45F * h;
			} else if (icon.equals("page_next")) {
				dx = (float) Math.abs(Math.sin(t * 8)) * 1.5F * h;
			} else if (icon.equals("page_prev") || icon.equals("back")) {
				dx = -(float) Math.abs(Math.sin(t * 8)) * 1.5F * h;
			} else if (icon.equals("tool_fill")) {
				rot = -0.35F * h;
			} else if (icon.equals("tool_stamp")) {
				dy = (float) Math.abs(Math.sin(t * 9)) * 2.0F * h;
			} else if (icon.equals("tool_eyedropper")) {
				dy = (float) Math.sin(t * 9) * 1.0F * h;
			} else if (icon.startsWith("zoom") || icon.equals("search")) {
				rot = (float) Math.sin(t * 8) * 0.2F * h;
			} else if (icon.startsWith("page_add") || icon.equals("plus")) {
				dy = -(float) Math.abs(Math.sin(t * 8)) * 1.2F * h;
			} else if (icon.equals("folder")) {
				dy = -(float) Math.abs(Math.sin(t * 6)) * 1.0F * h;
			} else if (icon.equals("close")) {
				rot = h * 0.6F;
			}
		}
		if (rot == 0 && dx == 0 && dy == 0) {
			icon(g, name, x, y, alpha);
			return;
		}
		g.pose().pushMatrix();
		g.pose().translate(x + 8 + dx, y + 8 + dy);
		g.pose().rotate(rot);
		icon(g, name, -8, -8, alpha);
		g.pose().popMatrix();
	}

	/** A toy button with a text label. */
	public static Hotspots.Hotspot textButton(GuiGraphicsExtractor g, Hotspots hs, double mx, double my,
											  int x, int y, int w, int h, Component label, boolean enabled,
											  @Nullable Runnable action) {
		return textButton(g, hs, mx, my, x, y, w, h, label, enabled, false, action);
	}

	public static Hotspots.Hotspot textButton(GuiGraphicsExtractor g, Hotspots hs, double mx, double my,
											  int x, int y, int w, int h, Component label, boolean enabled,
											  boolean primary, @Nullable Runnable action) {
		boolean hover = enabled && hovered(mx, my, x, y, w, h);
		Object key = "tb" + label.getString() + x + ',' + y;
		hoverSound(key, hover);
		float s = enabled ? Anim.bouncy(key, hover ? 1.06F : 1.0F) : 1.0F;
		pushScale(g, x + w / 2.0F, y + h / 2.0F, s);
		Identifier bg = !enabled ? Sprites.BUTTON_DISABLED : primary ? Sprites.BUTTON_SELECTED : hover ? Sprites.BUTTON_HOVER : Sprites.BUTTON;
		sprite(g, bg, x, y, w, h);
		String str = ellipsize(label.getString(), w - 8);
		centered(g, Component.literal(str).withStyle(label.getStyle()), x + w / 2, y + (h - 8) / 2 - 1, enabled ? TEXT : 0xFFA48C70);
		popScale(g);
		Hotspots.Hotspot spot = hs.add(x, y, w, h);
		if (enabled && action != null) {
			spot.click(pressing(key, action));
		}
		return spot;
	}

	/** A pill shaped filter / toggle chip. Returns its width. */
	public static int chip(GuiGraphicsExtractor g, Hotspots hs, double mx, double my, int x, int y,
						   Component label, @Nullable String icon, boolean selected, Runnable action) {
		int w = font().width(label) + 12 + (icon != null ? 14 : 0);
		int h = 15;
		boolean hover = hovered(mx, my, x, y, w, h);
		Object key = "chip" + label.getString() + x;
		hoverSound(key, hover);
		float s = Anim.bouncy(key, hover ? 1.07F : 1.0F);
		pushScale(g, x + w / 2.0F, y + h / 2.0F, s);
		sprite(g, selected ? Sprites.CHIP_SELECTED : hover ? Sprites.CHIP_HOVER : Sprites.CHIP, x, y, w, h);
		int tx = x + 6;
		if (icon != null) {
			g.pose().pushMatrix();
			g.pose().translate(x + 3, y + 1);
			g.pose().scale(0.75F, 0.75F);
			icon(g, icon, 0, 0);
			g.pose().popMatrix();
			tx += 13;
		}
		text(g, label, tx, y + 3, selected ? 0xFF4A2A08 : TEXT);
		popScale(g);
		hs.add(x, y, w, h).click(pressing(key, action));
		return w;
	}

	/** A color swatch. {@code color == 0} draws a "none" swatch with a red slash. */
	public static void swatch(GuiGraphicsExtractor g, Hotspots hs, double mx, double my, int x, int y, int size,
							  int color, boolean selected, @Nullable Component tooltip, Runnable action) {
		boolean hover = hovered(mx, my, x, y, size, size);
		Object key = "sw" + x + ',' + y;
		float s = Anim.bouncy(key, hover ? 1.3F : selected ? 1.12F : 1.0F);
		pushScale(g, x + size / 2.0F, y + size / 2.0F, s);
		if (color == 0) {
			g.fill(x + 1, y + 1, x + size - 1, y + size - 1, 0xFFFFFFFF);
			for (int i = 1; i < size - 1; i++) {
				g.fill(x + size - 1 - i, y + i, x + size - i, y + i + 1, BAD);
			}
		} else {
			g.fill(x + 1, y + 1, x + size - 1, y + size - 1, color | 0xFF000000);
		}
		sprite(g, selected ? Sprites.SWATCH_SELECTED : Sprites.SWATCH, x, y, size, size);
		popScale(g);
		hs.add(x, y, size, size).tooltip(tooltip).click(() -> {
			Anim.kick(key, -5);
			click();
			action.run();
		});
	}

	public static void requestPointer(GuiGraphicsExtractor g) {
		g.requestCursor(CursorTypes.POINTING_HAND);
	}

	/** Vertical scrollbar; dragging is wired through the returned hotspot. */
	public static Hotspots.Hotspot scrollbar(GuiGraphicsExtractor g, Hotspots hs, int x, int y, int h,
											 double scroll, double maxScroll, Hotspots.DragHandler drag) {
		if (maxScroll <= 0) {
			return hs.add(x, y, 6, h).noPointer();
		}
		sprite(g, Sprites.SCROLL_TRACK, x, y, 6, h);
		int thumbH = Math.max(16, (int) (h * h / (h + maxScroll)));
		int thumbY = y + (int) ((h - thumbH) * (scroll / maxScroll));
		sprite(g, Sprites.SCROLL_THUMB, x, thumbY, 6, thumbH);
		return hs.add(x - 2, y, 10, h).drag(drag);
	}

	public static String relativeTime(long millis) {
		long d = System.currentTimeMillis() - millis;
		long s = d / 1000;
		if (s < 45) {
			return Component.translatable("scribble.time.now").getString();
		}
		long m = s / 60;
		if (m < 60) {
			return Component.translatable("scribble.time.minutes", Math.max(1, m)).getString();
		}
		long h = m / 60;
		if (h < 24) {
			return Component.translatable("scribble.time.hours", h).getString();
		}
		long days = h / 24;
		if (days < 30) {
			return Component.translatable("scribble.time.days", days).getString();
		}
		return new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date(millis));
	}

	/** Darkens or lightens an ARGB color. */
	public static int shade(int argb, float f) {
		int r = (int) Math.max(0, Math.min(255, ((argb >> 16) & 0xFF) * f));
		int gr = (int) Math.max(0, Math.min(255, ((argb >> 8) & 0xFF) * f));
		int b = (int) Math.max(0, Math.min(255, (argb & 0xFF) * f));
		return (argb & 0xFF000000) | (r << 16) | (gr << 8) | b;
	}

	/** Warm vignette and soft top light over the desk, for that cozy cabin feel. */
	public static void cozyLight(GuiGraphicsExtractor g, int w, int h) {
		g.fillGradient(0, 0, w, h / 3, 0x26FFD9A0, 0x00FFD9A0);
		g.fillGradient(0, h * 2 / 3, w, h, 0x00000000, 0x50140A04);
		int band = Math.max(8, w / 10);
		for (int i = 0; i < band; i += 2) {
			int a = (int) (70 * Math.pow(1 - i / (float) band, 2));
			g.fill(i, 0, i + 2, h, a << 24 | 0x140A04);
			g.fill(w - i - 2, 0, w - i, h, a << 24 | 0x140A04);
		}
	}
}
