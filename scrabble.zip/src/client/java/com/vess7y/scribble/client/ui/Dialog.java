package com.vess7y.scribble.client.ui;

import com.vess7y.scribble.client.render.Sprites;
import java.util.function.Consumer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

/**
 * Modal dialogs: cozy cream cards that bounce in over a warm dimmed backdrop.
 */
public abstract class Dialog {
	protected final Component title;
	protected final String icon;
	protected int x, y, w, h;
	private Runnable closer = () -> {
	};
	private final Object animKey = new Object();
	private boolean opened;

	protected Dialog(Component title, String icon, int w, int h) {
		this.title = title;
		this.icon = icon;
		this.w = w;
		this.h = h;
	}

	public void setCloser(Runnable closer) {
		this.closer = closer;
	}

	public void close() {
		this.closer.run();
	}

	public void render(GuiGraphicsExtractor g, Hotspots hs, int screenW, int screenH, double mx, double my) {
		if (!this.opened) {
			this.opened = true;
			Anim.set(this.animKey, 0.6F);
		}
		float s = Anim.spring(this.animKey, 1.0F, 220, 0.5F);
		g.fill(0, 0, screenW, screenH, (int) (Math.min(1, s) * 0x90) << 24 | 0x1A0E06);
		hs.add(0, 0, screenW, screenH).noPointer();
		this.x = (screenW - this.w) / 2;
		this.y = (screenH - this.h) / 2;
		Ui.pushScale(g, screenW / 2.0F, screenH / 2.0F, s);
		Ui.panel(g, this.x, this.y, this.w, this.h);
		Ui.animatedIcon(g, this.icon, this.x + 6, this.y + 4, 1.0F, true, this.animKey);
		Ui.text(g, this.title, this.x + 26, this.y + 9, Ui.TEXT);
		this.renderContent(g, hs, mx, my);
		Ui.popScale(g);
	}

	protected abstract void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my);

	public boolean keyPressed(KeyEvent event) {
		if (event.isEscape()) {
			this.close();
			return true;
		}
		return false;
	}

	public boolean charTyped(CharacterEvent event) {
		return false;
	}

	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		return false;
	}

	// ------------------------------------------------------------------ confirm

	public static final class Confirm extends Dialog {
		private final Component message;
		private final Component confirm;
		private final Runnable onConfirm;

		public Confirm(Component title, Component message, Component confirm, Runnable onConfirm) {
			this(title, "warn", message, confirm, onConfirm);
		}

		public Confirm(Component title, String icon, Component message, Component confirm, Runnable onConfirm) {
			super(title, icon, 210, 0);
			this.message = message;
			this.confirm = confirm;
			this.onConfirm = onConfirm;
			int lines = Ui.font().split(message, this.w - 20).size();
			this.h = 30 + lines * 10 + 34;
		}

		@Override
		protected void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my) {
			int cy = this.y + 26;
			for (FormattedCharSequence line : Ui.font().split(this.message, this.w - 20)) {
				g.text(Ui.font(), line, this.x + 10, cy, Ui.TEXT_DIM, false);
				cy += 10;
			}
			int by = this.y + this.h - 30;
			int bw = (this.w - 26) / 2;
			Ui.textButton(g, hs, mx, my, this.x + 9, by, bw, 20, CommonComponents.GUI_CANCEL, true, this::close);
			Ui.textButton(g, hs, mx, my, this.x + 17 + bw, by, bw, 20, this.confirm, true, true, () -> {
				this.close();
				this.onConfirm.run();
			});
		}

		@Override
		public boolean keyPressed(KeyEvent event) {
			if (event.isConfirmation()) {
				this.close();
				this.onConfirm.run();
				return true;
			}
			return super.keyPressed(event);
		}
	}

	// ------------------------------------------------------------------ text input

	public static final class Input extends Dialog {
		private final EditBox box;
		private final Consumer<String> onDone;

		public Input(Component title, String initial, int maxLength, Consumer<String> onDone) {
			super(title, "rename", 220, 84);
			this.onDone = onDone;
			this.box = new EditBox(Ui.font(), 0, 0, 200, 12, title);
			this.box.setBordered(false);
			this.box.setTextColor(Ui.TEXT);
			this.box.setMaxLength(maxLength);
			this.box.setValue(initial);
			this.box.setFocused(true);
			this.box.moveCursorToEnd(false);
			this.box.setHighlightPos(0);
		}

		@Override
		protected void renderContent(GuiGraphicsExtractor g, Hotspots hs, double mx, double my) {
			int fx = this.x + 9;
			int fy = this.y + 26;
			int fw = this.w - 18;
			Ui.sprite(g, Sprites.FIELD_FOCUSED, fx, fy, fw, 18);
			this.box.setX(fx + 5);
			this.box.setY(fy + 5);
			this.box.setWidth(fw - 10);
			this.box.extractRenderState(g, (int) mx, (int) my, 0);
			int by = this.y + this.h - 30;
			int bw = (this.w - 26) / 2;
			Ui.textButton(g, hs, mx, my, this.x + 9, by, bw, 20, CommonComponents.GUI_CANCEL, true, this::close);
			Ui.textButton(g, hs, mx, my, this.x + 17 + bw, by, bw, 20, CommonComponents.GUI_DONE, true, true, this::finish);
		}

		private void finish() {
			this.close();
			this.onDone.accept(this.box.getValue().strip());
		}

		@Override
		public boolean keyPressed(KeyEvent event) {
			if (event.isConfirmation()) {
				this.finish();
				return true;
			}
			if (this.box.keyPressed(event)) {
				return true;
			}
			return super.keyPressed(event);
		}

		@Override
		public boolean charTyped(CharacterEvent event) {
			return this.box.charTyped(event);
		}

		@Override
		public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
			return this.box.mouseClicked(event, doubleClick);
		}
	}
}
