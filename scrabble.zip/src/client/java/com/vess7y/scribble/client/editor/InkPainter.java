package com.vess7y.scribble.client.editor;

import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.render.SpriteData;
import it.unimi.dsi.fastutil.ints.IntArrayList;

/**
 * Pixel painting operations on ink layers. Every pixel is touched at most once per stroke (tracked with the
 * layer's stroke mask) so translucent brushes don't build up over themselves.
 */
public final class InkPainter {
	private InkPainter() {
	}

	public enum Shape {
		ROUND, SQUARE, WIDE, CHISEL
	}

	public enum Mode {
		PAINT, ERASE, ERASE_SOFT
	}

	/**
	 * @param size        brush diameter in ink pixels
	 * @param density     probability a pixel inside the brush gets painted (grainy chalk / pencil)
	 * @param alphaJitter random alpha reduction per pixel
	 */
	public record Brush(int color, int size, Shape shape, Mode mode, float density, float alphaJitter) {
		public static Brush solid(int color, int size, Shape shape) {
			return new Brush(color, size, shape, Mode.PAINT, 1.0F, 0.0F);
		}
	}

	public static void beginStroke(InkLayer layer) {
		layer.strokeMask.clear();
	}

	public static void line(InkLayer layer, float x0, float y0, float x1, float y1, Brush b, int seed) {
		float dx = x1 - x0;
		float dy = y1 - y0;
		float dist = (float) Math.sqrt(dx * dx + dy * dy);
		float step = Math.max(0.5F, b.size() * 0.35F);
		int steps = Math.max(1, (int) Math.ceil(dist / step));
		for (int i = 0; i <= steps; i++) {
			float t = (float) i / steps;
			stamp(layer, x0 + dx * t, y0 + dy * t, b, seed);
		}
	}

	public static void stamp(InkLayer layer, float cx, float cy, Brush b, int seed) {
		float rx;
		float ry;
		switch (b.shape()) {
			case WIDE -> {
				rx = b.size() / 2.0F;
				ry = Math.max(1, b.size() / 4.0F);
			}
			case CHISEL -> {
				rx = Math.max(1, b.size() / 6.0F);
				ry = b.size() / 2.0F;
			}
			default -> {
				rx = b.size() / 2.0F;
				ry = b.size() / 2.0F;
			}
		}
		int x0 = (int) Math.floor(cx - rx);
		int x1 = (int) Math.ceil(cx + rx);
		int y0 = (int) Math.floor(cy - ry);
		int y1 = (int) Math.ceil(cy + ry);
		float r2 = (b.size() / 2.0F) * (b.size() / 2.0F);
		for (int y = Math.max(0, y0); y < Math.min(layer.height, y1); y++) {
			for (int x = Math.max(0, x0); x < Math.min(layer.width, x1); x++) {
				float px = x + 0.5F - cx;
				float py = y + 0.5F - cy;
				if (b.shape() == Shape.ROUND) {
					if (px * px + py * py > r2 + 0.25F) {
						continue;
					}
				} else if (Math.abs(px) > rx || Math.abs(py) > ry) {
					continue;
				}
				plot(layer, x, y, b, seed);
			}
		}
		layer.markDirty(x0, y0, x1, y1);
	}

	private static void plot(InkLayer layer, int x, int y, Brush b, int seed) {
		int idx = y * layer.width + x;
		if (layer.strokeMask.get(idx)) {
			return;
		}
		int h = hash(x, y, seed);
		if (b.density() < 1.0F && (h & 0xFFFF) / 65536.0F > b.density()) {
			return;
		}
		layer.strokeMask.set(idx);
		int dst = layer.pixels[idx];
		switch (b.mode()) {
			case ERASE -> layer.pixels[idx] = 0;
			case ERASE_SOFT -> {
				int a = (int) ((dst >>> 24) * 0.3F);
				layer.pixels[idx] = a < 8 ? 0 : (a << 24) | (dst & 0xFFFFFF);
			}
			case PAINT -> {
				int color = b.color();
				if (b.alphaJitter() > 0) {
					float j = 1.0F - b.alphaJitter() * (((h >>> 16) & 0xFF) / 255.0F);
					color = ((int) ((color >>> 24) * j) << 24) | (color & 0xFFFFFF);
				}
				layer.pixels[idx] = over(dst, color);
			}
		}
	}

	public static int over(int dst, int src) {
		int sa = src >>> 24;
		if (sa == 255 || (dst >>> 24) == 0) {
			return src;
		}
		if (sa == 0) {
			return dst;
		}
		float a = sa / 255.0F;
		float da = (dst >>> 24) / 255.0F;
		float b = da * (1 - a);
		float oa = a + b;
		int r = (int) ((((src >> 16) & 0xFF) * a + ((dst >> 16) & 0xFF) * b) / oa);
		int g = (int) ((((src >> 8) & 0xFF) * a + ((dst >> 8) & 0xFF) * b) / oa);
		int bl = (int) (((src & 0xFF) * a + (dst & 0xFF) * b) / oa);
		return ((int) (oa * 255 + 0.5F) << 24) | (r << 16) | (g << 8) | bl;
	}

	private static int hash(int x, int y, int seed) {
		int h = x * 374761393 + y * 668265263 + seed * 1442695041;
		h = (h ^ (h >>> 13)) * 1274126177;
		return h ^ (h >>> 16);
	}

	// ------------------------------------------------------------------ shapes

	public static void rect(InkLayer layer, float x0, float y0, float x1, float y1, Brush b, boolean filled, int seed) {
		if (filled) {
			int ax = (int) Math.floor(Math.min(x0, x1));
			int bx = (int) Math.floor(Math.max(x0, x1));
			int ay = (int) Math.floor(Math.min(y0, y1));
			int by = (int) Math.floor(Math.max(y0, y1));
			for (int y = Math.max(0, ay); y <= Math.min(layer.height - 1, by); y++) {
				for (int x = Math.max(0, ax); x <= Math.min(layer.width - 1, bx); x++) {
					plot(layer, x, y, b, seed);
				}
			}
			layer.markDirty(ax, ay, bx, by);
		}
		line(layer, x0, y0, x1, y0, b, seed);
		line(layer, x1, y0, x1, y1, b, seed);
		line(layer, x1, y1, x0, y1, b, seed);
		line(layer, x0, y1, x0, y0, b, seed);
	}

	public static void ellipse(InkLayer layer, float x0, float y0, float x1, float y1, Brush b, boolean filled, int seed) {
		float cx = (x0 + x1) / 2;
		float cy = (y0 + y1) / 2;
		float rx = Math.abs(x1 - x0) / 2;
		float ry = Math.abs(y1 - y0) / 2;
		if (filled && rx > 0 && ry > 0) {
			for (int y = (int) Math.floor(cy - ry); y <= (int) Math.ceil(cy + ry); y++) {
				for (int x = (int) Math.floor(cx - rx); x <= (int) Math.ceil(cx + rx); x++) {
					float nx = (x + 0.5F - cx) / rx;
					float ny = (y + 0.5F - cy) / ry;
					if (nx * nx + ny * ny <= 1 && x >= 0 && y >= 0 && x < layer.width && y < layer.height) {
						plot(layer, x, y, b, seed);
					}
				}
			}
			layer.markDirty((int) (cx - rx), (int) (cy - ry), (int) (cx + rx) + 1, (int) (cy + ry) + 1);
		}
		int steps = Math.max(24, (int) ((rx + ry) * 2));
		float px = cx + rx;
		float py = cy;
		for (int i = 1; i <= steps; i++) {
			double a = Math.PI * 2 * i / steps;
			float nx = cx + (float) Math.cos(a) * rx;
			float ny = cy + (float) Math.sin(a) * ry;
			line(layer, px, py, nx, ny, b, seed);
			px = nx;
			py = ny;
		}
	}

	/** Flood fills the contiguous region of identical pixels under (x, y). */
	public static boolean floodFill(InkLayer layer, int x, int y, int color) {
		if (x < 0 || y < 0 || x >= layer.width || y >= layer.height) {
			return false;
		}
		int target = layer.pixels[y * layer.width + x];
		int replacement = over(target, color);
		if (target == replacement) {
			return false;
		}
		IntArrayList stack = new IntArrayList();
		stack.push(y * layer.width + x);
		int minX = x, maxX = x, minY = y, maxY = y;
		while (!stack.isEmpty()) {
			int idx = stack.popInt();
			if (layer.pixels[idx] != target) {
				continue;
			}
			int px = idx % layer.width;
			int py = idx / layer.width;
			int lx = px;
			while (lx > 0 && layer.pixels[idx - (px - lx) - 1] == target) {
				lx--;
			}
			int rx = px;
			while (rx < layer.width - 1 && layer.pixels[idx + (rx - px) + 1] == target) {
				rx++;
			}
			for (int i = lx; i <= rx; i++) {
				int j = py * layer.width + i;
				layer.pixels[j] = replacement;
				if (py > 0 && layer.pixels[j - layer.width] == target) {
					stack.push(j - layer.width);
				}
				if (py < layer.height - 1 && layer.pixels[j + layer.width] == target) {
					stack.push(j + layer.width);
				}
			}
			minX = Math.min(minX, lx);
			maxX = Math.max(maxX, rx);
			minY = Math.min(minY, py);
			maxY = Math.max(maxY, py);
		}
		layer.markDirty(minX, minY, maxX, maxY);
		return true;
	}

	/** Paints a sprite (stamp) centered at (cx, cy), each sprite pixel becoming {@code scale} ink pixels. */
	public static void sprite(InkLayer layer, SpriteData sprite, int cx, int cy, int scale) {
		int w = sprite.width() * scale;
		int h = sprite.height() * scale;
		int x0 = cx - w / 2;
		int y0 = cy - h / 2;
		for (int y = 0; y < h; y++) {
			int ty = y0 + y;
			if (ty < 0 || ty >= layer.height) {
				continue;
			}
			for (int x = 0; x < w; x++) {
				int tx = x0 + x;
				if (tx < 0 || tx >= layer.width) {
					continue;
				}
				int src = sprite.get(x / scale, y / scale);
				if ((src >>> 24) != 0) {
					int idx = ty * layer.width + tx;
					layer.pixels[idx] = over(layer.pixels[idx], src);
				}
			}
		}
		layer.markDirty(x0, y0, x0 + w, y0 + h);
	}

	/** Pastes an image scaled to fit inside the layer, centered. */
	public static void image(InkLayer layer, int[] argb, int w, int h) {
		float s = Math.min((float) layer.width / w, (float) layer.height / h);
		s = Math.min(s, 4.0F);
		int tw = Math.max(1, (int) (w * s));
		int th = Math.max(1, (int) (h * s));
		int x0 = (layer.width - tw) / 2;
		int y0 = (layer.height - th) / 2;
		for (int y = 0; y < th; y++) {
			int sy = Math.min(h - 1, (int) (y / s));
			for (int x = 0; x < tw; x++) {
				int sx = Math.min(w - 1, (int) (x / s));
				int idx = (y0 + y) * layer.width + x0 + x;
				layer.pixels[idx] = over(layer.pixels[idx], argb[sy * w + sx]);
			}
		}
		layer.markDirty(x0, y0, x0 + tw, y0 + th);
	}
}
