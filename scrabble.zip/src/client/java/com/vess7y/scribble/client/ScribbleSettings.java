package com.vess7y.scribble.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.vess7y.scribble.Scribble;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Small persisted preferences in {@code .minecraft/scribble/settings.json}.
 */
public final class ScribbleSettings {
	public static boolean sounds = true;
	public static boolean typingSounds = true;
	private static boolean loaded;

	private ScribbleSettings() {
	}

	private static Path file() {
		return NotesStorage.root().resolve("settings.json");
	}

	public static void load() {
		if (loaded) {
			return;
		}
		loaded = true;
		try {
			if (Files.isRegularFile(file())) {
				JsonObject o = JsonParser.parseString(Files.readString(file(), StandardCharsets.UTF_8)).getAsJsonObject();
				sounds = !o.has("sounds") || o.get("sounds").getAsBoolean();
				typingSounds = !o.has("typing_sounds") || o.get("typing_sounds").getAsBoolean();
			}
		} catch (Exception e) {
			Scribble.LOGGER.warn("Could not read Scribble settings", e);
		}
	}

	public static void save() {
		JsonObject o = new JsonObject();
		o.addProperty("sounds", sounds);
		o.addProperty("typing_sounds", typingSounds);
		try {
			Files.createDirectories(file().getParent());
			Files.writeString(file(), o.toString(), StandardCharsets.UTF_8);
		} catch (Exception e) {
			Scribble.LOGGER.warn("Could not save Scribble settings", e);
		}
	}
}
