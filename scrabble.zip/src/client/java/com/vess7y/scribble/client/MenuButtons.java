package com.vess7y.scribble.client;

import com.vess7y.scribble.Scribble;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

/**
 * Adds a small Scribble icon button next to the other icon buttons (language, accessibility, ...) on the title
 * screen and in the pause menu.
 */
public final class MenuButtons {
	private static final int SIZE = 20;
	private static final int SPACING = 4;

	private MenuButtons() {
	}

	public static void register() {
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			if (screen instanceof TitleScreen || screen instanceof PauseScreen) {
				addButton(client, screen);
			}
		});
	}

	private static void addButton(Minecraft client, Screen screen) {
		List<AbstractWidget> widgets = Screens.getWidgets(screen);
		if (widgets.isEmpty()) {
			return; // pause screen without menu (F3 + Esc)
		}
		SpriteIconButton button = SpriteIconButton.builder(Component.translatable("scribble.menu.button"),
						b -> client.gui.setScreen(new NotesScreen(screen)), true)
				.size(SIZE, SIZE)
				.sprite(Scribble.id("icon/scribble"), 15, 15)
				.build();
		button.setTooltip(Tooltip.create(Component.translatable("scribble.menu.tooltip")));

		// find the row of small square icon buttons and append to it, keeping the row centered
		Map<Integer, List<AbstractWidget>> rows = new HashMap<>();
		for (AbstractWidget w : widgets) {
			if (w.visible && w.getWidth() == SIZE && w.getHeight() == SIZE) {
				rows.computeIfAbsent(w.getY(), y -> new ArrayList<>()).add(w);
			}
		}
		List<AbstractWidget> row = null;
		for (List<AbstractWidget> r : rows.values()) {
			if (r.size() >= 2 && (row == null || r.size() > row.size())) {
				row = r;
			}
		}
		if (row != null) {
			row.sort(Comparator.comparingInt(AbstractWidget::getX));
			int minX = row.getFirst().getX();
			int maxX = row.getLast().getX() + SIZE;
			int center = (minX + maxX) / 2;
			int n = row.size() + 1;
			int total = n * SIZE + (n - 1) * SPACING;
			int x = center - total / 2;
			for (AbstractWidget w : row) {
				w.setX(x);
				x += SIZE + SPACING;
			}
			button.setPosition(x, row.getFirst().getY());
		} else {
			button.setPosition(4, 4);
		}
		widgets.add(button);
	}
}
