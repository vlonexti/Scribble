package com.vess7y.scribble.client.ui;

import java.util.Random;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Lazy dust motes drifting through warm light: a tiny bit of ambient life for the cozy desk background.
 */
public final class Dust {
	private static final int COUNT = 40;
	private final float[] x = new float[COUNT];
	private final float[] y = new float[COUNT];
	private final float[] speed = new float[COUNT];
	private final float[] phase = new float[COUNT];
	private final int[] size = new int[COUNT];
	private boolean seeded;

	public void render(GuiGraphicsExtractor g, int w, int h) {
		if (!this.seeded) {
			Random r = new Random(7);
			for (int i = 0; i < COUNT; i++) {
				this.x[i] = r.nextFloat();
				this.y[i] = r.nextFloat();
				this.speed[i] = 0.004F + r.nextFloat() * 0.01F;
				this.phase[i] = r.nextFloat() * 6.28F;
				this.size[i] = r.nextFloat() < 0.25F ? 2 : 1;
			}
			this.seeded = true;
		}
		float dt = Anim.dt();
		float t = Anim.time();
		for (int i = 0; i < COUNT; i++) {
			this.y[i] -= this.speed[i] * dt;
			this.x[i] += (float) Math.sin(t * 0.4F + this.phase[i]) * 0.003F * dt;
			if (this.y[i] < -0.02F) {
				this.y[i] = 1.02F;
			}
			float twinkle = 0.5F + 0.5F * (float) Math.sin(t * 1.3F + this.phase[i] * 3);
			int a = (int) (30 + 70 * twinkle);
			int px = Math.round(Math.floorMod((int) (this.x[i] * w * 10), w * 10) / 10.0F);
			int py = Math.round(this.y[i] * h);
			g.fill(px, py, px + this.size[i], py + this.size[i], (a << 24) | 0xFFE9C0);
		}
	}
}
