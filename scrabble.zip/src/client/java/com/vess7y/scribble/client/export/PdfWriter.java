package com.vess7y.scribble.client.export;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.Deflater;

/**
 * Minimal PDF writer: one full-bleed image per page. Enough for exporting pixel-perfect pages without
 * pulling in a PDF library.
 */
public final class PdfWriter {
	public record Page(int[] argb, int width, int height) {
	}

	private PdfWriter() {
	}

	/**
	 * @param pointsPerPixel physical size of one image pixel in PDF points (1/72 inch)
	 */
	public static void write(Path path, List<Page> pages, float pointsPerPixel) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		List<Integer> offsets = new ArrayList<>();
		int objects = 2 + pages.size() * 3;

		ascii(out, "%PDF-1.4\n%âãÏÓ\n");

		offsets.add(out.size());
		ascii(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

		offsets.add(out.size());
		StringBuilder kids = new StringBuilder();
		for (int i = 0; i < pages.size(); i++) {
			kids.append(3 + i * 3).append(" 0 R ");
		}
		ascii(out, "2 0 obj\n<< /Type /Pages /Kids [" + kids + "] /Count " + pages.size() + " >>\nendobj\n");

		for (int i = 0; i < pages.size(); i++) {
			Page page = pages.get(i);
			int pageObj = 3 + i * 3;
			int contentObj = pageObj + 1;
			int imageObj = pageObj + 2;
			String w = fmt(page.width * pointsPerPixel);
			String h = fmt(page.height * pointsPerPixel);

			offsets.add(out.size());
			ascii(out, pageObj + " 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " + w + " " + h + "] "
					+ "/Resources << /XObject << /Im0 " + imageObj + " 0 R >> >> /Contents " + contentObj + " 0 R >>\nendobj\n");

			byte[] content = ("q " + w + " 0 0 " + h + " 0 0 cm /Im0 Do Q").getBytes(StandardCharsets.ISO_8859_1);
			offsets.add(out.size());
			ascii(out, contentObj + " 0 obj\n<< /Length " + content.length + " >>\nstream\n");
			out.write(content);
			ascii(out, "\nendstream\nendobj\n");

			byte[] image = deflate(toRgbOnWhite(page));
			offsets.add(out.size());
			ascii(out, imageObj + " 0 obj\n<< /Type /XObject /Subtype /Image /Width " + page.width + " /Height " + page.height
					+ " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length " + image.length + " >>\nstream\n");
			out.write(image);
			ascii(out, "\nendstream\nendobj\n");
		}

		int xref = out.size();
		ascii(out, "xref\n0 " + (objects + 1) + "\n0000000000 65535 f \n");
		for (int off : offsets) {
			ascii(out, String.format(Locale.ROOT, "%010d 00000 n \n", off));
		}
		ascii(out, "trailer\n<< /Size " + (objects + 1) + " /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
		Files.write(path, out.toByteArray());
	}

	private static byte[] toRgbOnWhite(Page page) {
		byte[] rgb = new byte[page.width * page.height * 3];
		for (int i = 0; i < page.argb.length; i++) {
			int p = page.argb[i];
			int a = p >>> 24;
			int r = ((p >> 16) & 0xFF) * a / 255 + 255 - a;
			int g = ((p >> 8) & 0xFF) * a / 255 + 255 - a;
			int b = (p & 0xFF) * a / 255 + 255 - a;
			rgb[i * 3] = (byte) r;
			rgb[i * 3 + 1] = (byte) g;
			rgb[i * 3 + 2] = (byte) b;
		}
		return rgb;
	}

	private static byte[] deflate(byte[] data) {
		Deflater deflater = new Deflater(Deflater.BEST_COMPRESSION);
		deflater.setInput(data);
		deflater.finish();
		ByteArrayOutputStream out = new ByteArrayOutputStream(data.length / 4);
		byte[] buf = new byte[65536];
		while (!deflater.finished()) {
			int n = deflater.deflate(buf);
			out.write(buf, 0, n);
		}
		deflater.end();
		return out.toByteArray();
	}

	private static void ascii(OutputStream out, String s) throws IOException {
		out.write(s.getBytes(StandardCharsets.ISO_8859_1));
	}

	private static String fmt(float f) {
		return String.format(Locale.ROOT, "%.2f", f);
	}
}
