package com.vess7y.scribble.client.note;

/**
 * Inline character formatting. Immutable; compare with equals.
 *
 * @param color     ARGB text color, or 0 to use the note's default ink
 * @param highlight ARGB highlight color, or 0 for none
 */
public record TextFormat(boolean bold, boolean italic, boolean underline, boolean strike, int color, int highlight) {
	public static final TextFormat PLAIN = new TextFormat(false, false, false, false, 0, 0);

	public TextFormat withBold(boolean v) {
		return new TextFormat(v, this.italic, this.underline, this.strike, this.color, this.highlight);
	}

	public TextFormat withItalic(boolean v) {
		return new TextFormat(this.bold, v, this.underline, this.strike, this.color, this.highlight);
	}

	public TextFormat withUnderline(boolean v) {
		return new TextFormat(this.bold, this.italic, v, this.strike, this.color, this.highlight);
	}

	public TextFormat withStrike(boolean v) {
		return new TextFormat(this.bold, this.italic, this.underline, v, this.color, this.highlight);
	}

	public TextFormat withColor(int v) {
		return new TextFormat(this.bold, this.italic, this.underline, this.strike, v, this.highlight);
	}

	public TextFormat withHighlight(int v) {
		return new TextFormat(this.bold, this.italic, this.underline, this.strike, this.color, v);
	}

	public boolean get(Flag flag) {
		return switch (flag) {
			case BOLD -> this.bold;
			case ITALIC -> this.italic;
			case UNDERLINE -> this.underline;
			case STRIKE -> this.strike;
		};
	}

	public TextFormat with(Flag flag, boolean v) {
		return switch (flag) {
			case BOLD -> this.withBold(v);
			case ITALIC -> this.withItalic(v);
			case UNDERLINE -> this.withUnderline(v);
			case STRIKE -> this.withStrike(v);
		};
	}

	public enum Flag {
		BOLD, ITALIC, UNDERLINE, STRIKE
	}
}
