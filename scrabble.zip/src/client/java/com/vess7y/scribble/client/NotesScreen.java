package com.vess7y.scribble.client;

import com.mojang.blaze3d.Blaze3D;
import com.mojang.blaze3d.platform.cursor.CursorTypes;
import com.vess7y.scribble.Scribble;
import com.vess7y.scribble.client.editor.NoteEditorScreen;
import com.vess7y.scribble.client.export.NoteExporter;
import com.vess7y.scribble.client.note.InkLayer;
import com.vess7y.scribble.client.note.Note;
import com.vess7y.scribble.client.note.NoteType;
import com.vess7y.scribble.client.note.ParaStyle;
import com.vess7y.scribble.client.note.Paragraph;
import com.vess7y.scribble.client.note.TextFormat;
import com.vess7y.scribble.client.render.BitmapFont;
import com.vess7y.scribble.client.render.PageRenderer;
import com.vess7y.scribble.client.render.SpriteData;
import com.vess7y.scribble.client.render.Sprites;
import com.vess7y.scribble.client.text.TextLayout;
import com.vess7y.scribble.client.text.TextMetrics;
import com.vess7y.scribble.client.ui.Anim;
import com.vess7y.scribble.client.ui.Dialog;
import com.vess7y.scribble.client.ui.Dust;
import com.vess7y.scribble.client.ui.Hotspots;
import com.vess7y.scribble.client.ui.Notifications;
import com.vess7y.scribble.client.ui.Popup;
import com.vess7y.scribble.client.ui.Ui;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import org.jspecify.annotations.Nullable;

/**
 * The Scribble library: a cozy desk with a corkboard of templates and your notes scattered as paper cards that
 * you can pick up, swing around and rearrange.
 */
public class NotesScreen extends Screen {
	private static final int HEADER_H = 34;
	private static final int TEMPLATE_W = 64;
	private static final int TEMPLATE_H = 88;
	private static final int TILE_W = 92;
	private static final int TILE_H = 122;
	private static final int GAP = 10;

	private final @Nullable Screen parent;
	private final Hotspots hs = new Hotspots();
	private final EditBox search;
	private final Map<String, Thumb> thumbs = new HashMap<>();
	private final Map<NoteType, Note> samples = new EnumMap<>(NoteType.class);
	private final Map<NoteType, TextLayout> sampleLayouts = new EnumMap<>(NoteType.class);
	private final Dust dust = new Dust();
	private final long openedAt = Util.getMillis();
	private List<Note> notes = new ArrayList<>();
	private List<String> order = new ArrayList<>();
	private Filter filter = Filter.ALL;
	private Sort sort = Sort.CUSTOM;
	private double scroll;
	private int contentHeight;
	private @Nullable Popup popup;
	private @Nullable Dialog dialog;
	private Hotspots.@Nullable DragHandler activeDrag;

	// tile hit boxes and chip drop targets from the last frame
	private final List<TileRect> tileRects = new ArrayList<>();
	private final Map<Filter, int[]> chipRects = new EnumMap<>(Filter.class);
	private final List<int[]> slotRects = new ArrayList<>();

	// card dragging with pivot physics
	private @Nullable Note pressed;
	private double pressX;
	private double pressY;
	private @Nullable Note dragged;
	private float grabX;
	private float grabY;
	private float angle;
	private float angVel;
	private double prevMx = Double.NaN;
	private double prevMy;
	private float velX;
	private float velY;
	private int insertIndex = -1;
	private @Nullable Filter dropChip;
	private int clickX;
	private int clickY;

	private record TileRect(Note note, int x, int y, int w, int h) {
	}

	private enum Filter {
		ALL("all", null), STARRED("starred", "star_filled"), PAPER("paper", "type_lined"), BOARDS("boards", "type_whiteboard"), TRASH("trash", "trash");

		final String id;
		final @Nullable String icon;

		Filter(String id, @Nullable String icon) {
			this.id = id;
			this.icon = icon;
		}
	}

	private enum Sort {
		CUSTOM("custom"), EDITED("edited"), CREATED("created"), TITLE("title"), TYPE("type");

		final String id;

		Sort(String id) {
			this.id = id;
		}
	}

	private record Thumb(long modified, TextLayout layout, @Nullable InkLayer ink, int pages) {
	}

	public NotesScreen(@Nullable Screen parent) {
		super(Component.translatable("scribble.library.title"));
		this.parent = parent;
		this.search = new EditBox(Ui.font(), 0, 0, 100, 10, Component.translatable("scribble.library.search"));
		this.search.setBordered(false);
		this.search.setMaxLength(64);
		this.search.setTextColor(Ui.TEXT);
		this.search.setHint(Component.translatable("scribble.library.search").withStyle(s -> s.withColor(0xB09878)));
		this.search.setResponder(s -> this.scroll = 0);
		ScribbleSettings.load();
	}

	@Override
	protected void init() {
		TextMetrics.invalidate();
		BitmapFont.invalidate();
		SpriteData.invalidate();
		this.reload();
	}

	private void reload() {
		this.notes = NotesStorage.loadAll();
		this.order = NotesStorage.loadOrder();
	}

	@Override
	public void removed() {
		for (Thumb t : this.thumbs.values()) {
			if (t.ink != null) {
				t.ink.release();
			}
		}
		this.thumbs.clear();
	}

	@Override
	public void onClose() {
		ScribbleSounds.playVaried(ScribbleSounds.WHOOSH, 1.0F, 0.4F);
		this.minecraft.gui.setScreen(this.parent);
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	// ------------------------------------------------------------------ data

	private boolean matches(Note n, Filter f) {
		return switch (f) {
			case ALL -> !n.trashed;
			case STARRED -> !n.trashed && n.starred;
			case PAPER -> !n.trashed && !n.type.board;
			case BOARDS -> !n.trashed && n.type.board;
			case TRASH -> n.trashed;
		};
	}

	private List<Note> visibleNotes() {
		String q = this.search.getValue().strip().toLowerCase(Locale.ROOT);
		List<Note> out = new ArrayList<>();
		for (Note n : this.notes) {
			boolean match = this.matches(n, this.filter);
			if (match && !q.isEmpty()) {
				match = n.title.toLowerCase(Locale.ROOT).contains(q) || n.plainText().toLowerCase(Locale.ROOT).contains(q)
						|| Component.translatable(n.type.translationKey()).getString().toLowerCase(Locale.ROOT).contains(q);
			}
			if (match) {
				out.add(n);
			}
		}
		Comparator<Note> cmp = switch (this.sort) {
			case CUSTOM -> Comparator.comparingInt((Note n) -> {
				int i = this.order.indexOf(n.id);
				return i < 0 ? -1 : i;
			}).thenComparing(Comparator.comparingLong((Note n) -> n.modified).reversed());
			case EDITED -> Comparator.comparingLong((Note n) -> n.modified).reversed();
			case CREATED -> Comparator.comparingLong((Note n) -> n.created).reversed();
			case TITLE -> Comparator.comparing((Note n) -> displayTitle(n).toLowerCase(Locale.ROOT));
			case TYPE -> Comparator.comparing((Note n) -> n.type.ordinal()).thenComparing(n -> -n.modified);
		};
		if (this.sort != Sort.CUSTOM) {
			cmp = Comparator.comparing((Note n) -> !n.starred || this.filter == Filter.TRASH).thenComparing(cmp);
		}
		out.sort(cmp);
		return out;
	}

	private int count(Filter f) {
		int c = 0;
		for (Note n : this.notes) {
			c += this.matches(n, f) ? 1 : 0;
		}
		return c;
	}

	private static String displayTitle(Note n) {
		if (!n.title.isBlank()) {
			return n.title;
		}
		String snippet = n.snippet();
		return snippet.isEmpty() ? Component.translatable("scribble.note.untitled").getString() : snippet;
	}

	private Thumb thumb(Note n) {
		Thumb t = this.thumbs.get(n.id);
		if (t == null || t.modified != n.modified) {
			if (t != null && t.ink != null) {
				t.ink.release();
			}
			InkLayer full = NotesStorage.loadInkPage(n, 0);
			InkLayer small = full == null ? null : full.downscaled(4);
			TextLayout layout = TextLayout.build(n, TextMetrics.get());
			t = new Thumb(n.modified, layout, small, layout.pageCount(n));
			this.thumbs.put(n.id, t);
		}
		return t;
	}

	private Note sample(NoteType type) {
		return this.samples.computeIfAbsent(type, t -> {
			Note n = new Note("sample_" + t.id, t);
			n.paragraphs.clear();
			Paragraph title = new Paragraph(Component.translatable("scribble.type." + t.id).getString());
			title.style = ParaStyle.TITLE;
			n.paragraphs.add(title);
			String[] lines = {"Gather wood and stone", "Build a cozy base", "Find diamonds!", "Tame a wolf", "Plant a garden"};
			for (int i = 0; i < lines.length; i++) {
				Paragraph p = new Paragraph();
				p.insert(0, lines[i], i == 2 ? TextFormat.PLAIN.withColor(t.palette[Math.min(2, t.palette.length - 1)]) : TextFormat.PLAIN);
				p.style = t.board ? ParaStyle.BULLET : ParaStyle.CHECKLIST;
				p.checked = !t.board && i == 0;
				n.paragraphs.add(p);
			}
			return n;
		});
	}

	private static float tiltOf(String id) {
		int h = id.hashCode();
		return ((Math.floorMod(h, 9) - 4) / 4.0F) * 0.035F;
	}

	// ------------------------------------------------------------------ actions

	private void createNote(NoteType type) {
		Note note = Note.create(type, "");
		NotesStorage.save(note);
		ScribbleSounds.playVaried(ScribbleSounds.PAPER_PICKUP, 1.0F, 0.7F);
		Notifications.info(type.iconName(), Component.translatable("scribble.notify.created"),
				Component.translatable(type.translationKey()));
		this.open(note);
	}

	private void open(Note note) {
		Ui.pageTurn();
		this.minecraft.gui.setScreen(new NoteEditorScreen(this, note));
	}

	private void trash(Note note) {
		note.trashed = true;
		boolean wasStarred = note.starred;
		note.starred = false;
		NotesStorage.save(note);
		ScribbleSounds.playVaried(ScribbleSounds.CRUMPLE, 1.0F, 0.6F);
		Notifications.push("trash", Component.translatable("scribble.note.trashed"), Component.literal(displayTitle(note)),
				0xFFE8604C, Component.translatable("scribble.notify.undo"), () -> {
					note.trashed = false;
					note.starred = wasStarred;
					NotesStorage.save(note);
					ScribbleSounds.playVaried(ScribbleSounds.PAPER_DROP, 1.0F, 0.6F);
				});
	}

	private void toggleStar(Note note) {
		note.starred = !note.starred;
		NotesStorage.save(note);
		ScribbleSounds.playVaried(ScribbleSounds.POP, note.starred ? 1.3F : 0.9F, 0.5F);
		if (note.starred) {
			Notifications.info("star_filled", Component.translatable("scribble.notify.starred"), Component.literal(displayTitle(note)));
		}
	}

	private void openPopup(Popup p, int x, int y) {
		p.setCloser(() -> {
			if (this.popup == p) {
				this.popup = null;
			}
		});
		p.at(x, y, this.width, this.height);
		this.popup = p;
		Ui.pop();
	}

	private void openDialog(Dialog d) {
		d.setCloser(() -> {
			if (this.dialog == d) {
				this.dialog = null;
			}
		});
		this.popup = null;
		this.dialog = d;
		this.search.setFocused(false);
		Ui.pop();
	}

	private void exportNote(Note note, NoteExporter.Format f) {
		try {
			Path file = NoteExporter.export(note, f);
			Notifications.success(f.icon, Component.translatable("scribble.export.done"), Component.literal(file.getFileName().toString()),
					Component.translatable("scribble.export.open_folder"), () -> Blaze3D.openPath(NotesStorage.exportsDir()));
		} catch (Exception e) {
			Scribble.LOGGER.error("Export failed", e);
			Notifications.warn(Component.translatable("scribble.export.failed"), Component.literal(String.valueOf(e.getMessage())));
		}
	}

	private Popup noteMenu(Note note) {
		Popup.Menu m = new Popup.Menu();
		if (note.trashed) {
			m.item("restore", Component.translatable("scribble.note.restore"), () -> {
				note.trashed = false;
				NotesStorage.save(note);
				Notifications.success("restore", Component.translatable("scribble.notify.restored"), Component.literal(displayTitle(note)));
			});
			m.item("trash", Component.translatable("scribble.note.delete_forever"), () -> this.openDialog(new Dialog.Confirm(
					Component.translatable("scribble.note.delete_forever"),
					Component.translatable("scribble.note.delete_confirm", displayTitle(note)),
					Component.translatable("scribble.note.delete_button"),
					() -> {
						NotesStorage.delete(note);
						ScribbleSounds.playVaried(ScribbleSounds.CRUMPLE, 0.8F, 0.7F);
						this.reload();
					})));
			return m;
		}
		m.item("paper", Component.translatable("scribble.note.open"), () -> this.open(note));
		m.item("rename", Component.translatable("scribble.note.rename"), () -> this.openDialog(new Dialog.Input(
				Component.translatable("scribble.note.rename"), note.title, 64, title -> {
			note.title = title;
			note.touch();
			NotesStorage.save(note);
		})));
		m.item("copy", Component.translatable("scribble.note.duplicate"), () -> {
			NotesStorage.duplicate(note, Component.translatable("scribble.note.copy_of", displayTitle(note)).getString());
			this.reload();
			Notifications.success("copy", Component.translatable("scribble.notify.duplicated"), Component.literal(displayTitle(note)));
		});
		m.item(note.starred ? "star" : "star_filled", Component.translatable(note.starred ? "scribble.note.unstar" : "scribble.note.star"),
				() -> this.toggleStar(note));
		m.separator();
		for (NoteExporter.Format f : NoteExporter.Format.values()) {
			m.item(f.icon, Component.translatable(f.translationKey()), () -> this.exportNote(note, f));
		}
		m.separator();
		m.item("trash", Component.translatable("scribble.note.trash"), () -> this.trash(note));
		return m;
	}

	private Popup sortMenu() {
		Popup.Menu m = new Popup.Menu();
		for (Sort s : Sort.values()) {
			m.item(null, Component.translatable("scribble.sort." + s.id), null, true, this.sort == s, () -> this.sort = s);
		}
		return m;
	}

	// ------------------------------------------------------------------ rendering

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		Ui.sprite(g, Sprites.DESK, 0, 0, this.width, this.height);
		Ui.cozyLight(g, this.width, this.height);
		this.dust.render(g, this.width, this.height);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		Anim.beginFrame();
		this.hs.clear();
		this.tileRects.clear();
		this.chipRects.clear();
		int contentW = Math.min(this.width - 28, 820);
		int x0 = (this.width - contentW) / 2;
		double maxScroll = Math.max(0, this.contentHeight - (this.height - HEADER_H));
		this.scroll = Mth.clamp(this.scroll, 0, maxScroll);
		this.updateDragPhysics(mouseX, mouseY);

		g.enableScissor(0, HEADER_H, this.width, this.height);
		this.hs.clip(0, HEADER_H, this.width, this.height);
		int cy = HEADER_H + 10 - (int) this.scroll;
		int start = cy;
		cy = this.renderTemplates(g, mouseX, mouseY, x0, contentW, cy);
		cy = this.renderFilters(g, mouseX, mouseY, x0, contentW, cy);
		this.updateDropTarget(mouseX, mouseY);
		cy = this.renderGrid(g, mouseX, mouseY, x0, contentW, cy);
		this.contentHeight = cy - start + 20;
		this.hs.unclip();
		g.disableScissor();

		if (maxScroll > 0) {
			Ui.scrollbar(g, this.hs, this.width - 9, HEADER_H + 4, this.height - HEADER_H - 8, this.scroll, maxScroll,
					(mx, my) -> this.scroll = (my - HEADER_H) / (this.height - HEADER_H) * maxScroll);
		}

		this.renderHeader(g, mouseX, mouseY);
		if (this.dragged != null) {
			this.renderDragged(g, mouseX, mouseY);
		}
		if (this.popup != null) {
			this.popup.render(g, this.hs, mouseX, mouseY);
		}
		if (this.dialog != null) {
			this.dialog.render(g, this.hs, this.width, this.height, mouseX, mouseY);
		}
		Notifications.render(g, this.hs, this.width - 8, HEADER_H + 6, mouseX, mouseY);

		Hotspots.Hotspot hover = this.hs.at(mouseX, mouseY);
		if (this.dragged != null) {
			g.requestCursor(CursorTypes.RESIZE_ALL);
		} else if (hover != null) {
			if (hover.tooltip != null) {
				g.setTooltipForNextFrame(this.font, hover.tooltip, mouseX, mouseY);
			}
			if (hover.pointer && (hover.onClick != null || hover.onRightClick != null)) {
				Ui.requestPointer(g);
			}
		} else if (this.tileAt(mouseX, mouseY) != null) {
			Ui.requestPointer(g);
		}
		Ui.endFrame();
	}

	private void renderHeader(GuiGraphicsExtractor g, int mx, int my) {
		Ui.shadow(g, -10, -10, this.width + 20, HEADER_H + 10, 0.9F);
		Ui.sprite(g, Sprites.DESK_DARK, 0, 0, this.width, HEADER_H);
		g.fill(0, HEADER_H - 3, this.width, HEADER_H - 2, 0x40FFE0B0);
		g.fill(0, HEADER_H - 2, this.width, HEADER_H, Ui.INK);
		float bob = (float) Math.sin(Anim.time() * 2.2F) * 0.08F;
		g.pose().pushMatrix();
		g.pose().translate(16, 17);
		g.pose().rotate(bob);
		Ui.sprite(g, Sprites.PENCIL, -8, -8, 16, 16);
		g.pose().popMatrix();
		Ui.sprite(g, Sprites.LOGO, 28, 4, Sprites.LOGO_WIDTH, Sprites.LOGO_HEIGHT);

		int bx = this.width - 26;
		Ui.iconButton(g, this.hs, mx, my, bx, 7, 20, "close", Component.translatable("scribble.library.close"), false, true, false, this::onClose);
		bx -= 24;
		Ui.iconButton(g, this.hs, mx, my, bx, 7, 20, "folder", Component.translatable("scribble.library.folder"), false, true, false, () -> {
			try {
				Files.createDirectories(NotesStorage.root());
			} catch (Exception ignored) {
			}
			Blaze3D.openPath(NotesStorage.root());
		});
		bx -= 24;
		Ui.iconButton(g, this.hs, mx, my, bx, 7, 20, ScribbleSettings.sounds ? "sound_on" : "sound_off",
				Component.translatable(ScribbleSettings.sounds ? "scribble.settings.sounds_on" : "scribble.settings.sounds_off"), false, true, false, () -> {
					ScribbleSettings.sounds = !ScribbleSettings.sounds;
					ScribbleSettings.save();
				});
		int logoEnd = 28 + Sprites.LOGO_WIDTH + 12;
		int sw = Math.min(210, bx - 8 - logoEnd);
		if (sw > 60) {
			int sx = bx - 8 - sw;
			Ui.sprite(g, this.search.isFocused() ? Sprites.FIELD_FOCUSED : Sprites.FIELD, sx, 8, sw, 18);
			Ui.animatedIcon(g, "search", sx + 1, 9, 1.0F, this.search.isFocused(), "searchIcon");
			this.search.setX(sx + 19);
			this.search.setY(13);
			this.search.setWidth(sw - 23);
			this.search.extractRenderState(g, mx, my, 0);
			this.hs.add(sx, 8, sw, 18).noPointer();
		}
	}

	private int renderTemplates(GuiGraphicsExtractor g, int mx, int my, int x0, int w, int cy) {
		int perRow = Math.max(1, (w - 16 + 8) / (TEMPLATE_W + 8));
		NoteType[] types = NoteType.values();
		int rows = (types.length + perRow - 1) / perRow;
		int boardH = 30 + rows * (TEMPLATE_H + 10);
		// corkboard in a wooden frame
		Ui.shadow(g, x0, cy, w, boardH, 0.9F);
		Ui.sprite(g, Sprites.PANEL_DARK, x0, cy, w, boardH);
		Ui.sprite(g, Sprites.CORK, x0 + 5, cy + 5, w - 10, boardH - 11);
		g.fill(x0 + 5, cy + 5, x0 + w - 5, cy + 7, 0x40000000);
		// pinned label
		Component label = Component.translatable("scribble.library.new");
		int lw = this.font.width(label) + 16;
		g.pose().pushMatrix();
		g.pose().translate(x0 + 12 + lw / 2.0F, cy + 13);
		g.pose().rotate(-0.03F);
		Ui.sprite(g, Sprites.CHIP, -lw / 2, -7, lw, 15);
		Ui.text(g, label, -lw / 2 + 8, -4, Ui.TEXT);
		Ui.sprite(g, Sprites.PIN, -lw / 2 - 2, -10, 8, 8);
		g.pose().popMatrix();

		boolean blocked = this.popup != null || this.dialog != null || this.dragged != null;
		int rowW = Math.min(types.length, perRow) * (TEMPLATE_W + 8) - 8;
		int tx0 = x0 + (w - rowW) / 2;
		for (int i = 0; i < types.length; i++) {
			NoteType type = types[i];
			int tx = tx0 + (i % perRow) * (TEMPLATE_W + 8);
			int ty = cy + 26 + (i / perRow) * (TEMPLATE_H + 10);
			boolean hover = !blocked && Ui.hovered(mx, my, tx, ty, TEMPLATE_W, TEMPLATE_H);
			Object key = "tpl" + type.id;
			Ui.hoverSound(key, hover);
			float appear = this.appear(i * 0.04F);
			float lift = Anim.bouncy(key + "lift", hover ? 1 : 0);
			float scale = Anim.bouncy(key + "scale", hover ? 1.07F : 1.0F) * appear;
			float rest = ((i * 37) % 7 - 3) * 0.022F;
			float rot = rest * (1 - lift) + (float) Math.sin(Anim.time() * 3 + i) * 0.01F * lift;
			float cx = tx + TEMPLATE_W / 2.0F;
			float cyy = ty + TEMPLATE_H / 2.0F - lift * 4;
			g.pose().pushMatrix();
			g.pose().translate(cx, cyy);
			g.pose().rotate(rot);
			g.pose().scale(scale, scale);
			g.pose().translate(-TEMPLATE_W / 2.0F, -TEMPLATE_H / 2.0F);
			// paper sheet
			int pw = TEMPLATE_W - 8;
			int ph = TEMPLATE_H - 26;
			Ui.shadow(g, 4, 2, pw, ph, 0.55F + lift * 0.4F);
			Note sample = this.sample(type);
			TextLayout layout = this.sampleLayouts.computeIfAbsent(type, t -> TextLayout.build(sample, TextMetrics.get()));
			PageRenderer.thumbnail(g, sample, layout, TextMetrics.get(), 0, 1, null, 4, 2, pw, ph);
			// pin with a little wobble
			g.pose().pushMatrix();
			g.pose().translate(TEMPLATE_W / 2.0F, 2);
			g.pose().rotate((float) Math.sin(Anim.time() * 9) * 0.25F * lift);
			Ui.sprite(g, Sprites.PIN, -4, -5, 8, 8);
			g.pose().popMatrix();
			// name tag
			String name = Ui.ellipsize(Component.translatable("scribble.type." + type.id + ".short").getString(), TEMPLATE_W - 2);
			int nw = Math.min(TEMPLATE_W, this.font.width(name) + 10);
			Ui.sprite(g, hover ? Sprites.CHIP_SELECTED : Sprites.CHIP, (TEMPLATE_W - nw) / 2, TEMPLATE_H - 19, nw, 15);
			Ui.centered(g, Component.literal(name), TEMPLATE_W / 2, TEMPLATE_H - 16, hover ? 0xFF4A2A08 : Ui.TEXT);
			g.pose().popMatrix();
			this.hs.add(tx, ty, TEMPLATE_W, TEMPLATE_H)
					.tooltip(Component.translatable("scribble.library.new_type", Component.translatable(type.translationKey())))
					.click(() -> {
						Anim.kick(key + "scale", -8);
						this.createNote(type);
					});
		}
		return cy + boardH + 12;
	}

	private float appear(float delay) {
		float t = (Util.getMillis() - this.openedAt) / 1000.0F - delay;
		return t <= 0 ? 0.0F : t >= 0.45F ? 1.0F : Anim.easeOutBack(t / 0.45F);
	}

	private int renderFilters(GuiGraphicsExtractor g, int mx, int my, int x0, int w, int cy) {
		Component heading = Component.translatable(this.filter == Filter.TRASH ? "scribble.library.trash" : "scribble.library.notes");
		Ui.textLight(g, heading, x0 + 2, cy + 4, Ui.TEXT_LIGHT);
		int x = x0 + this.font.width(heading) + 12;
		for (Filter f : Filter.values()) {
			Component label = Component.translatable("scribble.filter." + f.id, this.count(f));
			boolean target = this.dragged != null && (f == Filter.STARRED || f == Filter.TRASH);
			boolean over = target && this.dropChip == f;
			if (target) {
				float pulse = 1 + (float) Math.sin(Anim.time() * 8) * 0.04F + (over ? 0.12F : 0);
				Ui.pushScale(g, x + 20, cy + 7, pulse);
			}
			int cw = Ui.chip(g, this.hs, mx, my, x, cy, label, f.icon, this.filter == f || over, () -> {
				this.filter = f;
				this.scroll = 0;
			});
			if (target) {
				Ui.popScale(g);
			}
			this.chipRects.put(f, new int[]{x - 4, cy - 4, cw + 8, 23});
			x += cw + 4;
		}
		Component sortLabel = Component.translatable("scribble.library.sort", Component.translatable("scribble.sort." + this.sort.id));
		int sw = this.font.width(sortLabel) + 26;
		int sx = Math.max(x + 4, x0 + w - sw);
		int chipY = cy;
		Ui.chip(g, this.hs, mx, my, sx, cy, sortLabel, "sort", false, () -> this.openPopup(this.sortMenu(), sx, chipY + 17));
		if (this.filter == Filter.TRASH && this.count(Filter.TRASH) > 0) {
			cy += 20;
			Ui.chip(g, this.hs, mx, my, x0, cy, Component.translatable("scribble.library.empty_trash"), "trash", false, () -> this.openDialog(new Dialog.Confirm(
					Component.translatable("scribble.library.empty_trash"),
					Component.translatable("scribble.library.empty_trash_confirm", this.count(Filter.TRASH)),
					Component.translatable("scribble.note.delete_button"),
					() -> {
						for (Note n : this.notes) {
							if (n.trashed) {
								NotesStorage.delete(n);
							}
						}
						ScribbleSounds.playVaried(ScribbleSounds.CRUMPLE, 0.8F, 0.8F);
						this.reload();
					})));
		}
		return cy + 24;
	}

	private int renderGrid(GuiGraphicsExtractor g, int mx, int my, int x0, int w, int cy) {
		List<Note> list = this.visibleNotes();
		if (this.dragged != null) {
			list.remove(this.dragged);
		}
		int perRow = Math.max(1, (w + GAP) / (TILE_W + GAP));
		int gridW = perRow * (TILE_W + GAP) - GAP;
		int gx = x0 + (w - gridW) / 2;

		// slots (including one extra for the dragged card)
		int slots = list.size() + (this.dragged != null ? 1 : 0);
		this.slotRects.clear();
		for (int i = 0; i < slots; i++) {
			this.slotRects.add(new int[]{gx + (i % perRow) * (TILE_W + GAP), cy + (i / perRow) * (TILE_H + GAP)});
		}
		if (this.dragged != null) {
			this.insertIndex = this.slotIndexAt(mx, my, slots);
		}

		if (list.isEmpty() && this.dragged == null) {
			return this.renderEmpty(g, x0, w, cy);
		}
		boolean blocked = this.popup != null || this.dialog != null || this.dragged != null;
		for (int i = 0; i < list.size(); i++) {
			Note n = list.get(i);
			int slot = this.dragged != null && this.insertIndex >= 0 && i >= this.insertIndex ? i + 1 : i;
			int[] target = this.slotRects.get(slot);
			float px = Anim.spring(n.id + "#x", target[0], 120, 0.8F);
			float py = Anim.spring(n.id + "#y", target[1], 120, 0.8F);
			int tx = Math.round(px);
			int ty = Math.round(py);
			if (ty > this.height + 20 || ty + TILE_H < HEADER_H - 20) {
				continue;
			}
			boolean hover = !blocked && Ui.hovered(mx, my, tx, ty, TILE_W, TILE_H);
			Ui.hoverSound(n.id, hover);
			float lift = Anim.bouncy(n.id + "#lift", hover ? 1 : 0);
			float scale = this.appear(0.15F + i * 0.03F) * (1 + lift * 0.04F);
			float rot = tiltOf(n.id) * (1 - lift);
			g.pose().pushMatrix();
			g.pose().translate(tx + TILE_W / 2.0F, ty + TILE_H / 2.0F - lift * 3);
			g.pose().rotate(rot);
			g.pose().scale(scale, scale);
			g.pose().translate(-TILE_W / 2.0F, -TILE_H / 2.0F);
			this.drawTile(g, n, hover, 0.6F + lift * 0.35F);
			g.pose().popMatrix();
			this.tileRects.add(new TileRect(n, tx, ty, TILE_W, TILE_H));
			this.hs.add(tx, ty, TILE_W, TILE_H).noPointer().rightClick(() -> this.openPopup(this.noteMenu(n), this.clickX, this.clickY));
			if (hover) {
				int menuX = tx + TILE_W - 22;
				int menuY = ty + 5;
				Ui.iconButton(g, this.hs, mx, my, menuX, menuY, 17, "dots", Component.translatable("scribble.note.more"), false, true, false,
						() -> this.openPopup(this.noteMenu(n), menuX, menuY + 18));
			}
		}
		if (this.dragged != null && this.insertIndex >= 0 && this.dropChip == null) {
			// ghost slot showing where the card will land
			int[] r = this.slotRects.get(this.insertIndex);
			float pulse = 0.5F + 0.5F * (float) Math.sin(Anim.time() * 6);
			int col = ((int) (40 + 40 * pulse) << 24) | 0xFFE9C0;
			for (int k = 0; k < TILE_W; k += 6) {
				g.fill(r[0] + k, r[1], r[0] + Math.min(TILE_W, k + 3), r[1] + 2, col);
				g.fill(r[0] + k, r[1] + TILE_H - 2, r[0] + Math.min(TILE_W, k + 3), r[1] + TILE_H, col);
			}
			for (int k = 0; k < TILE_H; k += 6) {
				g.fill(r[0], r[1] + k, r[0] + 2, r[1] + Math.min(TILE_H, k + 3), col);
				g.fill(r[0] + TILE_W - 2, r[1] + k, r[0] + TILE_W, r[1] + Math.min(TILE_H, k + 3), col);
			}
		}
		int rows = (slots + perRow - 1) / perRow;
		return cy + rows * (TILE_H + GAP);
	}

	private int renderEmpty(GuiGraphicsExtractor g, int x0, int w, int cy) {
		int cx = x0 + w / 2;
		float bob = (float) Math.sin(Anim.time() * 2) * 3;
		g.pose().pushMatrix();
		g.pose().translate(cx, cy + 34 + bob);
		g.pose().rotate((float) Math.sin(Anim.time() * 1.3F) * 0.08F);
		g.pose().scale(3, 3);
		Ui.icon(g, this.filter == Filter.TRASH ? "trash" : "notebook", -8, -8);
		g.pose().popMatrix();
		boolean searching = !this.search.getValue().isBlank();
		String key = searching ? "scribble.library.no_results" : this.filter == Filter.TRASH ? "scribble.library.trash_empty" : "scribble.library.empty";
		Component c = Component.translatable(key);
		Ui.textLight(g, c, cx - this.font.width(c) / 2, cy + 66, Ui.TEXT_LIGHT);
		if (!searching && this.filter != Filter.TRASH) {
			Component hint = Component.translatable("scribble.library.empty_hint");
			Ui.textLight(g, hint, cx - this.font.width(hint) / 2, cy + 78, Ui.TEXT_LIGHT_DIM);
		}
		return cy + 100;
	}

	/** Draws a note card at (0, 0) in the current pose. */
	private void drawTile(GuiGraphicsExtractor g, Note n, boolean hover, float shadow) {
		Ui.shadow(g, 0, 0, TILE_W, TILE_H, shadow);
		Ui.sprite(g, hover ? Sprites.CARD_HOVER : Sprites.CARD, 0, 0, TILE_W, TILE_H);
		int ts = TILE_W - 12;
		g.fill(6, 6, 6 + ts, 6 + ts, 0xFFEADBC0);
		Thumb t = this.thumb(n);
		PageRenderer.thumbnail(g, n, t.layout, TextMetrics.get(), 0, t.pages, t.ink, 7, 7, ts - 2, ts - 2);
		Ui.icon(g, n.type.iconName(), 3, ts - 9);
		if (t.pages > 1) {
			String pc = String.valueOf(t.pages);
			int pw = this.font.width(pc) + 8;
			Ui.sprite(g, Sprites.BADGE, TILE_W - 5 - pw, ts - 6, pw, 12);
			Ui.text(g, pc, TILE_W - 1 - pw, ts - 4, 0xFF4A2A08);
		}
		if (n.starred) {
			float spin = (float) Math.sin(Anim.time() * 2 + n.id.hashCode()) * 0.15F;
			g.pose().pushMatrix();
			g.pose().translate(11, 11);
			g.pose().rotate(spin);
			Ui.icon(g, "star_filled", -8, -8);
			g.pose().popMatrix();
		}
		String title = Ui.ellipsize(displayTitle(n), TILE_W - 12);
		Ui.text(g, title, 6, ts + 11, n.title.isBlank() ? Ui.TEXT_DIM : Ui.TEXT);
		Ui.text(g, Ui.ellipsize(Ui.relativeTime(n.modified), TILE_W - 12), 6, ts + 22, Ui.TEXT_DIM);
	}

	private void renderDragged(GuiGraphicsExtractor g, int mx, int my) {
		Note n = this.dragged;
		float lift = Anim.bouncy("dragLift", 1);
		g.pose().pushMatrix();
		g.pose().translate(mx, my);
		g.pose().rotate(this.angle);
		g.pose().scale(1 + 0.06F * lift, 1 + 0.06F * lift);
		g.pose().translate(-this.grabX, -this.grabY);
		g.pose().pushMatrix();
		g.pose().translate(6 * lift, 9 * lift);
		Ui.shadow(g, 0, 0, TILE_W, TILE_H, 0.7F);
		g.pose().popMatrix();
		this.drawTile(g, n, true, 0);
		// the grabbing hand at the pivot
		g.pose().translate(this.grabX, this.grabY);
		g.pose().rotate(-this.angle);
		Ui.icon(g, "tool_pan_grab", -8, -6);
		g.pose().popMatrix();
	}

	// ------------------------------------------------------------------ drag physics

	/**
	 * Pendulum-like card physics: the card pivots on the point you grabbed it by. Gravity makes off-center grabs hang
	 * and the pivot's acceleration (your mouse flicks) swings it.
	 */
	private void updateDragPhysics(double mx, double my) {
		float dt = Anim.dt();
		if (Double.isNaN(this.prevMx)) {
			this.prevMx = mx;
			this.prevMy = my;
		}
		float nvx = (float) ((mx - this.prevMx) / dt);
		float nvy = (float) ((my - this.prevMy) / dt);
		this.prevMx = mx;
		this.prevMy = my;
		float k = 1 - (float) Math.pow(0.0005, dt);
		float ax = (nvx - this.velX) / dt * k;
		float ay = (nvy - this.velY) / dt * k;
		this.velX += (nvx - this.velX) * k;
		this.velY += (nvy - this.velY) * k;
		if (this.dragged == null) {
			return;
		}
		float rx0 = TILE_W / 2.0F - this.grabX;
		float ry0 = TILE_H / 2.0F - this.grabY;
		float cos = (float) Math.cos(this.angle);
		float sin = (float) Math.sin(this.angle);
		float rx = rx0 * cos - ry0 * sin;
		float ry = rx0 * sin + ry0 * cos;
		float inertia = rx0 * rx0 + ry0 * ry0 + (TILE_W * TILE_W + TILE_H * TILE_H) / 12.0F;
		float gravity = 650;
		float torque = rx * gravity + (ry * ax - rx * ay) * 0.9F;
		this.angVel += (torque / inertia - this.angle * 7.5F - this.angVel * 4.5F) * dt;
		this.angle = Mth.clamp(this.angle + this.angVel * dt, -1.2F, 1.2F);
	}

	/** Which filter chip (Starred / Trash) the dragged card is hovering, using this frame's chip layout. */
	private void updateDropTarget(double mx, double my) {
		this.dropChip = null;
		if (this.dragged == null) {
			return;
		}
		for (Map.Entry<Filter, int[]> e : this.chipRects.entrySet()) {
			int[] r = e.getValue();
			if ((e.getKey() == Filter.STARRED || e.getKey() == Filter.TRASH) && Ui.hovered(mx, my, r[0], r[1], r[2], r[3])) {
				this.dropChip = e.getKey();
			}
		}
	}

	private int slotIndexAt(double mx, double my, int slots) {
		int best = slots - 1;
		double bestD = Double.MAX_VALUE;
		for (int i = 0; i < slots; i++) {
			int[] r = this.slotRects.get(i);
			double dx = mx - (r[0] + TILE_W / 2.0);
			double dy = my - (r[1] + TILE_H / 2.0);
			double d = dx * dx + dy * dy * 0.6;
			if (d < bestD) {
				bestD = d;
				best = i;
			}
		}
		return best;
	}

	private @Nullable TileRect tileAt(double mx, double my) {
		for (int i = this.tileRects.size() - 1; i >= 0; i--) {
			TileRect r = this.tileRects.get(i);
			if (Ui.hovered(mx, my, r.x, r.y, r.w, r.h)) {
				return r;
			}
		}
		return null;
	}

	private void beginDrag(TileRect r, double mx, double my) {
		this.dragged = r.note;
		this.grabX = (float) (this.pressX - r.x);
		this.grabY = (float) (this.pressY - r.y);
		this.angle = tiltOf(r.note.id);
		this.angVel = 0;
		Anim.set("dragLift", 0);
		ScribbleSounds.playVaried(ScribbleSounds.PAPER_PICKUP, 1.0F, 0.6F);
	}

	private void endDrag() {
		Note n = this.dragged;
		this.dragged = null;
		if (n == null) {
			return;
		}
		// let the card land where it is: seed its spring position from the drop point
		Anim.set(n.id + "#x", (float) (this.prevMx - this.grabX));
		Anim.set(n.id + "#y", (float) (this.prevMy - this.grabY));
		if (this.dropChip == Filter.STARRED) {
			if (!n.starred) {
				this.toggleStar(n);
			}
			this.dropChip = null;
			return;
		}
		if (this.dropChip == Filter.TRASH) {
			this.trash(n);
			this.dropChip = null;
			return;
		}
		ScribbleSounds.playVaried(ScribbleSounds.PAPER_DROP, 1.0F, 0.6F);
		List<Note> list = this.visibleNotes();
		list.remove(n);
		int idx = Mth.clamp(this.insertIndex, 0, list.size());
		list.add(idx, n);
		// merge the visible arrangement into the global order
		List<String> newOrder = new ArrayList<>();
		for (Note v : list) {
			newOrder.add(v.id);
		}
		for (String id : this.order) {
			if (!newOrder.contains(id)) {
				newOrder.add(id);
			}
		}
		for (Note other : this.notes) {
			if (!newOrder.contains(other.id)) {
				newOrder.add(other.id);
			}
		}
		this.order = newOrder;
		NotesStorage.saveOrder(newOrder);
		this.sort = Sort.CUSTOM;
	}

	// ------------------------------------------------------------------ input

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mx = event.x();
		double my = event.y();
		int button = event.button();
		this.clickX = (int) mx;
		this.clickY = (int) my;
		if (this.dialog != null) {
			Hotspots.Hotspot h = this.hs.at(mx, my);
			if (h != null && h.onClick != null && button == 0) {
				h.onClick.run();
				return true;
			}
			this.dialog.mouseClicked(event, doubleClick);
			return true;
		}
		if (this.popup != null) {
			if (this.popup.contains(mx, my)) {
				Hotspots.Hotspot h = this.hs.at(mx, my);
				if (h != null && h.onClick != null && button == 0) {
					h.onClick.run();
				}
			} else {
				this.popup = null;
			}
			return true;
		}
		boolean onSearch = this.search.isMouseOver(mx, my)
				|| (mx >= this.search.getX() - 19 && mx < this.search.getX() + this.search.getWidth() + 4 && my >= 8 && my < 26);
		this.search.setFocused(onSearch);
		if (onSearch) {
			this.search.mouseClicked(event, doubleClick);
			return true;
		}
		Hotspots.Hotspot h = this.hs.at(mx, my);
		if (h != null && (h.onClick != null || h.onDrag != null || (button == 1 && h.onRightClick != null))) {
			if (button == 0 && h.onDrag != null) {
				this.activeDrag = h.onDrag;
				h.onDrag.drag(mx, my);
				return true;
			}
			if (button == 0 && h.onClick != null) {
				h.onClick.run();
				return true;
			}
			if (button == 1 && h.onRightClick != null) {
				Ui.click();
				h.onRightClick.run();
				return true;
			}
		}
		if (button == 0) {
			TileRect tile = this.tileAt(mx, my);
			if (tile != null) {
				this.pressed = tile.note;
				this.pressX = mx;
				this.pressY = my;
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
		if (this.activeDrag != null) {
			this.activeDrag.drag(event.x(), event.y());
			return true;
		}
		if (this.pressed != null && this.dragged == null) {
			double d = Math.hypot(event.x() - this.pressX, event.y() - this.pressY);
			if (d > 4) {
				for (TileRect r : this.tileRects) {
					if (r.note == this.pressed) {
						this.beginDrag(r, event.x(), event.y());
						break;
					}
				}
			}
			return true;
		}
		return this.dragged != null || super.mouseDragged(event, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (this.activeDrag != null) {
			this.activeDrag.release();
			this.activeDrag = null;
		}
		if (this.dragged != null) {
			this.endDrag();
			this.pressed = null;
			return true;
		}
		if (this.pressed != null) {
			Note n = this.pressed;
			this.pressed = null;
			if (n.trashed) {
				this.openPopup(this.noteMenu(n), (int) event.x(), (int) event.y());
			} else {
				this.open(n);
			}
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
		if (this.dialog == null && this.popup == null) {
			this.scroll -= scrollY * 30;
		}
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (this.dialog != null) {
			this.dialog.keyPressed(event);
			return true;
		}
		if (this.popup != null && event.isEscape()) {
			this.popup = null;
			return true;
		}
		if (this.dragged != null && event.isEscape()) {
			this.dragged = null;
			this.pressed = null;
			return true;
		}
		if (event.hasControlDownWithQuirk() && event.shortcutKey() == 'f') {
			this.search.setFocused(true);
			return true;
		}
		if (event.hasControlDownWithQuirk() && event.shortcutKey() == 'n') {
			this.createNote(NoteType.LINED);
			return true;
		}
		if (this.search.isFocused()) {
			if (event.isEscape()) {
				if (!this.search.getValue().isEmpty()) {
					this.search.setValue("");
				} else {
					this.search.setFocused(false);
				}
				return true;
			}
			if (this.search.keyPressed(event)) {
				return true;
			}
		}
		if (event.isEscape()) {
			this.onClose();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	public boolean charTyped(CharacterEvent event) {
		if (this.dialog != null) {
			return this.dialog.charTyped(event);
		}
		if (this.search.isFocused()) {
			ScribbleSounds.typing();
			return this.search.charTyped(event);
		}
		if (event.isAllowedChatCharacter() && !Character.isWhitespace(event.codepoint())) {
			this.search.setFocused(true);
			return this.search.charTyped(event);
		}
		return false;
	}

	@Override
	public void onFilesDrop(List<Path> files) {
		int imported = 0;
		for (Path file : files) {
			String name = file.getFileName().toString();
			String lower = name.toLowerCase(Locale.ROOT);
			if (!lower.endsWith(".txt") && !lower.endsWith(".md")) {
				continue;
			}
			try {
				Note note = Note.create(NoteType.LINED, name.substring(0, name.lastIndexOf('.')));
				note.paragraphs.clear();
				for (String line : Files.readString(file, StandardCharsets.UTF_8).replace("\r\n", "\n").split("\n", -1)) {
					note.paragraphs.add(new Paragraph(line.replace('\t', ' ')));
				}
				if (note.paragraphs.isEmpty()) {
					note.paragraphs.add(new Paragraph());
				}
				NotesStorage.save(note);
				imported++;
			} catch (Exception e) {
				Scribble.LOGGER.error("Could not import {}", file, e);
			}
		}
		if (imported > 0) {
			this.reload();
			Notifications.success("folder", Component.translatable("scribble.import.done"), Component.translatable("scribble.import.count", imported));
		}
	}
}
