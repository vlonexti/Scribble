package com.vess7y.scribble.client.note;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.material.MapColor;

/**
 * Every color Minecraft itself uses: the 16 dyes, the 16 chat colors and all map / block material colors.
 */
public final class MinecraftColors {
	public record Swatch(int argb, Component name) {
	}

	public enum Group {
		DYES("dyes"), CHAT("chat"), BLOCKS("blocks");

		public final String id;

		Group(String id) {
			this.id = id;
		}
	}

	private static final String[] CHAT_NAMES = {
			"Black", "Dark Blue", "Dark Green", "Dark Aqua", "Dark Red", "Dark Purple", "Gold", "Gray",
			"Dark Gray", "Blue", "Green", "Aqua", "Red", "Light Purple", "Yellow", "White"
	};
	private static final int[] CHAT_COLORS = {
			0x000000, 0x0000AA, 0x00AA00, 0x00AAAA, 0xAA0000, 0xAA00AA, 0xFFAA00, 0xAAAAAA,
			0x555555, 0x5555FF, 0x55FF55, 0x55FFFF, 0xFF5555, 0xFF55FF, 0xFFFF55, 0xFFFFFF
	};

	private static List<Swatch> dyes;
	private static List<Swatch> chat;
	private static List<Swatch> blocks;

	private MinecraftColors() {
	}

	public static List<Swatch> get(Group set) {
		return switch (set) {
			case DYES -> dyes();
			case CHAT -> chat();
			case BLOCKS -> blocks();
		};
	}

	public static List<Swatch> dyes() {
		if (dyes == null) {
			dyes = new ArrayList<>();
			for (DyeColor d : DyeColor.values()) {
				dyes.add(new Swatch(0xFF000000 | (d.getTextureDiffuseColor() & 0xFFFFFF),
						Component.translatable("color.minecraft." + d.getName())));
			}
		}
		return dyes;
	}

	public static List<Swatch> chat() {
		if (chat == null) {
			chat = new ArrayList<>();
			for (int i = 0; i < CHAT_COLORS.length; i++) {
				chat.add(new Swatch(0xFF000000 | CHAT_COLORS[i], Component.literal(CHAT_NAMES[i])));
			}
		}
		return chat;
	}

	/** All map colors (the colors blocks show on maps), named after their MapColor constants. */
	public static List<Swatch> blocks() {
		if (blocks == null) {
			blocks = new ArrayList<>();
			java.util.Set<Integer> seen = new LinkedHashSet<>();
			for (Field f : MapColor.class.getFields()) {
				if (!Modifier.isStatic(f.getModifiers()) || f.getType() != MapColor.class) {
					continue;
				}
				try {
					MapColor mc = (MapColor) f.get(null);
					if (mc == null || mc.col == 0 || !seen.add(mc.col)) {
						continue;
					}
					blocks.add(new Swatch(0xFF000000 | mc.col, Component.literal(prettify(f.getName()))));
				} catch (IllegalAccessException ignored) {
				}
			}
		}
		return blocks;
	}

	private static String prettify(String constant) {
		String s = constant.startsWith("COLOR_") ? constant.substring(6) : constant;
		StringBuilder out = new StringBuilder();
		for (String word : s.toLowerCase(Locale.ROOT).split("_")) {
			if (!word.isEmpty()) {
				if (!out.isEmpty()) {
					out.append(' ');
				}
				out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
			}
		}
		return out.toString();
	}

	public static int[] argb(List<Swatch> swatches) {
		int[] out = new int[swatches.size()];
		for (int i = 0; i < out.length; i++) {
			out[i] = swatches.get(i).argb();
		}
		return out;
	}
}
