package com.vess7y.scribble.client.render;

import com.vess7y.scribble.client.note.InkLayer;
import java.util.List;
import net.minecraft.resources.Identifier;

/**
 * Something a page can be drawn onto, in page units. Implemented for the live GUI and for the
 * software rasterizer used by PNG / PDF export, so both share {@link PageComposer}.
 */
public interface PageCanvas {
	void fill(int x0, int y0, int x1, int y1, int argb);

	/** Draws a GUI sprite honouring its stretch / tile / nine-slice scaling. */
	void sprite(Identifier sprite, int x, int y, int width, int height);

	/** Draws text with its top-left at (x, y); {@code scale} is page units per font pixel. */
	void text(List<Run> runs, int x, int y, int scale);

	void ink(InkLayer layer, int x, int y, int width, int height);

	/** Whether real glyphs should be drawn (false for tiny thumbnails, which draw text as bars). */
	default boolean detailedText() {
		return true;
	}

	record Run(String text, boolean bold, boolean italic, boolean underline, boolean strike, int color) {
	}
}
