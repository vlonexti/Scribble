package com.vess7y.scribble.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.vess7y.scribble.Scribble;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;

public class ScribbleClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		KeyMapping openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.scribble.open",
				InputConstants.KEY_N,
				KeyMapping.Category.register(Scribble.id("main"))
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.consumeClick()) {
				if (client.gui.screen() == null) {
					client.gui.setScreen(new NotesScreen(null));
				}
			}
		});

		MenuButtons.register();
	}
}
