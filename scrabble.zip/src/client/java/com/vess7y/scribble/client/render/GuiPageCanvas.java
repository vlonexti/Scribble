package com.vess7y.scribble.client.render;

import com.vess7y.scribble.client.note.InkLayer;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;

/**
 * Draws pages into the GUI. The caller sets up the pose so that (0, 0) is the page's top-left corner and one
 * unit is one page unit.
 */
public final class GuiPageCanvas implements PageCanvas {
	private final GuiGraphicsExtractor graphics;
	private final boolean detailed;

	public GuiPageCanvas(GuiGraphicsExtractor graphics, boolean detailed) {
		this.graphics = graphics;
		this.detailed = detailed;
	}

	@Override
	public void fill(int x0, int y0, int x1, int y1, int argb) {
		this.graphics.fill(x0, y0, x1, y1, argb);
	}

	@Override
	public void sprite(Identifier sprite, int x, int y, int width, int height) {
		this.graphics.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, x, y, width, height);
	}

	@Override
	public void text(List<Run> runs, int x, int y, int scale) {
		MutableComponent line = Component.empty();
		for (Run run : runs) {
			Style style = Style.EMPTY
					.withBold(run.bold())
					.withItalic(run.italic())
					.withUnderlined(run.underline())
					.withStrikethrough(run.strike())
					.withColor(run.color() & 0xFFFFFF);
			line.append(Component.literal(run.text()).withStyle(style));
		}
		this.graphics.pose().pushMatrix();
		this.graphics.pose().translate(x, y);
		this.graphics.pose().scale(scale, scale);
		this.graphics.text(Minecraft.getInstance().font, line, 0, 0, 0xFFFFFFFF, false);
		this.graphics.pose().popMatrix();
	}

	@Override
	public void ink(InkLayer layer, int x, int y, int width, int height) {
		this.graphics.blit(RenderPipelines.GUI_TEXTURED, layer.texture(), x, y, 0.0F, 0.0F, width, height,
				layer.width, layer.height, layer.width, layer.height);
	}

	@Override
	public boolean detailedText() {
		return this.detailed;
	}
}
