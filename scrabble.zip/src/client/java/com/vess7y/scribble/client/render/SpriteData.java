package com.vess7y.scribble.client.render;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import com.vess7y.scribble.Scribble;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;

/**
 * CPU-side copy of a GUI sprite and its scaling mode, for the software rasterizer and ink stamps.
 */
public record SpriteData(int[] pixels, int width, int height, Mode mode, int border) {
	private static final Map<Identifier, SpriteData> CACHE = new HashMap<>();
	private static final SpriteData MISSING = new SpriteData(new int[]{0xFFFF00FF}, 1, 1, Mode.STRETCH, 0);

	public enum Mode {
		STRETCH, TILE, NINE_SLICE
	}

	public int get(int x, int y) {
		return this.pixels[Math.floorMod(y, this.height) * this.width + Math.floorMod(x, this.width)];
	}

	public static synchronized SpriteData get(Identifier sprite) {
		return CACHE.computeIfAbsent(sprite, SpriteData::load);
	}

	public static synchronized void invalidate() {
		CACHE.clear();
	}

	private static SpriteData load(Identifier sprite) {
		ResourceManager resources = Minecraft.getInstance().getResourceManager();
		Identifier texture = Sprites.textureOf(sprite);
		Optional<Resource> res = resources.getResource(texture);
		if (res.isEmpty()) {
			return MISSING;
		}
		int[] pixels;
		int w;
		int h;
		try (InputStream in = res.get().open(); NativeImage image = NativeImage.read(in)) {
			w = image.getWidth();
			h = image.getHeight();
			pixels = new int[w * h];
			for (int y = 0; y < h; y++) {
				for (int x = 0; x < w; x++) {
					pixels[y * w + x] = image.getPixel(x, y);
				}
			}
		} catch (Exception e) {
			Scribble.LOGGER.warn("Could not read sprite {}", sprite, e);
			return MISSING;
		}
		Mode mode = Mode.STRETCH;
		int border = 0;
		Optional<Resource> meta = resources.getResource(texture.withSuffix(".mcmeta"));
		if (meta.isPresent()) {
			try (Reader reader = new InputStreamReader(meta.get().open(), StandardCharsets.UTF_8)) {
				JsonObject scaling = JsonParser.parseReader(reader).getAsJsonObject()
						.getAsJsonObject("gui").getAsJsonObject("scaling");
				String type = scaling.get("type").getAsString();
				if (type.equals("tile")) {
					mode = Mode.TILE;
				} else if (type.equals("nine_slice")) {
					mode = Mode.NINE_SLICE;
					border = scaling.get("border").getAsInt();
				}
			} catch (Exception e) {
				Scribble.LOGGER.warn("Could not read sprite meta {}", sprite, e);
			}
		}
		return new SpriteData(pixels, w, h, mode, border);
	}
}
