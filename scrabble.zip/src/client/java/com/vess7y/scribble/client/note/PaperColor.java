package com.vess7y.scribble.client.note;

/**
 * Paper tints available for paper-like note types.
 */
public enum PaperColor {
	WHITE("white", 0xFFFBFBF8),
	CREAM("cream", 0xFFFBF3DA),
	YELLOW("yellow", 0xFFFFEE8A),
	PINK("pink", 0xFFFFCADD),
	BLUE("blue", 0xFFC8E6FF),
	GREEN("green", 0xFFD2F2C2),
	ORANGE("orange", 0xFFFFD8A4),
	PURPLE("purple", 0xFFE2D2FF),
	KRAFT("kraft", 0xFFD1B088),
	GRAY("gray", 0xFFDCDCDC),
	BLACK("black", 0xFF27272D);

	public final String id;
	public final int argb;

	PaperColor(String id, int argb) {
		this.id = id;
		this.argb = argb;
	}

	public boolean isDark() {
		int r = (this.argb >> 16) & 0xFF;
		int g = (this.argb >> 8) & 0xFF;
		int b = this.argb & 0xFF;
		return (r * 299 + g * 587 + b * 114) / 1000 < 110;
	}

	public String translationKey() {
		return "scribble.paper." + this.id;
	}

	public static PaperColor byId(String id, PaperColor fallback) {
		for (PaperColor c : values()) {
			if (c.id.equals(id)) {
				return c;
			}
		}
		return fallback;
	}
}
